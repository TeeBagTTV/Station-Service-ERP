# Projet 4E - 1B


Pour télécharger tous les packages (avoir python et pip déjà installés) :
```
pip3 install -r requirements.txt
```

Pour lancer la page de connexion :
```
python -m flask run
```

- / : Pour vérifier si la connexion fonctionne bien
- /login : Pour se connecter
- /logout : Pour fermer la session en cours

