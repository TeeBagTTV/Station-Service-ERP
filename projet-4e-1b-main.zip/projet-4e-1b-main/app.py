from datetime import datetime, timedelta, date
from flask import Flask, jsonify, render_template, request, flash, redirect, session, url_for, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import text, desc

from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from sqlalchemy.exc import SQLAlchemyError

from werkzeug.utils import secure_filename
import os
from datetime import datetime
import logging
import paramiko

from sqlalchemy.exc import IntegrityError



#logging dans la console
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')



app = Flask(__name__)


#Logging Serveur FTP FileZilla
SFTP_HOST = 'linserv-info-01.campus.unice.fr'
SFTP_PORT = 22
SFTP_USERNAME = 'lm206097'
SFTP_PASSWORD = 'Marino0645'

LOCAL_UPLOAD_FOLDER = 'uploads/DocumentsEssentiels'
REMOTE_PATH = '/home/lm206097/www/uploads/documentsessentiels/'
BASE_URL = 'https://linserv-info-01.campus.unice.fr/~lm206097/uploads/documentsessentiels/' 
ALLOWED_EXTENSIONS = {'pdf','xlsx','docx','txt'}

app.config['UPLOAD_FOLDER'] = LOCAL_UPLOAD_FOLDER
app.config['SECRET_KEY'] = 'key'

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://ll107065:ll107065@linserv-info-01.campus.unice.fr/ll107065_4E'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

app.secret_key = 'key'

#TODO initialiser (surtout id_employe)
id_client = 8
id_employe = 1

#classe utilisateur
class Utilisateur(db.Model):
    __tablename__ = 'Utilisateurs'
    id = db.Column(db.String(255), primary_key=True)
    password = db.Column(db.String(255))
    perm = db.Column(db.Integer)

    def __repr__(self):
        return f'<Utilisateur {self.id}>'


#classe produit
class Produit(db.Model):
    __tablename__ = 'Produit'
    id_produit = db.Column(db.Integer, primary_key=True)
    id_famille = db.Column(db.Integer, nullable=True)
    id_fournisseur = db.Column(db.Integer, nullable=True)
    nom = db.Column(db.String(255), nullable=True)
    description = db.Column(db.Text, nullable=True)
    prix_vente = db.Column(db.Numeric(10,2), nullable=True)
    prix_achat = db.Column(db.Numeric(10,2), nullable=True)
    seuil_alerte = db.Column(db.Numeric(10,2), nullable=True)

    def __repr__(self):
        return f'<Produit {self.nom}>'
    

@app.route('/produits', methods=['GET'])
def get_produits():
    produits = Produit.query.all()
    produits_list = []
    for produit in produits:
        produit_data = {
            'id_produit': produit.id_produit,
            'id_famille': produit.id_famille,
            'id_fournisseur': produit.id_fournisseur,
            'nom': produit.nom,
            'description': produit.description,
            'prix_vente': produit.prix_vente,
            'prix_achat': produit.prix_achat,
            'seuil_alerte': produit.seuil_alerte
        }
        produits_list.append(produit_data)
    return jsonify({'produits': produits_list})



#classe pompe
class Pompe(db.Model):
    __tablename__ = 'Pompe'
    id_pompe = db.Column(db.Integer, primary_key=True, autoincrement=True)
    etat = db.Column(db.Enum('Activée', 'Désactivée', 'En_Panne'), nullable=False)
    date_derniere_inspection = db.Column(db.Date, nullable=True)

    def __repr__(self):
        return f'<Pompe {self.id_pompe} {self.etat}>'


"""#login post
@app.route('/login', methods=['GET', 'POST'])
def login():
    erreur = False
    messageErreur = ''

    if request.method == 'POST':
        id = request.form.get('id')
        mot_de_passe = request.form.get('mot_de_passe')

        utilisateur = Utilisateur.query.filter_by(id=id).first()
        if utilisateur and utilisateur.password == mot_de_passe:
            session['user_id'] = utilisateur.id
            # return redirect(url_for('index'))
            return redirect(url_for('dashboard')) 
        else:
            erreur = True
            messageErreur = 'Id ou mot de passe incorrect.'

    return render_template('login.html', erreur=erreur, messageErreur=messageErreur)"""

@app.route('/login', methods=['GET', 'POST'])
def login():
    erreur = False
    messageErreur = ''

    if request.method == 'POST':
        id = request.form.get('id')
        mot_de_passe = request.form.get('mot_de_passe')

        utilisateur = Utilisateur.query.filter_by(id=id).first()
        if utilisateur and utilisateur.password == mot_de_passe:
            session['user_id'] = utilisateur.id
            if utilisateur.perm == 2:
                return redirect(url_for('dashboard'))  
            elif utilisateur.perm == 1:
                return redirect(url_for('admin_dashboard')) 
        else:
            erreur = True
            messageErreur = 'Id ou mot de passe incorrect.'
    return render_template('login.html', erreur=erreur, messageErreur=messageErreur)


@app.route('/')
def index():
    return redirect(url_for('login')) 
    
@app.route('/dashboard')
def dashboard():
    if 'user_id' in session:
        return render_template('index.html')
    else:
        return redirect(url_for('login'))
    

@app.route('/changer_employe', methods=['GET'])
def changer_employe():
    return redirect(url_for('dashboard'))
    
@app.route('/admin')
def admin_dashboard():
    if 'user_id' in session:
        return render_template('admin.html')
    else:
        return redirect(url_for('login'))


# Test des boutons
@app.route('/endpoint', methods=['POST'])
def endpoint():
    if request.method == 'POST':
        data = request.json 
        print('Données reçues:', data)
        return {'message': 'Données reçues avec succès'}, 200
    else:
        return {'error': 'Méthode non autorisée'}, 405
    
    
"""@app.route('/calculer_total', methods=['POST'])
def calculer_total():
    data = request.json  
    total = data.get('total')
    print(f"Total reçu depuis la page HTML: {total} EUR")
    return jsonify({'message': 'Total calculé avec succès'})"""


@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login'))



def test_db_connection():
    try:
        db.session.execute(text('SELECT 1'))
        db.session.commit()
        print("Connecté à la base de données avec succès.")
    except Exception as e:
        print(f"Erreur lors de la connexion à la base de données: {e}")


    """_summary_: Reçoit pour une vente identifiants et quantités des produits, montant total et type de paiement,
    puis met à jour les stocks en conséquence et enregistre la transaction dans la base.

    Returns:
        _type_: objet JSON 
    """
@app.route('/validerAchat', methods=['POST'])
def valider_achat():
    # récupérer l'objet de détail des marchandises
    donnees = request.json
    app.logger.info("Données reçues : %s", donnees)
    try:
        produits = donnees.get('jsonItems', {}).get('produits', [])
        app.logger.info("Produits : %s", produits)
        # modifier les stocks dans la base
        # pour chaque produit
        for id, quantite in donnees['produits']:
            # TODO trouver un moyen pour savoir si marchandise est produit ou carburant
            type = 'prod'
            idProduit = id
            if type == 'prod':
                donnees = ['StockProduits', 'quantite_stock', 'id_produit']
            elif type == 'carb':
                donnees = ['StockCarburant', 'volume_dispo', 'id_carburant']
            
            # calculer nouvelle quantite
            requeteQte = text(f"SELECT {donnees[1]} FROM {donnees[0]} WHERE {donnees[2]}={idProduit}")
            ancienneQte = db.session.execute(requeteQte).fetchone()[0]
            nouvelleQte = int(ancienneQte - quantite)
            
            # mettre a jour la base
            query = text(f"UPDATE {donnees[0]} SET {donnees[1]}={nouvelleQte} WHERE {donnees[2]}={idProduit}")
            db.session.execute(query)
            
            # enregistrer la transaction dans la bd
        transaction = create_transaction(id_employe, id_client, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), donnees["typePaiement"], donnees["montantTotal"])
        

        # Accéder aux produits
       

        # parcourir chaque produit
        for produit in produits:
            id_produit = str(produit['id'])
            quantite = produit.get('quantity')

            # déterminer le type de produit
            type_produit = 'prod'  # pour l'instant, toujours un produit, à modifier si nécessaire

            # mettre à jour les stocks dans la base de données
            if type_produit == 'prod':
                table_stock = 'StockProduits'
                colonne_quantite = 'quantite_stock'
                colonne_id_produit = 'id_produit'
            elif type_produit == 'carb':
                table_stock = 'StockCarburant'
                colonne_quantite = 'volume_dispo'
                colonne_id_produit = 'id_carburant'

            # calculer la nouvelle quantité
            requete_qte = text(f"SELECT {colonne_quantite} FROM {table_stock} WHERE {colonne_id_produit} = :id_produit")
            ancienne_qte = db.session.execute(requete_qte, {'id_produit': id_produit}).fetchone()[0]
            nouvelle_qte = int(ancienne_qte - quantite)

            # mettre à jour la base de données
            query = text(f"UPDATE {table_stock} SET {colonne_quantite} = :nouvelle_qte WHERE {colonne_id_produit} = :id_produit")
            db.session.execute(query, {'nouvelle_qte': nouvelle_qte, 'id_produit': id_produit})

        # enregistrer la transaction dans la base de données
        type_paiement = donnees.get("jsonItems", {}).get("typePaiement")
        montant_total = donnees.get("jsonItems", {}).get("montantTotal")
        transaction = create_transaction(id_employe, id_client, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), str(type_paiement), str(montant_total))

        # enregistrer les modifications
        db.session.commit()

        return jsonify({'success': 'Transaction enregistrée et stocks mis à jour.'}), 200

    except Exception as e:
        db.session.rollback()
        app.logger.error("Erreur lors de la mise à jour des stocks ou de l'enregistrement de la transaction : %s", e)
        msgErreur = "Erreur lors de la mise à jour des stocks ou de l'enregistrement de la transaction : " + str(e)
        return jsonify({"erreur": msgErreur}), 500
    # TODO lancer verif alerte stocks ?
    


# recuperer la liste des employes afin de peupler le select #personne_contactee
@app.route('/liste_employes', methods=['GET'])
def getListeEmployes():
    employes = Employe.query.all()
    employes_data = [{'id_employe': employe.id_employe, 'nom': employe.nom, 'prenom': employe.prenom} for employe in employes]
    return jsonify(employes_data)

# enregistrer dans la bd la fiche incident cree par l'employe faisant la requete
@app.route('/creer_fiche_incident', methods=['POST'])
def creer_fiche_incident():
    id_employe=1 # ghetto
    data = request.json
    app.logger.info("Données reçues : %s", data)
    id_personne_contactee = data['personne_contactee']
    id_personne_contactee = 1
    typeIncident = data['type']
    detail_technique = data['det_tech']
    autres_remarques = data['remarques']
    solution_apportee = data['solution']
    #TODO date heure solution
    niveau = data['niveau']
    
    # start db transaction
    db.session.begin()
    try:
        query = text("INSERT INTO Incidents (id_employe, id_personne_contactee, niveau, type, detail_technique, autres_remarques, solution_apportee) VALUES(:id_employe, :id_personne_contactee, :niveau, :typeIncident, :detail_technique, :autres_remarques, :solution_apportee)")
        result = db.session.execute(query, {
            'id_employe': id_employe,
            'id_personne_contactee': id_personne_contactee,
            'niveau': niveau,
            'typeIncident': typeIncident,
            'detail_technique': detail_technique,
            'autres_remarques': autres_remarques,
            'solution_apportee': solution_apportee
        })
        db.session.commit()
        """ 
        SORT out this writing to db
        do all the gerant side of things
        em^ploye can see all the incidents concerning him
        if niv 3 selected then theres the fields which change accordingly 
        """
        return jsonify("Incident enregistre dans la BD avec succes"), 200
    except Exception as e:
        db.session.rollback()
        return jsonify(e), 500
    
    
    try:
        result = create_incident(id_employe, id_personne_contactee, typeIncident, detail_technique, autres_remarques, solution_apportee)
        db.session.commit()
        return jsonify(result), 200
    except error as e:
        db.session.rollback()
        error = str(e.__dict__['orig'])
        return jsonify({'mysql_error': error}), 500    
    return jsonify({'success': '1'}), 200

# lors du chargement de gerant, recuperer les incidents pour peupler listes des incidents
@app.route('/liste_incidents', methods=['GET'])
def getListeIncidents():
    incidents = Incident.query.order_by(desc(Incident.date_heure)).all()
    incidents_data = [{'id_incident': incident.id_incident, 'type': incident.type, 'niveau': str(incident.niveau), 'horaire': incident.date_heure, 'auteur': incident.id_employe, 'a_traiter': incident.a_traiter, 'personne_contactee': incident.id_personne_contactee, 'detail': incident.detail_technique, 'remarques':incident.autres_remarques, 'solution':incident.solution_apportee, 'horaire_solution': incident.date_heure_solution} for incident in incidents]
    
    # remplacer les noms des employes
    for incident in incidents_data:
        id_auteur = incident['auteur']
        print("ID de l'auteur : ", id_auteur) # delete me
        employe_nom = db.session.execute(text("SELECT nom FROM Employe WHERE id_employe = :id_auteur"), {'id_auteur': id_auteur}).fetchone()[0]
        print("nom de l'employe : ", employe_nom) # delete me
        incident['auteur'] = employe_nom
    
    return jsonify(incidents_data)


@app.route('/add_product', methods=['POST'])
def add_product():
    
    if not request.is_json:
        return "Invalid content type, expecting application/json", 400
    data = request.get_json()
    product_code = data.get('id_produit')
    if not product_code:
        return jsonify({'error': 'Missing id_produit'}), 400
    data = request.json
    product_code = int(data.get('id_produit'))

    product = Produit.query.filter_by(id_produit=product_code).first()

    if product:
        product_details = {
            'id_produit': product.id_produit,
            'nom': product.nom,
            'prix_vente': str(product.prix_vente),
            'prix_achat': str(product.prix_achat),
        }
        print(product_details)
        return jsonify({'success': True, 'message': 'Product added successfully', 'product_details': product_details})
    else:
        return jsonify({'success': False, 'message': 'Product not found'}), 404






# ----------------- Pompes ----------------- #
    
def create_pompe(etat, date_derniere_inspection):
    pompe = Pompe(etat=etat, date_derniere_inspection=date_derniere_inspection)
    db.session.add(pompe)
    db.session.commit()
    return pompe

def get_all_pompes():
    return Pompe.query.all()

def get_pompe_by_id(id_pompe):
    return Pompe.query.get(id_pompe)

def update_pompe(id_pompe, etat, date_derniere_inspection):
    pompe = Pompe.query.get(id_pompe)
    if pompe:
        pompe.etat = etat
        pompe.date_derniere_inspection = date_derniere_inspection
        db.session.commit()
        return True
    return False

def delete_pompe(id_pompe):
    pompe = Pompe.query.get(id_pompe)
    if pompe:
        db.session.delete(pompe)
        db.session.commit()
        return True
    return False

@app.route('/pompes')
def list_pompes():
    pompes = get_all_pompes()  
    return render_template('pompes.html', pompes=pompes)

@app.route('/api/pompes')
def api_pompes():
    pompes = get_all_pompes()  
    pompes_data = [{
        'id_pompe': pompe.id_pompe,
        'etat': pompe.etat,
        'date_derniere_inspection': pompe.date_derniere_inspection.strftime('%d/%m/%Y') if pompe.date_derniere_inspection else 'Non réalisé'
    } for pompe in pompes]
    return jsonify(pompes_data)

#permet d'activer une pompe, si elle est désactivée
@app.route('/update_pompe/<int:id_pompe>', methods=['POST'])
def update_pompe(id_pompe):
    pompe = Pompe.query.get(id_pompe)
    if pompe:
        pompe.etat = 'Activée' if pompe.etat == 'Désactivée' else 'Désactivée'
        db.session.commit()
        return jsonify({'success': True, 'nouvel_etat': pompe.etat})
    return jsonify({'success': False}), 404



# ----------------- Bon Réapprovisionnement ----------------- #
    
class BonReapprovisionnement(db.Model):
    __tablename__ = 'BonReapprovisionnement'
    id_br = db.Column(db.Integer, primary_key=True, autoincrement=True)
    date_br = db.Column(db.Date, nullable=False)
    montant_total = db.Column(db.Numeric(10, 2))

    def __repr__(self):
        return f'<BonReapprovisionnement {self.id_br}>'


def create_bon(date_br, montant_total):
    nouveau_bon = BonReapprovisionnement(date_br=date_br, montant_total=montant_total)
    db.session.add(nouveau_bon)
    db.session.commit()
    return nouveau_bon


def get_all_bons():
    return BonReapprovisionnement.query.all()


def get_bon_by_id(id_br):
    return BonReapprovisionnement.query.get(id_br)


def update_bon(id_br, new_date_br, new_montant_total):
    bon = BonReapprovisionnement.query.get(id_br)
    if bon:
        bon.date_br = new_date_br
        bon.montant_total = new_montant_total
        db.session.commit()
        return True
    return False


def delete_bon(id_br):
    bon = BonReapprovisionnement.query.get(id_br)
    if bon:
        db.session.delete(bon)
        db.session.commit()
        return True
    return False


@app.route('/bons', methods=['POST'])
def create_bon_route():
    date_br = request.form['date_br']
    montant_total = request.form['montant_total']
    create_bon(date_br, montant_total)
    return redirect(url_for('get_all_bons_route'))

@app.route('/bons', methods=['GET'])
def get_all_bons_route():
    bons = get_all_bons()
    return render_template('list_bons.html', bons=bons)

@app.route('/bons/<int:id_br>', methods=['GET'])
def get_bon_route(id_br):
    bon = get_bon_by_id(id_br)
    if bon:
        return render_template('detail_bon.html', bon=bon)
    else:
        flash('Bon de réapprovisionnement non trouvé.')
        return redirect(url_for('get_all_bons_route'))

@app.route('/bons/<int:id_br>', methods=['POST'])
def update_bon_route(id_br):
    new_date_br = request.form['date_br']
    new_montant_total = request.form['montant_total']
    if update_bon(id_br, new_date_br, new_montant_total):
        flash('Mise à jour réussie.')
    else:
        flash('Échec de la mise à jour.')
    return redirect(url_for('get_bon_route', id_br=id_br))

@app.route('/bons/<int:id_br>/delete', methods=['POST'])
def delete_bon_route(id_br):
    if delete_bon(id_br):
        flash('Suppression réussie.')
    else:
        flash('Ce bon de réapprovisionnement ne peut pas être supprimé.')
    return redirect(url_for('get_all_bons_route'))


# ----------------- Carburant ----------------- #


class Carburant(db.Model):
    __tablename__ = 'Carburant'
    id_carburant = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nom = db.Column(db.String(255), nullable=False)
    prix_vente = db.Column(db.Numeric(10, 2), nullable=True)
    prix_achat = db.Column(db.Numeric(10, 2), nullable=True)
    description = db.Column(db.Text, nullable=True)
    seuil_alerte = db.Column(db.Numeric(10, 2), nullable=True)
    id_cuve = db.Column(db.Integer, db.ForeignKey('Cuve.id_cuve'), nullable=False)


    def __repr__(self):
        return f'<Carburant {self.nom}>'


def create_carburant(nom, prix_vente, prix_achat, description, seuil_alerte):
    nouveau_carburant = Carburant(nom=nom, prix_vente=prix_vente, prix_achat=prix_achat, 
                                   description=description, seuil_alerte=seuil_alerte)
    db.session.add(nouveau_carburant)
    db.session.commit()
    return nouveau_carburant


def get_all_carburants():
    return Carburant.query.all()

def get_carburant_by_id(id_carburant):
    return Carburant.query.get(id_carburant)


@app.route('/get_carburants')
def get_carburants():
    carburants_data = db.session.query(
        Carburant.id_carburant,
        Carburant.nom,
        Carburant.prix_vente,
        Carburant.prix_achat,
        Carburant.description,
        Carburant.seuil_alerte,
        Cuve.niveau_actuel,
        Cuve.capacite_totale
    ).join(Cuve, Carburant.id_cuve == Cuve.id_cuve).all()

    carburant_list = [
        {
            'id': data.id_carburant,
            'nom': data.nom,
            'prix_vente': data.prix_vente,
            'prix_achat': data.prix_achat,
            'description': data.description, 
            'seuil_alerte': data.seuil_alerte,
            'niveau_actuel': data.niveau_actuel,
            'capacite_totale': data.capacite_totale,
            'niveau_percent': (data.niveau_actuel / data.capacite_totale) * 100 if data.capacite_totale else 0
        } for data in carburants_data
    ]
    return jsonify(carburant_list)



@app.route('/get_selected_carburants')
def get_selected_carburants():
    selected_ids = [2, 4, 5]  
    carburants_data = db.session.query(
        Carburant.id_carburant,
        Carburant.nom,
        Carburant.prix_vente,
        Carburant.prix_achat,
        Carburant.description,
        Carburant.seuil_alerte,
        Cuve.niveau_actuel,
        Cuve.capacite_totale
    ).join(Cuve, Carburant.id_cuve == Cuve.id_cuve).filter(Carburant.id_carburant.in_(selected_ids)).all()

    carburants = []
    for carburant_data in carburants_data:
        carburant = {
            'id': carburant_data.id_carburant,
            'nom': carburant_data.nom,
            'prix_vente': carburant_data.prix_vente,
            'prix_achat': carburant_data.prix_achat,
            'description': carburant_data.description,
            'seuil_alerte': carburant_data.seuil_alerte,
            'niveau_actuel': carburant_data.niveau_actuel,
            'capacite_totale': carburant_data.capacite_totale,
            'niveau_percent': (carburant_data.niveau_actuel / carburant_data.capacite_totale) * 100 if carburant_data.capacite_totale else 0
        }
        carburants.append(carburant)

    return jsonify(carburants)


@app.route('/add_or_update_carburant', methods=['POST'])
def add_or_update_carburant():
    id_carburant = request.form.get('idcarburant')
    nom = request.form.get('cuves-name')
    description = request.form.get('cuves-description')
    prix_achat = request.form.get('purchase-cuves')
    prix_vente = request.form.get('selling-cuves')
    seuil_alerte = request.form.get('alert-cuves')
    id_cuve = request.form.get('cuves-id')

    logging.info(id_carburant)

    try:
        prix_achat = Decimal(prix_achat) if prix_achat else None
        prix_vente = Decimal(prix_vente) if prix_vente else None
        seuil_alerte = Decimal(seuil_alerte) if seuil_alerte else None
        id_cuve = int(id_cuve) if id_cuve else None
    except (InvalidOperation, ValueError):
        logging.error("'status': 'error', 'message': 'Données numériques invalides.'")
        return jsonify({'status': 'error', 'message': 'Données numériques invalides.'}), 400

    if id_carburant:
        carburant = Carburant.query.get(id_carburant)
        def clean(value):
            return value.strip() if value and value.strip() else None
        if carburant:
            carburant.nom = clean(request.form.get('cuves-name')) or carburant.nom
            carburant.description = clean(request.form.get('cuves-description')) or carburant.description
            carburant.prix_achat = Decimal(clean(request.form.get('purchase-cuves'))) if clean(request.form.get('purchase-cuves')) else carburant.prix_achat
            carburant.prix_vente = Decimal(clean(request.form.get('selling-cuves'))) if clean(request.form.get('selling-cuves')) else carburant.prix_vente
            carburant.seuil_alerte = Decimal(clean(request.form.get('alert-cuves'))) if clean(request.form.get('alert-cuves')) else carburant.seuil_alerte
            carburant.id_cuve = int(clean(request.form.get('cuves-id'))) if clean(request.form.get('cuves-id')) else carburant.id_cuve
            message = 'Carburant mis à jour avec succès.'
        else:
            logging.error('Carburant non trouvé.')
            return jsonify({'status': 'error', 'message': 'Carburant non trouvé.'}), 404
    else: 
        logging.error("Erreur lors de la modification du carburant.")
    try:
        db.session.commit()
        return jsonify({'status': 'success', 'message': message}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': 'error', 'message': str(e)}), 500







def update_carburant(id_carburant, new_nom, new_prix_vente, new_prix_achat, new_description, new_seuil_alerte):
    carburant = Carburant.query.get(id_carburant)
    if carburant:
        carburant.nom = new_nom
        carburant.prix_vente = new_prix_vente
        carburant.prix_achat = new_prix_achat
        carburant.description = new_description
        carburant.seuil_alerte = new_seuil_alerte
        db.session.commit()
        return True
    return False

def delete_carburant(id_carburant):
    carburant = Carburant.query.get(id_carburant)
    if carburant:
        db.session.delete(carburant)
        db.session.commit()
        return True
    return False

@app.route('/carburants', methods=['POST'])
def create_carburant_endpoint():
    nom = request.form.get('nom')
    prix_vente = request.form.get('prix_vente')
    prix_achat = request.form.get('prix_achat')
    description = request.form.get('description')
    seuil_alerte = request.form.get('seuil_alerte')

    create_carburant(nom, prix_vente, prix_achat, description, seuil_alerte)
    return redirect(url_for('list_carburants'))

@app.route('/carburants', methods=['GET'])
def list_carburants():
    carburants = get_carburants()
    return render_template('carburants.html', carburants=carburants)

@app.route('/carburants/<int:id_carburant>', methods=['GET'])
def get_carburant(id_carburant):
    carburant = get_carburant_by_id(id_carburant)
    if carburant:
        carburant_dict = {
            'id_carburant': carburant.id_carburant,
            'nom': carburant.nom,
            'prix_vente': carburant.prix_vente,
            'prix_achat': carburant.prix_achat,
            'description': carburant.description,
            'seuil_alerte': carburant.seuil_alerte
        }
        return jsonify(carburant_dict)
    else:
        return jsonify({"error": "Carburant not found"}), 404
@app.route('/carburants/<int:id_carburant>', methods=['POST'])
def update_carburant_endpoint(id_carburant):
    nom = request.form.get('nom')
    prix_vente = request.form.get('prix_vente')
    prix_achat = request.form.get('prix_achat')
    description = request.form.get('description')
    seuil_alerte = request.form.get('seuil_alerte')

    if update_carburant(id_carburant, nom, prix_vente, prix_achat, description, seuil_alerte):
        flash('Carburant mis à jour avec succès.')
    else:
        flash('Mise à jour du carburant échouée.')
    return redirect(url_for('get_carburant', id_carburant=id_carburant))

@app.route('/carburants/<int:id_carburant>/delete', methods=['POST'])
def delete_carburant_endpoint(id_carburant):
    if delete_carburant(id_carburant):
        flash('Carburant supprimé avec succès.')
    else:
        flash('Suppression du carburant échouée.')
    return redirect(url_for('list_carburants'))


# ----------------- Cuve (carburant) ----------------- #
class Cuve(db.Model):
    __tablename__ = 'Cuve'
    id_cuve = db.Column(db.Integer, primary_key=True, autoincrement=True)
    capacite_totale = db.Column(db.Numeric(10, 2), nullable=True)
    niveau_actuel = db.Column(db.Numeric(10, 2), nullable=True)
    seuil_alerte = db.Column(db.Numeric(10, 2), nullable=True)
    date_dernier_reapprovisionnement = db.Column(db.Date, nullable=True)

    def __repr__(self):
        return f'<Cuve {self.id_cuve}>'

# Exemples de fonctions CRUD pour Cuve (à compléter selon les besoins)
def create_cuve( capacite_totale, niveau_actuel, seuil_alerte, date_dernier_reapprovisionnement):
    cuve = Cuve(
        capacite_totale=capacite_totale,
        niveau_actuel=niveau_actuel,
        seuil_alerte=seuil_alerte,
        date_dernier_reapprovisionnement=date_dernier_reapprovisionnement
    )
    db.session.add(cuve)
    db.session.commit()
    return cuve



# ----------------- Carte Station ----------------- #

class CarteStation(db.Model):
    __tablename__ = 'CartesStation'
    id_carte_station = db.Column(db.Integer, primary_key=True, autoincrement=True)
    id_client = db.Column(db.Integer, nullable=False)
    date_creation = db.Column(db.DateTime)
    montant_credit_energie = db.Column(db.Numeric(10, 2))
    bonus = db.Column(db.Numeric(10, 2))
    statut = db.Column(db.Enum('active', 'perdue'))

def __repr__(self):
    return f'<CarteStation {self.id_carte_station}>'

def create_carte_station(id_client, date_creation, montant_credit_energie, bonus, statut):
    carte_station = CarteStation(id_client=id_client, date_creation=date_creation,
                                 montant_credit_energie=montant_credit_energie, bonus=bonus, statut=statut)
    db.session.add(carte_station)
    db.session.commit()
    return carte_station

def get_all_cartes_station():
    return CarteStation.query.all()

def get_carte_station_by_id(id_carte_station):
    return CarteStation.query.get(id_carte_station)

def update_carte_station_credit(id_carte_station, additional_credit):
    carte_station = CarteStation.query.get(id_carte_station)
    if carte_station:
        additional_credit_decimal = Decimal(str(additional_credit))
        carte_station.montant_credit_energie += additional_credit_decimal
        db.session.commit()
        return True
    return False

def update_carte_station_bonus(id_carte_station, additional_bonus):
    carte_station = CarteStation.query.get(id_carte_station)
    if carte_station:
        additional_bonus_decimal = Decimal(str(additional_bonus))
        carte_station.bonus -= additional_bonus_decimal
        db.session.commit()
        return True
    return False


def delete_carte_station(id_carte_station):
    carte_station = CarteStation.query.get(id_carte_station)
    if carte_station:
        db.session.delete(carte_station)
        db.session.commit()
        return True
    return False

@app.route('/cartes_station', methods=['POST'])
def create_carte_station_endpoint():
    id_client = request.form.get('id_client')
    date_creation = request.form.get('date_creation')
    montant_credit_energie = request.form.get('montant_credit_energie')
    bonus = request.form.get('bonus')
    statut = request.form.get('statut')

    create_carte_station(id_client, date_creation, montant_credit_energie, bonus, statut)
    return redirect(url_for('list_cartes_station'))

@app.route('/cartes_station', methods=['GET'])
def list_cartes_station():
    cartes = get_all_cartes_station()
    return render_template('cartes_station.html', cartes=cartes)

@app.route('/cartes_station/<int:id_carte_station>', methods=['GET'])
def get_carte_station(id_carte_station):
    carte = get_carte_station_by_id(id_carte_station)
    if carte:
        return jsonify({
            'id_carte_station': carte.id_carte_station,
            'id_client': carte.id_client,
            'date_creation': carte.date_creation.isoformat(),
            'montant_credit_energie': str(carte.montant_credit_energie),
            'bonus': str(carte.bonus), 
            'statut': carte.statut
        })
    else:
        return jsonify({'erreur': 'La carte station demandée n\'existe pas.'}), 404

@app.route('/cartes_station/<int:id_carte_station>/credit', methods=['POST'])
def update_carte_station_endpoint(id_carte_station):
    data = request.get_json()
    try:
        additional_credit = float(data.get('montant_credit_energie', 0))
    except ValueError:
        return jsonify({'erreur': 'Montant crédit énergie invalide.'}), 400
    
    if update_carte_station_credit(id_carte_station, additional_credit):
        return jsonify({'message': 'Carte station mise à jour avec succès.'}), 200
    else:
        return jsonify({'erreur': 'Mise à jour de la carte station échouée.'}), 400

@app.route('/cartes_station/<int:id_carte_station>/bonus', methods=['POST'])
def update_carte_station_bonus_endpoint(id_carte_station):
    data = request.get_json()
    try:
        additional_bonus = float(data.get('bonus', 0))
    except ValueError:
        return jsonify({'erreur': 'Bonus invalide.'}), 400
    
    if additional_bonus > 0:
        if update_carte_station_bonus(id_carte_station, additional_bonus):
            return jsonify({'message': 'Bonus de la carte station mis à jour avec succès.'}), 200
        else:
            return jsonify({'erreur': 'Mise à jour du bonus de la carte station échouée.'}), 400
    else:
        return jsonify({'erreur': 'Bonus non fourni ou invalide.'}), 400
    
@app.route('/cartes_station/int:id_carte_station/delete', methods=['POST'])
def delete_carte_station_endpoint(id_carte_station):
    if delete_carte_station(id_carte_station):
        flash('Carte station supprimée avec succès.')
    else:
        flash('Suppression de la carte station échouée.')
    return redirect(url_for('list_cartes_station'))



# ----------------- Client ----------------- #

class Client(db.Model):
    __tablename__ = 'Client'
    id_client = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nom = db.Column(db.String(255), nullable=False)
    prenom = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), nullable=False, unique=True)
    adresse = db.Column(db.String(255))
    code_secret = db.Column(db.Integer)

    def __repr__(self):
        return f'<Client {self.prenom} {self.nom}>'

def create_client(nom, prenom, email, adresse, code_secret):
    client = Client(nom=nom, prenom=prenom, email=email, adresse=adresse, code_secret=code_secret)
    db.session.add(client)
    db.session.commit()
    return client

def get_all_clients():
    return Client.query.all()

def get_client_by_id(id_client):
    return Client.query.get(id_client)

def update_client(id_client, nom, prenom, email, adresse, code_secret):
    client = Client.query.get(id_client)
    if client:
        client.nom = nom
        client.prenom = prenom
        client.email = email
        client.adresse = adresse
        client.code_secret = code_secret
        db.session.commit()
        return True
    return False

def delete_client(id_client):
    client = Client.query.get(id_client)
    if client:
        db.session.delete(client)
        db.session.commit()
        return True
    return False


@app.route('/get_clients')
def get_clients():
    clients = Client.query.all()
    clients_json = [{'id_client': client.id_client, 'nom': client.nom, 'prenom': client.prenom, 'email': client.email, 'adresse': client.adresse, 'code_secret': client.code_secret} for client in clients]
    return jsonify(clients_json)


@app.route('/clients', methods=['POST'])
def create_client_endpoint():
    nom = request.form.get('nom')
    prenom = request.form.get('prenom')
    email = request.form.get('email')
    adresse = request.form.get('adresse')
    code_secret = request.form.get('code_secret')

    create_client(nom, prenom, email, adresse, code_secret)
    return redirect(url_for('list_clients'))

@app.route('/clients', methods=['GET'])
def list_clients():
    clients = get_all_clients()
    return render_template('index.html', clients=clients)

@app.route('/clients/<int:id_client>', methods=['GET'])
def get_client_endpoint(id_client):
    client = get_client_by_id(id_client)
    if client:
        return jsonify({
            'id_client': client.id_client,
            'nom': client.nom,
            'prenom': client.prenom,
            'email': client.email,
            'adresse': client.adresse,
        })
    else:
        return jsonify({'erreur': 'Client non trouvé'}), 404

@app.route('/clients/<int:id_client>', methods=['POST'])
def update_client_endpoint(id_client):
    nom = request.form.get('nom')
    prenom = request.form.get('prenom')
    email = request.form.get('email')
    adresse = request.form.get('adresse')
    code_secret = request.form.get('code_secret')

    if update_client(id_client, nom, prenom, email, adresse, code_secret):
        flash('Client mis à jour avec succès.')
    else:
        flash('Mise à jour du client échouée.')
    return redirect(url_for('get_client_endpoint', id_client=id_client))

@app.route('/clients/int:id_client/delete', methods=['POST'])
def delete_client_endpoint(id_client):
    if delete_client(id_client):
        flash('Client supprimé avec succès.')
    else:
        flash('Suppression du client échouée.')
    return redirect(url_for('list_clients'))



# ----------------- Direction régional ----------------- #

class DirectionRegional(db.Model):
    __tablename__ = 'DirectionRegionale'
    id_direction = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nom = db.Column(db.String(255), nullable=False)
    adresse = db.Column(db.String(255), nullable=False)
    telephone = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), nullable=False)

    def __repr__(self):
        return f'<DirectionRegional {self.nom}>'

def create_direction_regional(nom, adresse, telephone, email):
    direction = DirectionRegional(nom=nom, adresse=adresse, telephone=telephone, email=email)
    db.session.add(direction)
    db.session.commit()
    return direction

def get_all_directions_regionales():
    return DirectionRegional.query.all()

def get_direction_regional_by_id(id_direction):
    return DirectionRegional.query.get(id_direction)

def update_direction_regional(id_direction, nom, adresse, telephone, email):
    direction = DirectionRegional.query.get(id_direction)
    if direction:
        direction.nom = nom
        direction.adresse = adresse
        direction.telephone = telephone
        direction.email = email
        db.session.commit()
        return True
    return False

def delete_direction_regional(id_direction):
    direction = DirectionRegional.query.get(id_direction)
    if direction:
        db.session.delete(direction)
        db.session.commit()
        return True
    return False


@app.route('/directions', methods=['POST'])
def create_direction_regional_endpoint():
    nom = request.form.get('nom')
    adresse = request.form.get('adresse')
    telephone = request.form.get('telephone')
    email = request.form.get('email')

    create_direction_regional(nom, adresse, telephone, email)
    return redirect(url_for('list_directions_regionales'))

@app.route('/directions', methods=['GET'])
def list_directions_regionales():
    directions = get_all_directions_regionales()
    return render_template('directions.html', directions=directions)

@app.route('/directions/<int:id_direction>', methods=['GET'])
def get_direction_regional(id_direction):
    direction = get_direction_regional_by_id(id_direction)
    return render_template('direction_detail.html', direction=direction)

@app.route('/directions/int:id_direction', methods=['POST'])
def update_direction_regional_endpoint(id_direction):
    nom = request.form.get('nom')
    adresse = request.form.get('adresse')
    telephone = request.form.get('telephone')
    email = request.form.get('email')
    if update_direction_regional(id_direction, nom, adresse, telephone, email):
        flash('Direction régionale mise à jour avec succès.')
    else:
        flash('Mise à jour de la direction régionale échouée.')
    return redirect(url_for('get_direction_regional', id_direction=id_direction))

@app.route('/directions/int:id_direction/delete', methods=['POST'])
def delete_direction_regional_endpoint(id_direction):
    if delete_direction_regional(id_direction):
        flash('Direction régionale supprimée avec succès.')
    else:
        flash('Suppression de la direction régionale échouée.')
    return redirect(url_for('list_directions_regionales'))


# ----------------- Directive ----------------- #

class Directive(db.Model):
    __tablename__ = 'Directives'
    id_directive = db.Column(db.Integer, primary_key=True, autoincrement=True)
    id_direction_regionale = db.Column(db.Integer, db.ForeignKey('directions_regionales.id_direction'), nullable=False)
    description = db.Column(db.Text, nullable=False)
    date_creation = db.Column(db.Date, nullable=False)

    def to_dict(self):
        return {
            'id_directive': self.id_directive,
            'id_direction_regionale': self.id_direction_regionale,
            'description': self.description,
            'date_creation': self.date_creation.isoformat(),
        }

    def __repr__(self):
        return f'<Directive {self.id_directive}>'
    

@app.route('/directives', methods=['GET'])
def get_directives():
    directives = Directive.query.all()
    directives_list = [directive.to_dict() for directive in directives]
    return jsonify(directives_list)



# def create_directive(id_direction_regionale, description, date_creation):
#     directive = Directive(id_direction_regionale=id_direction_regionale, description=description, date_creation=date_creation)
#     db.session.add(directive)
#     db.session.commit()
#     return directive


# def get_directive_by_id(id_directive):
#     return Directive.query.get(id_directive)

# def update_directive(id_directive, id_direction_regionale, description, date_creation):
#     directive = Directive.query.get(id_directive)
#     if directive:
#         directive.id_direction_regionale = id_direction_regionale
#         directive.description = description
#         directive.date_creation = date_creation
#         db.session.commit()
#         return True
#     return False

# def delete_directive(id_directive):
#     directive = Directive.query.get(id_directive)
#     if directive:
#         db.session.delete(directive)
#         db.session.commit()
#         return True
#     return False


@app.route('/directives', methods=['POST'])
def create_directive_endpoint():
    id_direction_regionale = request.form.get('id_direction_regionale')
    description = request.form.get('description')
    date_creation = request.form.get('date_creation') 

    create_directive(id_direction_regionale, description, date_creation)
    return redirect(url_for('list_directives'))

@app.route('/directives', methods=['GET'])
def list_directives():
    directives = get_all_directives()
    return render_template('directives.html', directives=directives)

@app.route('/directives/<int:id_directive>', methods=['GET'])
def get_directive_endpoint(id_directive):
    directive = get_directive_by_id(id_directive)
    return render_template('directive_detail.html', directive=directive)

@app.route('/directives/<int:id_directive>', methods=['POST'])
def update_directive_endpoint(id_directive):
    id_direction_regionale = request.form.get('id_direction_regionale')
    description = request.form.get('description')
    date_creation = request.form.get('date_creation')

    if update_directive(id_directive, id_direction_regionale, description, date_creation):
        flash('Directive mise à jour avec succès.')
    else:
        flash('Mise à jour de la directive échouée.')
    return redirect(url_for('get_directive_endpoint', id_directive=id_directive))

@app.route('/directives/<int:id_directive>/delete', methods=['POST'])
def delete_directive_endpoint(id_directive):
    if delete_directive(id_directive):
        flash('Directive supprimée avec succès.')
    else:
        flash('Suppression de la directive échouée.')
    return redirect(url_for('list_directives'))


# ----------------- Employé ----------------- #

class Employe(db.Model):
    __tablename__ = 'Employe'
    id_employe = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nom = db.Column(db.String(255), nullable=False)
    prenom = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), nullable=False, unique=True)
    mot_de_passe = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum('employe', 'gerant'), nullable=False)

    def __repr__(self):
        return f'<Employe {self.prenom} {self.nom}>'
    
    def getNomPrenomEmploye(self):
        return "", self.prenom, " ", self.nom


def create_employe(nom, prenom, email, mot_de_passe, role):
    employe = Employe(nom=nom, prenom=prenom, email=email, mot_de_passe=mot_de_passe, role=role)
    db.session.add(employe)
    db.session.commit()
    return employe

@app.route('/employes', methods=['GET'])
def get_employes():
    employes = Employe.query.all()
    result = [
        {
            'id_employe': employe.id_employe,
            'nom': employe.nom,
            'prenom': employe.prenom,
            'email': employe.email,
            'mot_de_passe': employe.mot_de_passe,
            'role': employe.role
        }
        for employe in employes
    ]
    return jsonify(result)


@app.route('/update_employe/<int:id_employe>', methods=['POST'])
def update_employe_info(id_employe):
    data = request.get_json()
    employe = Employe.query.get(id_employe)
    if employe:
        employe.nom = data.get('nom')
        employe.prenom = data.get('prenom')
        employe.email = data.get('email')
        employe.role = data.get('role')
        db.session.commit()
        return jsonify({'message': 'Employé mis à jour avec succès.'})
    else:
        return jsonify({'message': 'Employé non trouvé.'}), 404


def get_all_employes():
    return Employe.query.all()

def get_employe_by_id(id_employe):
    return Employe.query.get(id_employe)

def update_employe(id_employe, nom, prenom, email, mot_de_passe, role):
    employe = Employe.query.get(id_employe)
    if employe:
        employe.nom = nom
        employe.prenom = prenom
        employe.email = email
        employe.mot_de_passe = mot_de_passe
        employe.role = role
        db.session.commit()
        return True
    return False

def delete_employe(id_employe):
    employe = Employe.query.get(id_employe)
    if employe:
        db.session.delete(employe)
        db.session.commit()
        return True
    return False


# @app.route('/employes', methods=['POST'])
# def create_employe_endpoint():
#     nom = request.form.get('nom')
#     prenom = request.form.get('prenom')
#     email = request.form.get('email')
#     mot_de_passe = request.form.get('mot_de_passe')  
#     role = request.form.get('role')

#     create_employe(nom, prenom, email, mot_de_passe, role)
#     return redirect(url_for('list_employes'))

# @app.route('/employes', methods=['GET'])
# def list_employes():
#     employes = get_all_employes()
#     return render_template('employes.html', employes=employes)

# @app.route('/employes/<int:id_employe>', methods=['GET'])
# def get_employe_endpoint(id_employe):
#     employe = get_employe_by_id(id_employe)
#     return render_template('employe_detail.html', employe=employe)

# @app.route('/employes/<int:id_employe>', methods=['POST'])
# def update_employe_endpoint(id_employe):
#     nom = request.form.get('nom')
#     prenom = request.form.get('prenom')
#     email = request.form.get('email')
#     mot_de_passe = request.form.get('mot_de_passe')
#     role = request.form.get('role')
#     if update_employe(id_employe, nom, prenom, email, mot_de_passe, role):
#         flash('Employé mis à jour avec succès.')
#     else:
#         flash('Mise à jour de l\'employé échouée.')
#     return redirect(url_for('get_employe_endpoint', id_employe=id_employe))

# @app.route('/employes/int:id_employe/delete', methods=['POST'])
# def delete_employe_endpoint(id_employe):
#     if delete_employe(id_employe):
#         flash('Employé supprimé avec succès.')
#     else:
#         flash('Suppression de l\'employé échouée.')
#     return redirect(url_for('list_employes'))


# ----------------- Famille produit ----------------- #

class FamilleProduit(db.Model):
    __tablename__ = 'FamilleProduit'
    id_famille = db.Column(db.Integer, primary_key=True, autoincrement=True)
    type_famille = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)

    def __repr__(self):
        return f'<FamilleProduit {self.type_famille}>'

def create_famille_produit(type_famille, description):
    famille_produit = FamilleProduit(type_famille=type_famille, description=description)
    db.session.add(famille_produit)
    db.session.commit()
    return famille_produit

def get_all_familles_produit():
    return FamilleProduit.query.all()

def get_famille_produit_by_id(id_famille):
    return FamilleProduit.query.get(id_famille)

def update_famille_produit(id_famille, type_famille, description):
    famille_produit = FamilleProduit.query.get(id_famille)
    if famille_produit:
        famille_produit.type_famille = type_famille
        famille_produit.description = description
        db.session.commit()
        return True
    return False

def delete_famille_produit(id_famille):
    famille_produit = FamilleProduit.query.get(id_famille)
    if famille_produit:
        db.session.delete(famille_produit)
        db.session.commit()
        return True
    return False

@app.route('/familles_produit', methods=['POST'])
def create_famille_produit_endpoint():
    type_famille = request.form.get('type_famille')
    description = request.form.get('description')

    create_famille_produit(type_famille, description)
    return redirect(url_for('list_familles_produit'))

@app.route('/familles_produit', methods=['GET'])
def list_familles_produit():
    familles = get_all_familles_produit()
    return render_template('familles_produit.html', familles=familles)

@app.route('/familles_produit/<int:id_famille>', methods=['GET'])
def get_famille_produit(id_famille):
    famille = get_famille_produit_by_id(id_famille)
    return render_template('famille_produit_detail.html', famille=famille)

@app.route('/familles_produit/<int:id_famille>', methods=['POST'])
def update_famille_produit_endpoint(id_famille):
    type_famille = request.form.get('type_famille')
    description = request.form.get('description')

    if update_famille_produit(id_famille, type_famille, description):
        flash('Famille de produit mise à jour avec succès.')
    else:
        flash('Mise à jour de la famille de produit échouée.')
    return redirect(url_for('get_famille_produit', id_famille=id_famille))

@app.route('/familles_produit/<int:id_famille>/delete', methods=['POST'])
def delete_famille_produit_endpoint(id_famille):
    if delete_famille_produit(id_famille):
        flash('Famille de produit supprimée avec succès.')
    else:
        flash('Suppression de la famille de produit échouée.')
    return redirect(url_for('list_familles_produit'))


# ----------------- Fournisseur ----------------- #

class Fournisseur(db.Model):
    __tablename__ = 'Fournisseur'
    id_fournisseur = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nom = db.Column(db.String(255), nullable=False)
    adresse = db.Column(db.String(255), nullable=True)
    telephone = db.Column(db.String(255), nullable=True)
    email = db.Column(db.String(255), nullable=True)

    def __repr__(self):
        return f'<Fournisseur {self.nom}>'

def create_fournisseur(nom, adresse, telephone, email):
    fournisseur = Fournisseur(nom=nom, adresse=adresse, telephone=telephone, email=email)
    db.session.add(fournisseur)
    db.session.commit()
    return fournisseur

def get_all_fournisseurs():
    return Fournisseur.query.all()

def get_fournisseur_by_id(id_fournisseur):
    return Fournisseur.query.get(id_fournisseur)

def update_fournisseur(id_fournisseur, nom, adresse, telephone, email):
    fournisseur = Fournisseur.query.get(id_fournisseur)
    if fournisseur:
        fournisseur.nom = nom
        fournisseur.adresse = adresse
        fournisseur.telephone = telephone
        fournisseur.email = email
        db.session.commit()
        return True
    return False

def delete_fournisseur(id_fournisseur):
    fournisseur = Fournisseur.query.get(id_fournisseur)
    if fournisseur:
        db.session.delete(fournisseur)
        db.session.commit()
        return True
    return False

@app.route('/fournisseurs', methods=['POST'])
def create_fournisseur_endpoint():
    nom = request.form.get('nom')
    adresse = request.form.get('adresse')
    telephone = request.form.get('telephone')
    email = request.form.get('email')

    create_fournisseur(nom, adresse, telephone, email)
    return redirect(url_for('list_fournisseurs'))

@app.route('/fournisseurs', methods=['GET'])
def list_fournisseurs():
    fournisseurs = get_all_fournisseurs()
    return render_template('fournisseurs.html', fournisseurs=fournisseurs)

@app.route('/fournisseurs/<int:id_fournisseur>', methods=['GET'])
def get_fournisseur_endpoint(id_fournisseur):
    fournisseur = get_fournisseur_by_id(id_fournisseur)
    return render_template('fournisseur_detail.html', fournisseur=fournisseur)

@app.route('/fournisseurs/<int:id_fournisseur>', methods=['POST'])
def update_fournisseur_endpoint(id_fournisseur):
    nom = request.form.get('nom')
    adresse = request.form.get('adresse')
    telephone = request.form.get('telephone')
    email = request.form.get('email')

    if update_fournisseur(id_fournisseur, nom, adresse, telephone, email):
        flash('Fournisseur mis à jour avec succès.')
    else:
        flash('Mise à jour du fournisseur échouée.')
    return redirect(url_for('get_fournisseur_endpoint', id_fournisseur=id_fournisseur))

@app.route('/fournisseurs/<int:id_fournisseur>/delete', methods=['POST'])
def delete_fournisseur_endpoint(id_fournisseur):
    if delete_fournisseur(id_fournisseur):
        flash('Fournisseur supprimé avec succès.')
    else:
        flash('Suppression du fournisseur échouée.')
    return redirect(url_for('list_fournisseurs'))

# ----------------- Historique stock carburant ----------------- #

class HistoriqueStockCarburant(db.Model):
    __tablename__ = 'HistoriqueStockCarburant'
    id_historique = db.Column(db.Integer, primary_key=True, autoincrement=True)
    id_stock_carburant = db.Column(db.Integer, db.ForeignKey('stock_carburant.id_stock'), nullable=False)
    type_operation = db.Column(db.Enum('ajout', 'vente'), nullable=False)
    date_operation = db.Column(db.DateTime, nullable=False, default=db.func.current_timestamp())
    volume_restant = db.Column(db.Numeric(10, 2), nullable=False)

    def __repr__(self):
        return f'<HistoriqueStockCarburant {self.id_historique}>'


def create_historique_stock_carburant(id_stock_carburant, type_operation, volume_restant):
    historique = HistoriqueStockCarburant(
        id_stock_carburant=id_stock_carburant, 
        type_operation=type_operation, 
        volume_restant=volume_restant
    )
    db.session.add(historique)
    db.session.commit()
    return historique


def get_all_historique_stock_carburant():
    return HistoriqueStockCarburant.query.all()

def get_historique_stock_carburant_by_id(id_historique):
    return HistoriqueStockCarburant.query.get(id_historique)

def update_historique_stock_carburant(id_historique, id_stock_carburant, type_operation, volume_restant):
    historique = HistoriqueStockCarburant.query.get(id_historique)
    if historique:
        historique.id_stock_carburant = id_stock_carburant
        historique.type_operation = type_operation
        historique.volume_restant = volume_restant
        db.session.commit()
        return True
    return False

def delete_historique_stock_carburant(id_historique):
    historique = HistoriqueStockCarburant.query.get(id_historique)
    if historique:
        db.session.delete(historique)
        db.session.commit()
        return True
    return False


@app.route('/historique_stock_carburant', methods=['POST'])
def create_historique_stock_carburant_endpoint():
    id_stock_carburant = request.form.get('id_stock_carburant')
    type_operation = request.form.get('type_operation')
    volume_restant = request.form.get('volume_restant')

    create_historique_stock_carburant(id_stock_carburant, type_operation, volume_restant)
    return redirect(url_for('list_historique_stock_carburant'))

@app.route('/historique_stock_carburant', methods=['GET'])
def list_historique_stock_carburant():
    historiques = get_all_historique_stock_carburant()
    return render_template('historique_stock_carburant.html', historiques=historiques)

@app.route('/historique_stock_carburant/<int:id_historique>', methods=['GET'])
def get_historique_stock_carburant_endpoint(id_historique):
    historique = get_historique_stock_carburant_by_id(id_historique)
    return render_template('historique_stock_carburant_detail.html', historique=historique)

@app.route('/historique_stock_carburant/<int:id_historique>/delete', methods=['POST'])
def delete_historique_stock_carburant_endpoint(id_historique):
    if delete_historique_stock_carburant(id_historique):
        flash('Entrée d\'historique de stock de carburant supprimée avec succès.')
    else:
        flash('Suppression de l\'entrée d\'historique de stock de carburant échouée.')
    return redirect(url_for('list_historique_stock_carburant'))


# ----------------- Historique sotck Produit ----------------- #

class HistoriqueStockProduit(db.Model):
    __tablename__ = 'HistoriqueStockProduit'
    id_historique = db.Column(db.Integer, primary_key=True, autoincrement=True)
    id_stock_produit = db.Column(db.Integer, db.ForeignKey('StockProduits.id_stock_produit'), nullable=False)
    type_operation = db.Column(db.Enum('ajout', 'vente'), nullable=False)
    date_operation = db.Column(db.DateTime, nullable=False, default=db.func.current_timestamp())
    quantite_restante = db.Column(db.Numeric(10, 2), nullable=False)

    def __repr__(self):
        return f'<HistoriqueStockProduit {self.id_historique}>'


# Create
def create_historique_stock_produit(id_stock_produit, type_operation, quantite_restante):
    historique = HistoriqueStockProduit(
        id_stock_produit=id_stock_produit,
        type_operation=type_operation,
        quantite_restante=quantite_restante
    )
    db.session.add(historique)
    db.session.commit()
    return historique


def get_all_historique_stock_produit():
    return HistoriqueStockProduit.query.all()

def get_historique_stock_produit_by_id(id_historique):
    return HistoriqueStockProduit.query.get(id_historique)

def update_historique_stock_produit(id_historique, id_stock_produit, type_operation, quantite_restante):
    historique = HistoriqueStockProduit.query.get(id_historique)
    if historique:
        historique.id_stock_produit = id_stock_produit
        historique.type_operation = type_operation
        historique.quantite_restante = quantite_restante
        db.session.commit()
        return True
    return False

def delete_historique_stock_produit(id_historique):
    historique = HistoriqueStockProduit.query.get(id_historique)
    if historique:
        db.session.delete(historique)
        db.session.commit()
        return True
    return False

@app.route('/historique_stock_produit', methods=['POST'])
def create_historique_stock_produit_endpoint():
    id_stock_produit = request.form.get('id_stock_produit')
    type_operation = request.form.get('type_operation')
    quantite_restante = request.form.get('quantite_restante')

    create_historique_stock_produit(id_stock_produit, type_operation, quantite_restante)
    return redirect(url_for('list_historique_stock_produit'))

@app.route('/historique_stock_produit', methods=['GET'])
def list_historique_stock_produit():
    historiques = get_all_historique_stock_produit()
    return render_template('historique_stock_produit.html', historiques=historiques)

@app.route('/historique_stock_produit/<int:id_historique>', methods=['GET'])
def get_historique_stock_produit_endpoint(id_historique):
    historique = get_historique_stock_produit_by_id(id_historique)
    return render_template('historique_stock_produit_detail.html', historique=historique)

@app.route('/historique_stock_produit/<int:id_historique>/delete', methods=['POST'])
def delete_historique_stock_produit_endpoint(id_historique):
    if delete_historique_stock_produit(id_historique):
        flash('Entrée d\'historique de stock de produit supprimée avec succès.')
    else:
        flash('Suppression de l\'entrée d\'historique de stock de produit échouée.')
    return redirect(url_for('list_historique_stock_produit'))

# ----------------- Incident ----------------- #

class Incident(db.Model):
    __tablename__ = 'Incidents'
    id_incident = db.Column(db.Integer, primary_key=True, autoincrement=True)
    id_employe = db.Column(db.Integer, db.ForeignKey('Employe.id_employe'), nullable=True)
    id_personne_contactee = db.Column(db.Integer, nullable=True)
    date_heure = db.Column(db.DateTime, nullable=False, default=db.func.current_timestamp())
    type = db.Column(db.String(255), nullable=False)
    detail_technique = db.Column(db.String(255), nullable=True)
    autres_remarques = db.Column(db.String(255), nullable=True)
    solution_apportee = db.Column(db.String(255), nullable=True)
    date_heure_solution = db.Column(db.DateTime, nullable=True)
    niveau = db.Column(db.Integer, nullable=False)
    a_traiter = db.Column(db.Integer, nullable=False, default=(niveau==3))

    def __repr__(self):
        return f'<Incident {self.id_incident}>'


@app.route('/incidents', methods=['GET'])
def get_incidents():
    incidents = Incident.query.all()
    incidents_list = []
    for incident in incidents:
        incident_data = {
            'id_incident': incident.id_incident,
            'id_employe': incident.id_employe,
            'id_personne_contactee': incident.id_personne_contactee,
            'niveau': incident.niveau,
            'date_heure': incident.date_heure.strftime('%Y-%m-%d %H:%M:%S') if incident.date_heure else None,  # Vérifiez si date_heure est None
            'type': incident.type,
            'detail_technique': incident.detail_technique,
            'autres_remarques': incident.autres_remarques,
            'solution_apportee': incident.solution_apportee,
            'date_heure_solution': incident.date_heure_solution.strftime('%Y-%m-%d %H:%M:%S') if incident.date_heure_solution else None,  # Formatage de la date et heure de solution
            'a_traiter': incident.a_traiter
        }
        incidents_list.append(incident_data)
    return jsonify({'incidents': incidents_list})

def create_incident(id_employe, id_personne_contactee, type, detail_technique, autres_remarques, solution_apportee):
    incident = Incident(
        id_employe=id_employe,
        id_personne_contactee=id_personne_contactee,
        type=type,
        detail_technique=detail_technique,
        autres_remarques=autres_remarques,
        solution_apportee=solution_apportee
    )
    db.session.add(incident)
    db.session.commit()
    return incident


def get_all_incidents():
    return Incident.query.all()


def get_incident_by_id(id_incident):
    return Incident.query.get(id_incident)


def update_incident(id_incident, id_employe, id_personne_contactee, type, detail_technique, autres_remarques, solution_apportee, date_heure_solution):
    incident = Incident.query.get(id_incident)
    if incident:
        incident.id_employe = id_employe
        incident.id_personne_contactee = id_personne_contactee
        incident.type = type
        incident.detail_technique = detail_technique
        incident.autres_remarques = autres_remarques
        incident.solution_apportee = solution_apportee
        incident.date_heure_solution = date_heure_solution
        db.session.commit()
        return True
    return False

def delete_incident(id_incident):
    incident = Incident.query.get(id_incident)
    if incident:
        db.session.delete(incident)
        db.session.commit()
        return True
    return False


@app.route('/incidents', methods=['POST'])
def create_incident_endpoint():
    id_employe = request.form.get('id_employe')
    id_personne_contactee = request.form.get('id_personne_contactee')
    type = request.form.get('type')
    detail_technique = request.form.get('detail_technique')
    autres_remarques = request.form.get('autres_remarques')
    solution_apportee = request.form.get('solution_apportee')
    create_incident(id_employe, id_personne_contactee, type, detail_technique, autres_remarques, solution_apportee)
    return redirect(url_for('list_incidents'))


@app.route('/incidents', methods=['GET'])
def list_incidents():
    incidents = get_all_incidents()
    return render_template('incidents.html', incidents=incidents)

@app.route('/incidents/int:id_incident', methods=['GET'])
def get_incident_endpoint(id_incident):
    incident = get_incident_by_id(id_incident)
    return render_template('incident_detail.html', incident=incident)

@app.route('/incidents/int:id_incident', methods=['POST'])
def update_incident_endpoint(id_incident):
    id_employe = request.form.get('id_employe')
    id_personne_contactee = request.form.get('id_personne_contactee')
    type = request.form.get('type')
    detail_technique = request.form.get('detail_technique')
    autres_remarques = request.form.get('autres_remarques')
    solution_apportee = request.form.get('solution_apportee')
    date_heure_solution = request.form.get('date_heure_solution') # Assurez-vous de convertir cette donnée en timestamp
    if update_incident(id_incident, id_employe, id_personne_contactee, type, detail_technique, autres_remarques, solution_apportee, date_heure_solution):
        flash('Incident mis à jour avec succès.')
    else:
        flash('Mise à jour de l\'incident échouée.')
    return redirect(url_for('get_incident_endpoint', id_incident=id_incident))


@app.route('/incidents/int:id_incident/delete', methods=['POST'])
def delete_incident_endpoint(id_incident):
    if delete_incident(id_incident):
        flash('Incident supprimé avec succès.')
    else:
        flash('Suppression de l\'incident échouée.')
    return redirect(url_for('list_incidents'))

# ----------------- Ligne bon réappro ----------------- #

class LigneBonReapprovisionnement(db.Model):
    __tablename__ = 'LigneBonReapprovisionnement'
    id_br = db.Column(db.Integer, db.ForeignKey('bon_reapprovisionnement.id_br'), primary_key=True)
    id_produit = db.Column(db.Integer, db.ForeignKey('produit.id_produit'), primary_key=True)
    quantite = db.Column(db.Numeric(10, 2), nullable=False)
    prix_a_payer = db.Column(db.Numeric(10, 2), nullable=False)

    def __repr__(self):
        return f'<LigneBonReapprovisionnement {self.id_br} {self.id_produit}>'


def create_ligne_bon_reapprovisionnement(id_br, id_produit, quantite, prix_a_payer):
    ligne = LigneBonReapprovisionnement(id_br=id_br, id_produit=id_produit, quantite=quantite, prix_a_payer=prix_a_payer)
    db.session.add(ligne)
    db.session.commit()
    return ligne

def get_all_lignes_bon_reapprovisionnement():
    return LigneBonReapprovisionnement.query.all()


def get_ligne_bon_reapprovisionnement_by_id(id_br, id_produit):
    return LigneBonReapprovisionnement.query.get((id_br, id_produit))

def update_ligne_bon_reapprovisionnement(id_br, id_produit, quantite, prix_a_payer):
    ligne = LigneBonReapprovisionnement.query.get((id_br, id_produit))
    if ligne:
        ligne.quantite = quantite
        ligne.prix_a_payer = prix_a_payer
        db.session.commit()
        return True
    return False

def delete_ligne_bon_reapprovisionnement(id_br, id_produit):
    ligne = LigneBonReapprovisionnement.query.get((id_br, id_produit))
    if ligne:
        db.session.delete(ligne)
        db.session.commit()
        return True
    return False


# ----------------- Produit ----------------- #


def create_produit(id_famille, id_fournisseur, nom, description, prix_vente, prix_achat, seuil_alerte):
    produit = Produit(id_famille=id_famille, id_fournisseur=id_fournisseur, nom=nom,
                      description=description, prix_vente=prix_vente, prix_achat=prix_achat,
                      seuil_alerte=seuil_alerte)
    db.session.add(produit)
    db.session.commit()
    return produit

def get_all_produits():
    return Produit.query.all()


@app.route('/get_products')
def get_products():
    products = Produit.query.all()
    products_json = [{
        'id_produit': product.id_produit,
        'id_famille': product.id_famille,
        'id_fournisseur': product.id_fournisseur,
        'nom': product.nom,
        'description': product.description,
        'prix_vente': product.prix_vente,
        'prix_achat': product.prix_achat,
        'seuil_alerte': product.seuil_alerte
    } for product in products]
    return jsonify(products_json)


def get_produit_by_id(id_produit):
    return Produit.query.get(id_produit)

# def update_produit(id_produit, id_famille, id_fournisseur, nom, description, prix_vente, prix_achat, seuil_alerte):
#     produit = Produit.query.get(id_produit)
#     if produit:
#         produit.id_famille = id_famille
#         produit.id_fournisseur = id_fournisseur
#         produit.nom = nom
#         produit.description = description
#         produit.prix_vente = prix_vente
#         produit.prix_achat = prix_achat
#         produit.seuil_alerte = seuil_alerte
#         db.session.commit()
#         return True
#     return False

@app.route('/update_product', methods=['POST'])
def update_produit():
    data = request.get_json()
    print("Données reçues:", data)
    if data:
        id_produit = data.get('product-id')
        produit = Produit.query.get(id_produit)
        if produit:
            produit.nom = data.get('product-name')
            produit.description = data.get('product-description')
            produit.prix_vente = data.get('selling-price')
            produit.prix_achat = data.get('purchase-price')
            produit.seuil_alerte = data.get('alert-threshold')
            produit.id_fournisseur = data.get('fournissor')  
            db.session.commit()
            return jsonify({
                'success': True,
                'updatedProduct': {
                    'product-id': produit.id_produit,
                    'product-name': produit.nom,
                    'product-description': produit.description,
                    'purchase-price': produit.prix_achat,
                    'selling-price': produit.prix_vente,
                    'alert-threshold': produit.seuil_alerte,
                    'fournissor': produit.id_fournisseur 
                }
            })
    return jsonify({'success': False})

# def delete_produit(id_produit):
#     produit = Produit.query.get(id_produit)
#     if produit:
#         db.session.delete(produit)
#         db.session.commit()
#         return True
#     return False


@app.route('/delete_product/<int:id_produit>', methods=['DELETE'])
def delete_produit(id_produit):
    # Vérifiez d'abord si le produit existe
    produit = Produit.query.get(id_produit)
    if produit:
        try:
            # Trouvez d'abord tous les stock liés au produit
            stocks = StockProduit.query.filter_by(id_produit=id_produit).all()
            for stock in stocks:
                # Supprimez les entrées d'historique liées à chaque stock
                HistoriqueStockProduit.query.filter_by(id_stock_produit=stock.id_stock_produit).delete()
            
            # Supprimez ensuite les stocks eux-mêmes (si nécessaire)
            StockProduit.query.filter_by(id_produit=id_produit).delete()

            # Enfin, supprimez le produit lui-même
            db.session.delete(produit)
            db.session.commit()
            
            return jsonify({'success': True, 'message': 'Produit et historiques associés supprimés avec succès.'})
        except Exception as e:
            # En cas d'erreur, annulez les opérations de suppression et renvoyez un message d'erreur
            db.session.rollback()
            return jsonify({'success': False, 'message': str(e)}), 500
    else:
        return jsonify({'success': False, 'message': 'Produit introuvable.'}), 404

@app.route('/produit/create', methods=['POST'])
def create_produit_endpoint():
    id_famille = request.form['id_famille']
    id_fournisseur = request.form['id_fournisseur']
    nom = request.form['nom']
    description = request.form['description']
    prix_vente = request.form['prix_vente']
    prix_achat = request.form['prix_achat']
    seuil_alerte = request.form['seuil_alerte']

    produit = create_produit(id_famille, id_fournisseur, nom, description, prix_vente, prix_achat, seuil_alerte)
    return redirect(url_for('get_produit_endpoint', id_produit=produit.id_produit))


@app.route('/ajouter_product', methods=['POST'])
def ajouter_product():
    data = request.get_json()
    print(data)
    if not data:
        return jsonify({"error": "Aucune donnée fournie"}), 400
    try:
        new_product = Produit(
            id_famille=999, 
            id_fournisseur=data.get('fournissor-create'),
            nom=data.get('product-name-create'),
            description=data.get('product-description-create'),
            prix_vente=data.get('purchase-price-create'),
            prix_achat=data.get('selling-price-create'),
            seuil_alerte=data.get('alert-threshold-create')
        )
        db.session.add(new_product)
        db.session.commit()

        # Retourner une réponse en cas de succès
        return jsonify({"message": "Produit ajouté avec succès!", "id_produit": new_product.id_produit}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 400

# @app.route('/produit', methods=['GET'])
# def list_produit_endpoint():
#     produits = get_all_produits()
#     return render_template('produits_list.html', produits=produits)

@app.route('/produit/<int:id_produit>', methods=['GET'])
def get_produit_endpoint(id_produit):
    produit = get_produit_by_id(id_produit)
    return render_template('produit_detail.html', produit=produit)

@app.route('/produit/update/<int:id_produit>', methods=['POST'])
def update_produit_endpoint(id_produit):
    data = request.get_json()  # Récupère les données JSON

    produit = Produit.query.get(id_produit)
    if not produit:
        return jsonify({'success': False, 'message': 'Produit non trouvé.'}), 404
    
    for attr in ['id_famille', 'id_fournisseur', 'nom', 'description']:
        if attr in data:
            setattr(produit, attr, data[attr])

    # Mise à jour des attributs numériques avec vérification
    for attr in ['prix_vente', 'prix_achat', 'seuil_alerte']:
        if attr in data and data[attr] is not None:
            try:
                setattr(produit, attr, Decimal(data[attr]))
            except (ValueError, InvalidOperation):
                return jsonify({'success': False, 'message': f'Valeur invalide pour {attr}.'}), 400

    quantite_stock = data.get('quantite_stock')
    if quantite_stock is not None:
        stock_produit = StockProduit.query.filter_by(id_produit=id_produit).first()
        if stock_produit is None:
            # Si le stock n'existe pas, créez-le avec la date actuelle et la quantité fournie
            stock_produit = StockProduit(
                id_produit=id_produit,
                date_stock=datetime.utcnow().date(),  # Utilisez datetime.now().date() si vous voulez la date locale
                quantite_stock=Decimal(quantite_stock)
            )
            db.session.add(stock_produit)
        else:
            # Si le stock existe déjà, mettez simplement à jour la quantité
            try:
                stock_produit.quantite_stock = Decimal(quantite_stock)
            except (ValueError, InvalidOperation):
                return jsonify({'success': False, 'message': 'Quantité de stock invalide.'}), 400

    db.session.commit()
    return jsonify({'success': True, 'message': 'Produit et stock mis à jour avec succès.'})


@app.route('/produit/delete/<int:id_produit>', methods=['POST'])
def delete_produit_endpoint(id_produit):
    if delete_produit(id_produit):
        flash('Produit supprimé avec succès.')
    else:
        flash('Suppression du produit échouée.')
    return redirect(url_for('list_produit_endpoint'))


def get_produits_groupes_par_famille_2():
    produits = Produit.query.all()
    produits_par_famille = {}
    for produit in produits:
        famille_obj = FamilleProduit.query.get(produit.id_famille)
        #Gére le cas oo la famille n'est pas trouvée
        if famille_obj:
            type_famille = famille_obj.type_famille
            if type_famille not in produits_par_famille:
                produits_par_famille[type_famille] = []
            produits_par_famille[type_famille].append(produit)
        else:
            type_famille = 'Inconnue'
            if type_famille not in produits_par_famille:
                produits_par_famille[type_famille] = []
            produits_par_famille[type_famille].append(produit)
    return produits_par_famille




def get_stocks_produits_groupes_par_famille():
    produits = Produit.query.all()
    produits_par_famille = {}
    for produit in produits:
        stock = StockProduit.query.filter_by(id_produit=produit.id_produit).first()
        famille_obj = FamilleProduit.query.get(produit.id_famille)

        if famille_obj:
            type_famille = famille_obj.type_famille
        else:
            type_famille = 'Inconnue'

        if type_famille not in produits_par_famille:
            produits_par_famille[type_famille] = []

        produit_info = {
            'id_produit': produit.id_produit,
            'nom': produit.nom,
            'description': produit.description,
            'prix_vente': str(produit.prix_vente),
            'prix_achat': str(produit.prix_achat),
            'seuil_alerte': str(produit.seuil_alerte),
            'quantite_stock': str(stock.quantite_stock) if stock else '0'
        }

        produits_par_famille[type_famille].append(produit_info)

    return produits_par_famille

# --------------- Services ------------ #

class Service(db.Model):
    __tablename__ = 'Services'
    id_service = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nom = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    prix = db.Column(db.Numeric(10, 2), nullable=False)

    def __repr__(self):
        return f'<Service {self.nom}>'

def create_service(nom, description, prix):
    service = Service(nom=nom, description=description, prix=prix)
    db.session.add(service)
    db.session.commit()
    return service

def get_all_services():
    return Service.query.all()

def get_service_by_id(id_service):
    return Service.query.get(id_service)

def update_service(id_service, nom, description, prix):
    service = Service.query.get(id_service)
    if service:
        service.nom = nom
        service.description = description
        service.prix = prix
        db.session.commit()
        return True
    return False

def delete_service(id_service):
    service = Service.query.get(id_service)
    if service:
        db.session.delete(service)
        db.session.commit()
        return True
    return False


@app.route('/services/create', methods=['POST'])
def create_service_endpoint():
    nom = request.form.get('nom')
    description = request.form.get('description')
    prix = request.form.get('prix')

    service = create_service(nom, description, prix)
    return redirect(url_for('get_service_endpoint', id_service=service.id_service))

@app.route('/services', methods=['GET'])
def list_services_endpoint():
    services = get_all_services()
    return render_template('services_list.html', services=services)

@app.route('/services/<int:id_service>', methods=['GET'])
def get_service_endpoint(id_service):
    service = get_service_by_id(id_service)
    return render_template('service_detail.html', service=service)

@app.route('/services/update/<int:id_service>', methods=['POST'])
def update_service_endpoint(id_service):
    nom = request.form.get('nom')
    description = request.form.get('description')
    prix = request.form.get('prix')

    if update_service(id_service, nom, description, prix):
        flash('Service mis à jour avec succès.')
    else:
        flash('Mise à jour du service échouée.')
    return redirect(url_for('get_service_endpoint', id_service=id_service))

@app.route('/services/delete/<int:id_service>', methods=['POST'])
def delete_service_endpoint(id_service):
    if delete_service(id_service):
        flash('Service supprimé avec succès.')
    else:
        flash('Suppression du service échouée.')
    return redirect(url_for('list_services_endpoint'))


# ------------- StockCarburant ----------------#

class StockCarburant(db.Model):
    __tablename__ = 'StockCarburant'
    id_stock_carburant = db.Column(db.Integer, primary_key=True)
    id_carburant = db.Column(db.Integer, db.ForeignKey('carburant.id_carburant'), nullable=False)
    date_stock = db.Column(db.Date, nullable=False)
    volume_dispo = db.Column(db.Numeric(10, 2), nullable=False)

    def __repr__(self):
        return f'<StockCarburant id_carburant={self.id_carburant} date_stock={self.date_stock}>'


def create_stock_carburant(id_carburant, date_stock, volume_dispo):
    stock = StockCarburant(id_carburant=id_carburant, date_stock=date_stock, volume_dispo=volume_dispo)
    db.session.add(stock)
    db.session.commit()
    return stock

def get_all_stock_carburant():
    return StockCarburant.query.all()

def get_stock_carburant_by_id(id_stock_carburant):
    return StockCarburant.query.get(id_stock_carburant)

def update_stock_carburant(id_stock_carburant, id_carburant, date_stock, volume_dispo):
    stock = StockCarburant.query.get(id_stock_carburant)
    if stock:
        stock.id_carburant = id_carburant
        stock.date_stock = date_stock
        stock.volume_dispo = volume_dispo
        db.session.commit()
        return True
    return False

def delete_stock_carburant(id_stock_carburant):
    stock = StockCarburant.query.get(id_stock_carburant)
    if stock:
        db.session.delete(stock)
        db.session.commit()
        return True
    return False


@app.route('/stock_carburant/create', methods=['POST'])
def create_stock_carburant_endpoint():
    id_carburant = request.form.get('id_carburant')
    date_stock = request.form.get('date_stock')  # Convertir en date si nécessaire
    volume_dispo = request.form.get('volume_dispo')

    stock = create_stock_carburant(id_carburant, date_stock, volume_dispo)
    return redirect(url_for('get_stock_carburant', id_stock_carburant=stock.id_stock_carburant))

@app.route('/stock_carburant', methods=['GET'])
def list_stock_carburant_endpoint():
    stocks = get_all_stock_carburant()
    return render_template('stock_carburant_list.html', stocks=stocks)

@app.route('/stock_carburant/<int:id_stock_carburant>', methods=['GET'])
def get_stock_carburant_endpoint(id_stock_carburant):
    stock = get_stock_carburant_by_id(id_stock_carburant)
    return render_template('stock_carburant_detail.html', stock=stock)

@app.route('/stock_carburant/update/<int:id_stock_carburant>', methods=['POST'])
def update_stock_carburant_endpoint(id_stock_carburant):
    id_carburant = request.form.get('id_carburant')
    date_stock = request.form.get('date_stock')  # Convertir en date si nécessaire
    volume_dispo = request.form.get('volume_dispo')

    if update_stock_carburant(id_stock_carburant, id_carburant, date_stock, volume_dispo):
        flash('Stock de carburant mis à jour avec succès.')
    else:
        flash('Mise à jour du stock de carburant échouée.')
    return redirect(url_for('get_stock_carburant_endpoint', id_stock_carburant=id_stock_carburant))

@app.route('/stock_carburant/delete/<int:id_stock_carburant>', methods=['POST'])
def delete_stock_carburant_endpoint(id_stock_carburant):
    if delete_stock_carburant(id_stock_carburant):
        flash('Stock de carburant supprimé avec succès.')
    else:
        flash('Suppression du stock de carburant échouée.')
    return redirect(url_for('list_stock_carburant_endpoint'))


# -------------- StockProduit ----------------

class StockProduit(db.Model):
    __tablename__ = 'StockProduits'
    id_stock_produit = db.Column(db.Integer, primary_key=True)
    id_produit = db.Column(db.Integer, db.ForeignKey('Produit.id_produit'), nullable=False)
    date_stock = db.Column(db.Date, nullable=False)
    quantite_stock = db.Column(db.Numeric(10, 2), nullable=False)

    def __repr__(self):
        return f'<StockProduit {self.id_stock_produit}>'


def create_stock_produit(id_produit, date_stock, quantite_stock):
    stock_produit = StockProduit(id_produit=id_produit, date_stock=date_stock, quantite_stock=quantite_stock)
    db.session.add(stock_produit)
    db.session.commit()
    return stock_produit

def get_all_stock_produit():
    return StockProduit.query.all()

def get_stock_produit_by_id(id_stock_produit):
    return StockProduit.query.get(id_stock_produit)

def update_stock_produit(id_stock_produit, id_produit, date_stock, quantite_stock):
    stock_produit = StockProduit.query.get(id_stock_produit)
    if stock_produit:
        stock_produit.id_produit = id_produit
        stock_produit.date_stock = date_stock
        stock_produit.quantite_stock = quantite_stock
        db.session.commit()
        return True
    return False

def delete_stock_produit(id_stock_produit):
    stock_produit = StockProduit.query.get(id_stock_produit)
    if stock_produit:
        db.session.delete(stock_produit)
        db.session.commit()
        return True
    return False


@app.route('/stock_produit/create', methods=['POST'])
def create_stock_produit_endpoint():
    id_produit = request.form.get('id_produit')
    date_stock = request.form.get('date_stock')  # Convertir en date si nécessaire
    quantite_stock = request.form.get('quantite_stock')

    stock_produit = create_stock_produit(id_produit, date_stock, quantite_stock)
    return redirect(url_for('get_stock_produit_endpoint', id_stock_produit=stock_produit.id_stock_produit))

@app.route('/stock_produit', methods=['GET'])
def list_stock_produit_endpoint():
    stock_produits = get_all_stock_produit()
    return render_template('stock_produit_list.html', stock_produits=stock_produits)

@app.route('/stock_produit/<int:id_stock_produit>', methods=['GET'])
def get_stock_produit_endpoint(id_stock_produit):
    stock_produit = get_stock_produit_by_id(id_stock_produit)
    return render_template('stock_produit_detail.html', stock_produit=stock_produit)

@app.route('/stock_produit/update/<int:id_stock_produit>', methods=['POST'])
def update_stock_produit_endpoint(id_stock_produit):
    id_produit = request.form.get('id_produit')
    date_stock = request.form.get('date_stock')  # Convertir en date si nécessaire
    quantite_stock = request.form.get('quantite_stock')

    if update_stock_produit(id_stock_produit, id_produit, date_stock, quantite_stock):
        flash('Stock produit mis à jour avec succès.')
    else:
        flash('Mise à jour du stock produit échouée.')
    return redirect(url_for('get_stock_produit_endpoint', id_stock_produit=id_stock_produit))

@app.route('/stock_produit/delete/<int:id_stock_produit>', methods=['POST'])
def delete_stock_produit_endpoint(id_stock_produit):
    if delete_stock_produit(id_stock_produit):
        flash('Stock produit supprimé avec succès.')
    else:
        flash('Suppression du stock produit échouée.')
    return redirect(url_for('list_stock_produit_endpoint'))


@app.route('/produits')
def afficher_produits():
    produits_par_famille = get_produits_groupes_par_famille()
    return render_template('afficher_produits.html', produits_par_famille=produits_par_famille)

@app.route('/test')
def test_page():
    produits_par_famille = get_produits_groupes_par_famille()
    return render_template('test.html', produits_par_famille=produits_par_famille)


# ------------------------- Transaction --------------------------- #

class Transaction(db.Model):
    __tablename__ = 'Transactions'
    id_transaction = db.Column(db.Integer, primary_key=True)
    id_employe = db.Column(db.Integer, db.ForeignKey('Employe.id_employe'), nullable=False)
    id_client = db.Column(db.Integer, db.ForeignKey('Client.id_client'), nullable=False)
    date_heure_transaction = db.Column(db.DateTime, nullable=False)
    type_paiement = db.Column(db.Enum('CB', 'ESP', 'CS'), nullable=False)
    montant_total = db.Column(db.Numeric(10, 2), nullable=False)
    verif = db.Column(db.Boolean, default=False, nullable=False)


    def __repr__(self):
        return f'<Transaction {self.id_transaction}>'

def create_transaction(id_employe, id_client, date_heure_transaction, type_paiement, montant_total,verif=False):
    new_transaction = Transaction(
        id_employe=id_employe,
        id_client=id_client,
        date_heure_transaction=date_heure_transaction,
        type_paiement=type_paiement,
        montant_total=montant_total,
        verif=verif
    )
    db.session.add(new_transaction)
    db.session.commit()
    return new_transaction

def get_all_transactions():
    return Transaction.query.all()

def get_transaction_by_id(id_transaction):
    return Transaction.query.get(id_transaction)

def update_transaction(id_transaction, id_employe, id_client, date_heure_transaction, type_paiement, montant_total, verif=None):
    transaction = get_transaction_by_id(id_transaction)
    if transaction:
        transaction.id_employe = id_employe
        transaction.id_client = id_client
        transaction.date_heure_transaction = date_heure_transaction
        transaction.type_paiement = type_paiement
        transaction.montant_total = montant_total
        transaction.verif = verif
        db.session.commit()
        return True
    return False

def delete_transaction(id_transaction):
    transaction = get_transaction_by_id(id_transaction)
    if transaction:
        db.session.delete(transaction)
        db.session.commit()
        return True
    return False


"""@app.route('/transactions/create', methods=['POST'])
def create_transaction_endpoint():
    id_employe = request.form.get('id_employe')
    id_client = request.form.get('id_client')
    date_heure_transaction = request.form.get('date_heure_transaction')  # Convertir en date si nécessaire
    type_paiement = request.form.get('type_paiement')
    montant_total = request.form.get('montant_total')

    transaction = create_transaction(id_employe, id_client, date_heure_transaction, type_paiement, montant_total)
    return redirect(url_for('get_transaction', id_transaction=transaction.id_transaction))"""

@app.route('/transactions', methods=['GET'])
def list_transactions_endpoint():
    transactions = get_all_transactions()
    return render_template('transactions_list.html', transactions=transactions)

@app.route('/transactions/<int:id_transaction>', methods=['GET'])
def get_transaction_endpoint(id_transaction):
    transaction = get_transaction_by_id(id_transaction)
    return render_template('transaction_detail.html', transaction=transaction)

@app.route('/transactions/update/<int:id_transaction>', methods=['POST'])
def update_transaction_endpoint(id_transaction):
    id_employe = request.form.get('id_employe')
    id_client = request.form.get('id_client')
    date_heure_transaction = request.form.get('date_heure_transaction')  # Convertir en date si nécessaire
    type_paiement = request.form.get('type_paiement')
    montant_total = request.form.get('montant_total')

    if update_transaction(id_transaction, id_employe, id_client, date_heure_transaction, type_paiement, montant_total):
        flash('Transaction mise à jour avec succès.')
    else:
        flash('Mise à jour de la transaction échouée.')
    return redirect(url_for('get_transaction', id_transaction=id_transaction))

@app.route('/transactions/delete/<int:id_transaction>', methods=['POST'])
def delete_transaction_endpoint(id_transaction):
    if delete_transaction(id_transaction):
        flash('Transaction supprimée avec succès.')
    else:
        flash('Suppression de la transaction échouée.')
    return redirect(url_for('list_transactions_endpoint'))


@app.route('/admin/daily-transactions', methods=['GET'])
def admin_daily_transactions():
    today = datetime.now().date()
    tomorrow = today + timedelta(days=1)
    transactions = Transaction.query.filter(
        Transaction.date_heure_transaction >= today,
        Transaction.date_heure_transaction < tomorrow
    ).order_by(Transaction.date_heure_transaction.desc()).all()
    
    return render_template('admin.html', transactions=transactions)

@app.route('/api/daily-transactions')
def api_daily_transactions():
    today = datetime.now().date()
    transactions = Transaction.query.filter(
        db.func.date(Transaction.date_heure_transaction) == today
    ).all()

    transactions_data = [{
        'id_transaction': t.id_transaction,
        'date_heure_transaction': t.date_heure_transaction.strftime('%Y-%m-%d %H:%M'),
        'montant_total': str(t.montant_total),
        'type_paiement': t.type_paiement
        # Vous pouvez ajouter d'autres champs si nécessaire
    } for t in transactions]

    return jsonify(transactions_data)



@app.route('/register', methods=['POST'])
def register_client_and_card():
    nom = request.form.get('nom')
    prenom = request.form.get('prenom')
    email = request.form.get('email')
    adresse = request.form.get('adresse')
    code_secret = "101"
    
    new_client = create_client(nom, prenom, email, adresse, code_secret)
    new_card = create_carte_station(new_client.id_client, datetime.utcnow(), 0, 0, 'active')
    
    return "Inscription réussie!"
#--------------------------------


"""@app.route('/valider_BonVente', methods=['POST'])
def valider_bon_vente():
    if not request.is_json:
        return jsonify({'error': 'Invalid content type, expecting application/json'}), 400

    data = request.get_json()
    items = data.get('items')
    total = data.get('total')

    if items is None or total is None:
        return jsonify({'error': 'Missing items or total'}), 400

    try:
        ticket = create_ticket(items, total)
        formatted_total = format_total(total)
        update_cash_register(formatted_total)
        return jsonify({'success': True, 'message': 'Ticket validé avec succès', 'total': formatted_total})
    except Exception as e:
        return jsonify({'error': 'Erreur lors de la validation du bon de vente', 'details': str(e)}), 500"""

def format_total(total):
    """Formatte le total à payer au format XX.XX."""
    return str(Decimal(total).quantize(Decimal('.01'), rounding=ROUND_HALF_UP))

def create_ticket(items, total):
    # Ici, vous pouvez ajouter votre logique pour la création du ticket
    # Par exemple, sauvegarder les informations dans une base de données
    print("Création du ticket avec les articles suivants :", items)
    # Simule la sauvegarde et retourne un ID de ticket ou un objet ticket
    return {"id_ticket": 123, "items": items, "total": total}

def update_cash_register(amount):
    # Met à jour le montant total dans la caisse
    # Cette fonction doit être définie selon la logique spécifique de votre caisse
    print(f"Mise à jour de la caisse avec le montant {amount}")


@app.route('/transactions/create', methods=['POST'])
def create_transaction_endpoint():
    id_employe = 1 #statique pour le moment
    id_client = 8 #statique pour le moment
    data = request.get_json()
    type_paiement = data.get('type_paiement')
    montant_total_str = data.get('montant_total')
    
    try:
        montant_total = float(montant_total_str)
        date_heure_transaction = datetime.now()

        print(f"Création d'une transaction :")
        print(f"id_employe: {id_employe}, id_client: {id_client}, date_heure_transaction: {date_heure_transaction}, type_paiement: {type_paiement}, montant_total: {montant_total}")

        transaction = create_transaction(id_employe, id_client, date_heure_transaction, type_paiement, montant_total)
        return jsonify({'success': True, 'message': 'Transaction ajoutée avec succès', 'id_transaction': transaction.id_transaction}), 200
    except SQLAlchemyError as e:
        print(f"Création d'une transaction :")
        print(f"id_employe: {id_employe}, id_client: {id_client}, date_heure_transaction: {date_heure_transaction}, type_paiement: {type_paiement}, montant_total: {montant_total}")
        print(e)
        return jsonify({'success': False, 'message': 'Erreur lors de la création de la transaction', 'error': str(e)}), 500

"""
@app.route('/transactions/create', methods=['POST'])
def create_transaction_endpoint():
    data = request.get_json()
    
    # Conversion et validation des données reçues
    try:
        type_paiement = data['type_paiement']
        montant_total = Decimal(data['montant_total'])
        id_employe = 1
        id_client = 8

        # Création de l'objet transaction
        new_transaction = Transaction(
            id_employe=id_employe,
            id_client=id_client,
            date_heure_transaction=datetime.now(),
            type_paiement=type_paiement,
            montant_total=montant_total
        )
        print(f"Création d'une transaction :")
        print(f"id_employe: {id_employe}, id_client: {id_client}, date_heure_transaction: {datetime.now()}, type_paiement: {type_paiement}, montant_total: {montant_total}")
        
        db.session.add(new_transaction)
        db.session.commit()
        return jsonify({'success': True, 'id_transaction': new_transaction.id_transaction}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Erreur lors de la création de la transaction', 'message': str(e)}), 500
"""

@app.route('/update_stock', methods=['POST'])
def update_stock_endpoint():
    data = request.get_json()
    stock_updates = data.get('updates', [])
    
    try:
        for update in stock_updates:
            id_produit = update.get('id_produit')
            quantite_vendue = update.get('quantite')
            
            # Mettre à jour StockProduits sans vérifier si la quantité en stock est suffisante
            stock_produit = StockProduit.query.filter_by(id_produit=id_produit).first()
            if stock_produit:
                stock_produit.quantite_stock -= quantite_vendue  # Mise à jour directe
                db.session.add(stock_produit)
                
                # Ajouter un enregistrement dans HistoriqueStockProduit
                new_historique = HistoriqueStockProduit(
                    id_stock_produit=stock_produit.id_stock_produit,
                    type_operation='vente',
                    quantite_restante=stock_produit.quantite_stock
                )
                db.session.add(new_historique)
            else:
                raise ValueError('Produit introuvable')
        
        db.session.commit()
        return jsonify({'success': True, 'message': 'Stock mis à jour avec succès'}), 200
    except Exception as e:
        db.session.rollback()
        print(e)
        return jsonify({'success': False, 'message': 'Erreur lors de la mise à jour du stock', 'error': str(e)}), 500


@app.route('/api/transactions/last24hours')
def transactions_last_24_hours():
    time_threshold = datetime.now() - timedelta(hours=24)

    transactions = Transaction.query.filter(Transaction.date_heure_transaction > time_threshold).all()

    transactions_data = [{
        'id_transaction': transaction.id_transaction,
        'id_employe': transaction.id_employe,
        'id_client': transaction.id_client,
        'date_heure_transaction': transaction.date_heure_transaction.strftime('%Y-%m-%d %H:%M:%S'),
        'type_paiement': transaction.type_paiement,
        'montant_total': str(transaction.montant_total),
        'verif': transaction.verif
    } for transaction in transactions]

    return jsonify(transactions_data)


@app.route('/update_verif', methods=['POST'])
def update_verif():
    try:
        Transaction.query.filter_by(verif=False).update({'verif': True})
        db.session.commit()
        return jsonify({'success': True, 'message': 'Toutes les transactions non vérifiées ont été validées.'}), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    

#--------Upload De Fichiers-----------------

#Verifie Les Extensions Autorise
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

#classe DocumentsEssentiels
class DocumentsEssentiels(db.Model):
    __tablename__ = 'DocumentsEssentiels'
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(255), nullable=False)
    dateAjout = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    taille = db.Column(db.Integer, nullable=False)
    chemin = db.Column(db.String(255), nullable=False)

    def __repr__(self):
        return f'<DocumentsEssentiels {self.nom}>'

#Upload Vers Serveur SFTP
def upload_to_sftp(filename):
    if allowed_file(filename):
        local_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        remote_filepath = os.path.join(REMOTE_PATH, filename)

        logging.info(f"Starting upload of {filename} to SFTP server.")

        transport = paramiko.Transport((SFTP_HOST, SFTP_PORT))
        try:
            transport.connect(username=SFTP_USERNAME, password=SFTP_PASSWORD)
            sftp = paramiko.SFTPClient.from_transport(transport)
            sftp.put(local_path, remote_filepath)
            sftp.close()
            logging.info(f"Successfully uploaded {filename} to SFTP server.")
        except paramiko.SSHException as e:
            logging.error(f"Connection to SFTP server failed: {e}")
        finally:
            transport.close()

        
        file_url = BASE_URL + filename
        return file_url
    else:
        logging.error("File type is not allowed.")
        return None    


#S'occupe de récupérer les documents fillezila et de les ajouter à la db
@app.route('/upload', methods=['GET','POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            file_url = upload_to_sftp(filename)
            logging.info(f"Received file {file.filename} for upload.")
            if file_url:
                add_document_to_db(filename, file_url)
                flash('File successfully uploaded and added to the database.')
                logging.info(f"File {filename} has been uploaded and will now be added to the database.")
            else:
                flash('Failed to upload file to SFTP server.')
                logging.error(f"Failed to upload file {filename} to SFTP server.")
        return redirect(url_for('upload_file'))
    else:
        return render_template('upload.html')

#Formulaire d'upload des fichiers vers FileZilla
@app.route('/')
def upload_form():
    return render_template('upload.html')   

#Ajoute doc à la db
def add_document_to_db(filename, file_url):
    file_size = os.path.getsize(os.path.join(app.config['UPLOAD_FOLDER'], filename))
    new_document = DocumentsEssentiels(
        nom=filename, 
        taille=file_size, 
        chemin=file_url,
        dateAjout=datetime.utcnow()
    )
    db.session.add(new_document)
    try:
        db.session.commit()
        logging.info(f"File {filename} added to the database.")
    except SQLAlchemyError as e:
        logging.error(f"Failed to add file to the database: {e}")
        db.session.rollback()  

#Upload Mannuel
def add_file_to_db(filename, directory="uploads/DocumentsEssentiels"):
    file_path = os.path.join(directory, filename)
    
    logging.info(f"Tentative de trouver et ajouter le fichier : {filename} dans le dossier : {directory}")
    
    if os.path.exists(file_path):
        logging.info(f"Fichier trouvé : {filename}, Taille : {os.path.getsize(file_path)} octets")

        file_size = os.path.getsize(file_path)
        
        new_doc = DocumentsEssentiels(
            nom=filename,
            taille=file_size,
            chemin=file_path,
            dateAjout=datetime.utcnow()
        )
        
        try:
            db.session.add(new_doc)
            db.session.commit()
            logging.info(f"Le fichier '{filename}' a été ajouté avec succès à la base de données.")
        except Exception as e:
            logging.error(f"Erreur lors de l'ajout du fichier à la base de données: {e}")
            db.session.rollback()
    else:
        logging.error(f"Erreur : Le fichier spécifié '{filename}' n'existe pas dans le dossier '{directory}'.")

@app.route('/uploads/DocumentsEssentiels/<path:filename>')
def serve_pdf(filename):
    # Utilisez un chemin absolu pour le répertoire ou ajustez en conséquence
    return send_from_directory('uploads/DocumentsEssentiels', filename)

#Recuperer les documents de la table DocumentsEssentiels
@app.route('/api/documents')
def get_documents():
    documents = DocumentsEssentiels.query.all()  
    documents_data = [{
        'id': document.id,
        'nom': document.nom,
        'dateAjout': document.dateAjout.strftime('%Y-%m-%d'),
        'taille': document.taille,
        'chemin': document.chemin
    } for document in documents]
    
    return jsonify(documents_data)



if __name__ == '__main__':
    logging.info("Starting Flask application.")
    with app.app_context():
        test_db_connection()
        db.create_all()
    app.run(debug=True)