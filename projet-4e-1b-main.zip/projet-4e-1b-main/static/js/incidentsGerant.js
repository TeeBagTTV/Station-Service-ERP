document.addEventListener('DOMContentLoaded', () => {
    recupererIncidents();
    document.getElementById("validerModifsIncident").addEventListener("click", modifierIncident());
});

function recupererIncidents() {
    fetch('/liste_incidents', {
        method: 'GET',
    })
    .then(response => {
        // en cas d'erreur
        if (!response.ok) {
            throw new Error('Erreur reception liste incidents');
        }
        // sinon, parse the JSON response
        return response.json();
    })
    .then(data => {
        // Pass the parsed JSON data to peuplerIncidents
        peuplerIncidents(data);
    })
    .catch(error => {
        // Handle any errors
        console.error('Error fetching or parsing data:', error);
    });


}

function peuplerIncidents(liste){

    const tableATraiter = document.getElementById("tableIncidentsATraiter");
    const tableHistorique = document.getElementById("tableHistoriqueIncidents"); 

    // peupler la table historique des incidents
    liste.forEach(incident => {

        let div = document.createElement("div");
        div.classList.add("popup-item");

        let spanId = document.createElement("span");
        spanId.classList.add("id");
        spanId.innerHTML = incident.id_incident;
        spanId.style.display = "none";

        let spanType = document.createElement("span");
        spanType.classList.add("type");
        spanType.innerHTML = incident.type;

        let spanHoraire = document.createElement("span");
        spanHoraire.classList.add("horaire");
        spanHoraire.innerHTML = incident.date_heure;

        let spanAuteur = document.createElement("span");
        spanAuteur.classList.add("auteur");
        spanAuteur.innerHTML = incident.auteur;

        let spanNiveau = document.createElement("span");
        spanNiveau.classList.add("niveau");
        spanNiveau.innerHTML = incident.niveau;


        div.appendChild(spanType);
        div.appendChild(spanHoraire);
        div.appendChild(spanAuteur);
        div.appendChild(spanNiveau);

        tableHistorique.appendChild(div);

        if (incident.niveau=="3" && incident.a_traiter!="0"){
            tableATraiter.appendChild(div);
        }
    });

    // gerer cliquer incident
    gererIncidentATraiter();
}

function gererIncidentATraiter() {
    let incidents = document.querySelectorAll("#tableIncidentsATraiter>.popup-item:not(.en-tete)");

    incidents.forEach(incident => {
        incident.addEventListener("click", (incident) => {
            // dans overlay.js on ferme le popup actuel
            afficherIncident(incident);
        });
    });
}

function afficherIncident(incident) {
    document.getElementById("incident").style.display = "none";
    // afficher le popup de gestion d'incident
    let popupGestionIncident = document.getElementById("gestion_incident");
    popupGestionIncident.style.display = "block";

    // peupler avec les bonnes valeurs
    
    // EMPLOYES et PERSONNE CONTACTEE
    // recuperer la liste des employes
    fetch("/liste_employes", {
        method: 'GET',
    })
    .then(response => {
        // en cas d'erreur
        if (!response.ok) {
            throw new Error('Erreur reception liste des employyés');
        }
        // sinon, parse the JSON response
        return response.json();
    })
    .then(data => {

        console.log(data);
        // les ajouter dans le select de l'employe
        data.forEach(emp => {
        
        const nom_employe = emp.prenom + " " + emp.nom;

        // ajouter l'employe dans les select
        let optionEmploye = document.createElement("option");
        optionEmploye.value, optionEmploye.text = nom_employe;

        let optionEmploye2 = optionEmploye.cloneNode(true);



        // selectionner l'employe actuel
        if(incident.auteur == nom_employe){
            optionEmploye.selected = "selected";
        }
        document.getElementById("gi-employe").appendChild(optionEmploye);

    
        if(incident.personne_contactee == nom_employe)
            optionEmploye2.selected = "selected";

        document.getElementById("gi-contact").appendChild(optionEmploye2);
        
        
        });
       

    })
    .catch(error => {
        // Handle any errors
        console.error('Error fetching or parsing data:', error);
    });

    // ID INCIDENT
    document.getElementById("gi-id").value = incident.id;

    // NIVEAU
    console.log("NIVEAU INCIDENT :"+incident.niveau);
    document.querySelectorAll("#gi-niveau>option").forEach(option => {
        console.log(option.value);
        if(option.value == ""+incident.niveau)
            option.selected = "selected";
    });

    // HORAIRE DE L'INCIDENT
    console.log(incident.horaire); // A VOIR COMMENT DIVISER EN DATE ET HEURE

    // TYPE
    const types = ['medical', 'securite', 'materiel', 'service/marchandise'];

    document.querySelectorAll("#gi-type>option").forEach(option => {
        if(option.value == incident.type)
            option.selected = "selected";
    });


    // DETAIL TECHNIQUE
    document.getElementById("gi-dettech").innerText = incident.detail;

    // AUTRES REMARQUES
    document.getElementById("gi-remarques").innerHTML = incident.remarques;

    // SOLUTION APPORTEE
    document.getElementById("gi-solution").textContent = incident.solution;

    // HORAIRE DE LA SOLUTION
    console.log(incident.horaire_solution); // A VOIR COMMENT DIVISER EN DATE ET HEURE
    
}

function modifierIncident() {
    // envoyer toutes les donnees au serveur, qui fera un update table
    let jsonAEnvoyer = {
        id: document.getElementById("gi-id").value,
        niveau: document.getElementById("gi-niveau").value,
        type: document.getElementById("gi-type").value,
        //horaire: document.getElementById("gi-horaire").value,
        auteur: document.getElementById("gi-employe").value,
        personne_contactee: document.getElementById("gi-contact").value,
        detail: document.getElementById("gi-dettech").value,
        remarques: document.getElementById("gi-remarques").value,
        solution: document.getElementById("gi-solution").value,
        //horaire_solution: document.getElementById("gi-horaire-solution").value
    };

    console.log(jsonAEnvoyer); // A ENVOYER AU SERVEUR



}