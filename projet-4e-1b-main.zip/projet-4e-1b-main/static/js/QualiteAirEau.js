var intervals = {};

function initializeBasePercentages() {
    document.querySelectorAll('.quality-item').forEach(function(item) {
        const percentageTextElement = item.querySelector('.quality-percentage');
        if (percentageTextElement) {
            const basePercentage = parseInt(percentageTextElement.textContent) || 0;
            const circle = item.querySelector('.circle');
            if(circle) {
                circle.setAttribute('data-base-percentage', basePercentage.toString());
                console.log('Base percentage set for', circle, 'to', basePercentage); // Log pour débogage
            }
        }
    });
}


document.addEventListener('DOMContentLoaded', function() {
    initializeBasePercentages();
    document.querySelectorAll('.switch').forEach(switchEl => {
        switchEl.addEventListener('click', () => toggleSwitch(switchEl));
    });    
});

function toggleSwitch(element) {
    element.classList.toggle('active');
    var parentItem = element.closest('.quality-item');
    var itemId = parentItem.getAttribute('id'); 
    var description = parentItem.querySelector('.quality-description-activation');
    var circle = parentItem.querySelector('.circle');
    var qualityEtat = parentItem.querySelector('.quality-etat');
    var basePercentage = parseInt(circle.getAttribute('data-base-percentage')) || 0; 

    if (intervals[itemId]) {
        clearInterval(intervals[itemId]);
        delete intervals[itemId]; 
    }

    if (element.classList.contains('active')) {
        description.textContent = description.getAttribute('data-active-text');
        description.classList.remove('text-inactive');
        description.classList.add('text-active');

        let currentPercentage = parseInt(circle.getAttribute('data-percentage')) || basePercentage;
        const targetPercentage = 90 + Math.floor(Math.random() * 11);

        intervals[itemId] = setInterval(function() {
            if (currentPercentage < targetPercentage) {
                currentPercentage++;
            } else {
                clearInterval(intervals[itemId]);
            }
            updateCircle(circle, currentPercentage);
            updateQualityEtat(qualityEtat, currentPercentage);
        }, 500); 
    } else {
        description.textContent = description.getAttribute('data-inactive-text');
        description.classList.remove('text-active');
        description.classList.add('text-inactive');

        let currentPercentage = parseInt(circle.getAttribute('data-percentage')) || basePercentage;

        intervals[itemId] = setInterval(function() {
            if (currentPercentage > basePercentage) {
                currentPercentage--;
            } else {
                clearInterval(intervals[itemId]);
                delete intervals[itemId];
                currentPercentage = basePercentage; 
            }
            updateCircle(circle, currentPercentage);
            updateQualityEtat(qualityEtat, currentPercentage);
        }, 200);
    }

}


function updateCircle(circle, percentage) {
    const radius = 24.875; 
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (percentage / 100) * circumference;
    circle.style.strokeDasharray = `${circumference}`;
    circle.style.strokeDashoffset = offset;

    circle.setAttribute('data-percentage', percentage);

    
    const percentageText = circle.nextElementSibling; 
    percentageText.textContent = `${percentage}%`;
}

function updateQualityEtat(qualityEtat, percentage) {
    qualityEtat.textContent = getQualityEtatText(percentage);
    qualityEtat.style.color = getColorForQualityEtat(percentage);
}


function getQualityEtatText(percentage) {
    if (percentage >= 90) {
        return 'État Excellent';
    } else if (percentage >= 70) {
        return 'État Bon';
    } else if (percentage >= 50) {
        return 'État Satisfaisant';
    } else if (percentage >= 30) {
        return 'État Moyen';
    } else if (percentage >= 10) {
        return 'État Pauvre';
    } else {
        return 'État Critique';
    }
}

function getColorForQualityEtat(percentage) {
    if (percentage >= 70) {
        return 'blue';
    } else if (percentage < 30) {
        return 'orange';
    } else if (percentage >= 30 && percentage < 70){
        return 'grey'; 
    } else {
        return 'grey';
    }
}
