document.addEventListener('DOMContentLoaded', (event) => {


   function activerEdition(idProduit) {
console.log(idProduit);  // Ceci devrait afficher l'ID du produit dans la console

document.querySelectorAll(`#form-produit-${idProduit} input`).forEach(input => {
    console.log(input); // Pour tester et voir si les éléments sont correctement sélectionnés
    input.removeAttribute('readonly');
    // Déplacer l'ajout des écouteurs d'événements ici
    input.addEventListener('input', () => {
        // Afficher le bouton Valider si une modification est détectée
        document.querySelector(`#valider-${idProduit}`).style.display = 'inline';
    });
    });

document.querySelector(`#valider-${idProduit}`).style.display = 'inline';
}

function modifierProduit(formElement) {
const idProduit = formElement.getAttribute('data-id-produit');
const formData = new FormData(formElement);
const data = {};
formData.forEach((value, key) => {data[key] = value;});
console.log(data)

fetch(`/produit/update/${idProduit}`, {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify(data)
})
.then(response => response.json())
.then(data => {
    if(data.success) {
        alert(data.message); 
    } else {
        alert(data.message); 
    }
})
.catch(error => {
    console.error('Erreur:', error);
    alert('Erreur lors de la communication avec le serveur.');
});
}
});

