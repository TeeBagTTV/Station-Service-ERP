document.addEventListener('DOMContentLoaded', () => {
    getCarburantsFromAPI();
});

function getCarburantsFromAPI() {
    fetch('/get_selected_carburants')
    .then(response => {
        if (!response.ok) {
            throw new Error('Erreur de réseau');
        }
        return response.json();
    })
    .then(data => {
        generateTankHTML(data);
    })
    .catch(error => console.error('Erreur lors de la récupération des données des carburants :', error));
}

function generateTankHTML(carburantsData) {
    const tanksContainer = document.querySelector('.tank-container');
    tanksContainer.innerHTML = '';

    carburantsData.forEach(carburant => {
        const blocksCount = Math.ceil(carburant.niveau_percent / 100 * 6); 
        const roundedPercentage = Math.round(carburant.niveau_percent);
        let carburantName = carburant.nom;
        if (carburantName === 'GAZOLENORM.B7') {
            carburantName = 'DIESELB7';
        }
        if (carburantName === 'SAPLOMB95.E05') {
            carburantName = 'SP95B05';
        }
        if (carburantName === 'SAPLOMB98.E10') {
            carburantName = 'SP98B10';
        }
        let tankHTML = `<div class="tank-row">
                            <div class="tank-name">${carburantName}</div>
                            <div class="tank-indicator">`;

        for (let i = 0; i < 6; i++) {
            if (i < blocksCount) {
                tankHTML += `<div class="tank-block-fill"></div>`;
            } else {
                tankHTML += `<div class="tank-block"></div>`;
            }
        }

        tankHTML += `</div>
                     <div class="tank-percentage">${roundedPercentage} %</div>
                     </div>`;

        tanksContainer.innerHTML += tankHTML;
    });
}


function fetchEmployes() {
    fetch('/employes')
      .then(response => {
        if (!response.ok) {
          throw new Error('Erreur lors de la récupération des données.');
        }
        return response.json();
      })
      .then(data => {
        document.querySelector('.gestion-main-number').innerText = data.length; // Nombre total d'employés
        let totalEmployes = 0;
        let totalGerants = 0;
        data.forEach(employe => {
          if (employe.role === 'employe') {
            totalEmployes++;
          } else if (employe.role === 'gerant') {
            totalGerants++;
          }
        });
        document.querySelector('.totGestion').innerText = 'Nombre d\'employé total';
        document.querySelectorAll('.gestion-info div')[1].innerText = 'Employé total : ' + totalEmployes;
        document.querySelectorAll('.gestion-info div')[2].innerText = 'Gérant admin : ' + totalGerants;
      })
      .catch(error => {
        console.error('Erreur:', error);
      });
  }
  
  fetchEmployes();
  