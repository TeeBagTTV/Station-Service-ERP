import { enregisterTransaction, supprimerArticles } from './widgetLeft.js';
import {  switchClavier, changeActiveInput, changeConnexion, changeRecrediter, updateCardCredit } from './calculatrice.js';

let nom='';
let prenom='';
let idClient='';
let idCarte='';
let payementEnCours=false;
let bonus=false;

function getPEnCours(){
    return payementEnCours;
}
function setPEnCours(bool){
    payementEnCours=bool;
}
function getIDClient(){
    return idClient;
}
function getIDCarte(){
    return idCarte;
}

function setIDCArte(id){
    idCarte=id;
}
var validateButton = document.querySelector('.validate');
var manageButton = document.querySelector('.manage');
var BlueButton = document.querySelector('.blue');
var closeBtn = document.querySelector('.popup-close-btn');
var closeBtnCStation = document.getElementById('cStation');


var overlay = document.getElementById('overlay');
var popup0 = document.getElementById('choixTypePaiement');
var popup1 = document.getElementById('choixTicket');
var popup3 = document.getElementById('incident');
var energyPumpPopup = document.getElementById('energyPumpPopup');
var popup2 = document.getElementById('impressionTicket');
var buttonCross = document.getElementById('buttonCross');
var carteStation = document.querySelector("#openCStation");

var pumpButton = document.querySelector('.pumpManagement');
var BlueButton = document.querySelector('.blue');

var closeButtons = document.querySelectorAll('.popup-close-btn, .popup-close-btn2');
const form = document.getElementById('registration-form');


var popups = document.querySelectorAll('.popup');
const formData = new FormData(form);

const createButton = document.querySelector('.btn1.create');
//let input = document.getElementById('client_code_input');
let input = document.getElementById('montantRecredite');
const validateButton2 = document.getElementById('scan-button');
const titre = document.getElementById('textTitrePopup');

const carteElement = document.querySelector('.createCarte');


var openCarteStationP = document.getElementById("openCStationPayement");

document.addEventListener('DOMContentLoaded', function() {
    document.querySelector("#btn_recu_cb").addEventListener('click', () => genererTicket());
    document.querySelector("#btn_ticket_recu").addEventListener('click', () => genererTicket());
    document.querySelector(".cash-button").addEventListener('click', () => lancerPaiementCarte("CS"));
    document.querySelector(".other-button").addEventListener('click', () => lancerPaiementEsp());
    document.querySelector(".visa-button").addEventListener('click', () => {
        lancerPaiementCarte("CB");
        
    });
    document.querySelector(".other-button").addEventListener('click', () => lancerPaiementCarte("CS"));

    document.getElementById('MontantBonus').style.display='none';
    document.getElementById('SommeCarte').style.display='none';
    document.getElementById('appliquerBonus').style.display='none';


    openCarteStationP.addEventListener('click',function(){
        changeRecrediter(false);
        setPEnCours(true);
        openCStation();
    });

    const applyButton = document.getElementById('appliquerBonus');
    applyButton.addEventListener('click', function() {
        bonus=true;
        this.classList.toggle('selected');
    });

    validateButton.addEventListener('click', function() {
        document.getElementById("carteStationPayement").style.display='block';
        document.querySelector(".payment-button.cash-button").disabled;
        payer();
    });

    BlueButton.addEventListener('click', function() {
        overlay.style.display = 'block';
        popup3.style.display = 'block';
    });

    manageButton.addEventListener('click', function() {
        overlay.style.display = 'block';
        energyPumpPopup.style.display = 'block';
    });

    carteStation.addEventListener('click', function() {
        setPEnCours(false);
        changeConnexion(true);
        openCStation();
    });

    function openCStation(){
        showPopup('carteStation');
        switchClavier(true);
        changeActiveInput(document.getElementById("montantRecredite"));
    }

    buttonCross.addEventListener('click', function(){
        overlay.style.display = 'none';
        popups.forEach(function(popup) {
            popup.style.display = 'none';
        });
    });

   
    

    if (pumpButton) {
        pumpButton.addEventListener('click', function() {
            showPopup('pumpManagementPopup');
        });
    }

    if (BlueButton) {
        BlueButton.addEventListener('click', function() {
            showPopup('incident');
        });
    }

    
    closeButtons.forEach(function(button) {
        button.addEventListener('click', closeAllPopups);
    });

    //afficher un popup spécifique

   
    

    if (pumpButton) {
        pumpButton.addEventListener('click', function() {
            showPopup('pumpManagementPopup');
        });
    }

    if (BlueButton) {
        BlueButton.addEventListener('click', function() {
            showPopup('incident');
        });
    }

    closeButtons.forEach(function(button) {
        button.addEventListener('click', closeAllPopups);
    });

    document.getElementById("title4later").style.display="none";


    form.addEventListener('submit', function (e) {
        e.preventDefault(); 
        fetch('/register', {
            method: 'POST',
            body: formData 
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.text();
        })
        .then(data => {
            try {
                const jsonData = JSON.parse(data);
                console.log(jsonData);
            } catch (error) {
                console.error('Le texte reçu n\'est pas du format JSON: ', data);
            }
        })
        .catch(error => {
            console.error('Il y a eu un problème avec l\'opération fetch: ', error);
        });
    });




    createButton.addEventListener('click', function () {

        carteElement.style.display = 'block';
        document.getElementById('container-for-calculator2').style.display = 'none';
    });

});


function showPopup(popupId) {
    closeAllPopups();
    var popup = document.getElementById(popupId);
    if (popup) {
        overlay.style.display = 'block';
        popup.style.display = 'block';
    }
}

//fermer tous les popups
function closeAllPopups() {
    initStation();
    initCPayement();
    overlay.style.display = 'none';
    popups.forEach(function(popup) {
        popup.style.display = 'none';
    });
}


function initStation() {
    document.getElementById('textTitrePopup').style.display = 'block';
    document.getElementById('textTitrePopup').textContent='Scanner ou entrer manuellement la carte station';
    document.getElementById('container-for-calculator2').style.display = 'block';
    document.querySelector('.btn1.create').style.display = 'block';

    document.getElementById('carte-station-details').style.display = 'none';
    document.getElementById('title4later').style.display = 'none';
    document.getElementById('montantRecredite').value = '';
    document.getElementById('montantRecredite').style.display = 'block';
    document.getElementById('montantRecredite').placeholder="Saisir un code via le clavier panel";

    document.querySelector('.createCarte').style.display='none';

};


function searchIDClient() {

    idClient = parseInt(input.value, 10); 

    createButton.style.display = 'none';
    input.style.display = 'none';
    document.getElementById('container-for-calculator2').style.display = 'none';
    //validateButton2.style.display = 'none';

    if (isNaN(idClient)) {
        createButton.style.display = 'block';
        input.style.display = 'block';
        //validateButton2.style.display = 'block';
        input.value = '';
        input.placeholder = 'Ce nombre n\'est pas valide.'; 
        return;
    }
    input.value = '';
    input.placeholder = 'Code valide !'; 

    fetch(`/cartes_station/${idClient}`) 
    .then(response => {
        if (!response.ok) {
            temp.placeholder = 'Code invalide !';
        }
        return response.json();
    })
    .then(data => {
        const detailsContainer = document.getElementById('carte-station-details');
        document.getElementById('carte-station-details').style.display = 'block';

        

        if ('erreur' in data) {
            detailsContainer.innerHTML = `<p>${data.erreur}</p>`;
            createButton.style.display = 'block';
            input.style.display = 'block';
            //validateButton2.style.display = 'block';
        } else {
            if(getPEnCours()){
                setIDCArte(data.id_carte_station);
                //data.montant_credit_energie
                //data.bonus
                setPEnCours(false);
                showPopup('choixTypePaiement');
                document.getElementById("openCStationPayement").style.display='none';
                document.getElementById('MontantBonus').style.display='block';
                document.getElementById('SommeCarte').style.display='block';
                
                document.getElementById('intro').style.display='none';
                document.getElementById('MontantBonus').textContent = 'Montant de réduction : '+data.bonus+" €";
                document.getElementById('SommeCarte').textContent = 'Montant carte : '+data.montant_credit_energie+" €";
                document.getElementById('appliquerBonus').style.display='block';

            }
            else{
                
            idCarte = data.id_carte_station;
            setIDCArte(data.id_carte_station);
            console.log(idCarte);
            titre.innerHTML = `Détails de la carteStation n°${data.id_carte_station}`;
            const htmlContent = `
            <div id="clientInfoTitle">Information client</div>
            <div id="temp">
            
                <p>ID Carte Station: ${data.id_carte_station} - ID Client: ${data.id_client} - Date de Création: ${data.date_creation}</p>
                <p>Montant Crédit Énergie: ${data.montant_credit_energie}€</p>
                <p>Bonus: ${data.bonus}€</p>
                <p>Statut: ${data.statut}</p>
            </div>
            `;
            detailsContainer.innerHTML = htmlContent;
            fetchClientDetails(data.id_client);
            }
        }
    })
    .catch(error => {
        console.error('Erreur lors de la récupération des données : ', error);
    });
}


function clearPopup(){
    popup0.style.display = 'none';
    popup1.style.display = 'none';
    popup2.style.display = 'none';
    popup3.style.display = 'none';

}


function fetchClientDetails(idClient) {
    fetch(`/clients/${idClient}`) 
        .then(response => {
            if (!response.ok) {
                throw new Error('Réponse réseau non OK.');
            }
            return response.json();
        })
        .then(data => {
            const detailsContainer = document.getElementById('carte-station-details');
            
            if ('erreur' in data) {
                detailsContainer.innerHTML = `<p>${data.erreur}</p>`;
            } else {
                nom=data.nom;
                prenom=data.prenom;
                idClient=data.id_client;

                let temp = detailsContainer.innerHTML;

                const htmlContent = temp +`
                <div id="temp2">
                    <p>Nom: ${data.nom} ${data.prenom}</p>
                    <p>Email: ${data.email}</p>
                    <p>Adresse: ${data.adresse}</p>
                    <Button id="recrediterCarte" class="btn1 create">Créditer carte énergie</Button>
                    </div>
                `;
                detailsContainer.innerHTML = htmlContent;
                document.getElementById("recrediterCarte").addEventListener('click', function () {
                    changeConnexion(false);
                    setPEnCours(false);
                    changeRecrediter(true);
                    document.getElementById('carte-station-details').style.display="none";
                    document.getElementById("container-for-calculator2").style.display="block";
                    document.getElementById("recrediterCarte").style.display="none";
                    document.getElementById("title4later").style.display="block";
                    document.getElementById("montantRecredite").style.display="block";
                    document.getElementById("montantRecredite").placeholder="Entrer le montant à recréditer";
                    switchClavier(true);
                    changeActiveInput(document.getElementById("montantRecredite"));
                    
                });
            }

        
        })
        .catch(error => {
            console.error('Erreur lors de la récupération des informations du client : ', error);
        });

    }

    

    

////////////////////////////////////////////////////////////////



function payer(){
    overlay.style.display = 'block';
        popup1.style.display = 'block';
        clearPopup();
        overlay.style.display = 'block';

        // choisir type paiement
        popup0.style.display = 'block';

        // etapes du paiement -> gerees par les boutons cash/visa/other -button
        
        // afficher choix ticket
        document.getElementById("choixTicket").style.display = "block"; // TODO n'afficher qu'une fois popup0 caché

        // etapes impression ticket
        //popup1.style.display = 'block';
}


function lancerPaiementEsp() {
    enregisterTransaction("ESP");
    // lancer overlay avec #paiementEsp
}

function parseAmount(str) {
    const matches = str.match(/:\s*([0-9]*[.,]?[0-9]+)\s*€/);
    if (matches && matches[1]) {
        return parseFloat(matches[1].replace(',', '.'));
    }
    return 0;
}


function initCPayement(){
    setIDCArte(0);

    document.getElementById("openCStationPayement").style.display='block';
    document.getElementById('MontantBonus').style.display='none';
    document.getElementById('SommeCarte').style.display='none';
    
    document.getElementById('intro').style.display='block';
    document.getElementById('MontantBonus').textContent = 'Montant de réduction : x €';
    document.getElementById('SommeCarte').textContent = 'Montant carte : x €';

    document.getElementById('appliquerBonus').style.display='none';

}
async function lancerPaiementCarte(typeCarte) {

    
    const applyButton = document.getElementById('appliquerBonus');
    if (applyButton.classList.contains('selected')) {
        enregisterTransaction(typeCarte,parseAmount(document.getElementById('MontantBonus').textContent));
    }
    else{
        enregisterTransaction(typeCarte,0);
    }
    initCPayement();

    document.getElementById("choixTypePaiement").style.display = "none";

    document.getElementById("paiementCarte").style.display = "block";

    let imgPrinc1 = "chemin/image/1";
    let imgPrinc2 = "chemin/image/2";
    let imgPrinc3 = "chemin/image/3";
    let imgPrinc4 = "chemin/image/4";

    let cheminGifChargement = "chemin/gif/chargement";
    let cheminImgReussie = "chemin/img/statut/succes";


    if(typeCarte=="CB")
        document.getElementById("paiementMsg").innerText = "Type de paiement : CB";
    else if (typeCarte=="CS")
        document.getElementById("paiementMsg").innerText = "Type de paiement : Carte station";



    // affichage 1re fenetre
    document.getElementById("img_principale").setAttribute("src", imgPrinc1);
    document.getElementById("msg").innerText = "Communication du montant au TPE";
    document.getElementById("img_statut").setAttribute("src", cheminGifChargement);

    await sleep(3000);

    // 2e fenetre
    document.getElementById("img_principale").setAttribute("src", imgPrinc2);
    document.getElementById("msg").innerText = "En attente de la réponse TPE";

    await sleep(3000);

    // 3e fenetre
    document.getElementById("img_principale").setAttribute("src", imgPrinc3);
    document.getElementById("msg").innerText = "Succès de réception de la réponse";

    await sleep(3000);

    // 4e fenetre
    document.getElementById("img_principale").setAttribute("src", imgPrinc4);
    document.getElementById("msg").innerText = "Transaction enregistrée avec succès";
    document.getElementById("img_statut").setAttribute("src", cheminImgReussie);
    
    await sleep(3000);

    document.getElementById("paiementCarte").style.display = 'none';
   
    showPopup('choixTicket');

    //document.getElementById('overlay').style.display = "none";

    console.log("done");

}

function afficherPopupTicket() {
    document.querySelector("#choixTicket").style.display = 'block';
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

async function genererTicket(genererTicketBool) {
    
    // cacher popup actuel
    var overlay = document.getElementById('overlay');
    document.querySelector("#choixTicket").style.display = 'none';
    

    if(genererTicketBool) {
        // afficher nouveau popup
        document.querySelector("#impressionTicket").style.display = 'block';
        
        // attendre cinq secondes
        await sleep(5000);

    }

    // fermer
    document.querySelector("#impressionTicket").style.display = 'none';
    overlay.style.display = 'none';
    supprimerArticles();

}
export {searchIDClient,payer,getIDClient,getIDCarte,getPEnCours, setPEnCours}

let incidents = document.querySelectorAll("#tableIncidentsATraiter>.popup-item:not(.en-tete)");

    incidents.forEach(incident => {
        incident.addEventListener("click", (incident) => {
            // dans overlay.js on ferme le popup actuel
            clearPopup();
        });
    });

