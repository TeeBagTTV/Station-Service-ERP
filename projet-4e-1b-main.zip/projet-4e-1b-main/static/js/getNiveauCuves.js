document.addEventListener('DOMContentLoaded', () => {
    fetch('/get_carburants')
        .then(response => {
            if (!response.ok) {
                throw new Error('Erreur de réseau');
            }
            return response.json();
        })
        .then(data => updatePopupList(data))
        .catch(error => console.error('Erreur:', error));
});

function updatePopupList(carburants) {
    const popupList = document.querySelector('.popup-list3');
    popupList.innerHTML = '';

    carburants.forEach(carburant => {
        const tankLevelWidth = (carburant.niveau_actuel / carburant.capacite_totale * 100).toFixed(2);
        const item = document.createElement('div');
        item.classList.add('popup-item-cuves');
        item.setAttribute('data-id-carburant', carburant.id); 
        item.innerHTML = `
            <span>${carburant.nom}</span>
            <span class="tank-background">
                <span class="tank-level-indicator" style="width: ${tankLevelWidth}%;"></span>
            </span>
            <span>${carburant.prix_achat}</span>
            <span>${carburant.prix_vente}</span>
        `;
        popupList.appendChild(item);
    });

    // Ajoute les événements de clic aux nouveaux éléments
    const cuvesItems = document.querySelectorAll('.popup-item-cuves');
    cuvesItems.forEach(item => {
        item.addEventListener('click', () => {
            // Récupère les valeurs des champs
            const nomCarburant = item.querySelector('span:nth-child(1)').textContent;
            const descriptionCarburant = item.querySelector('span:nth-child(2)').textContent;
            const prixAchat = item.querySelector('span:nth-child(3)').textContent;
            const prixVente = item.querySelector('span:nth-child(4)').textContent;
            const idCarburant = item.getAttribute('data-id-carburant');

            // Remplace les valeurs dans le formulaire
            document.getElementById('idcarburant').value = idCarburant;
            document.getElementById('cuves-name').value = nomCarburant;
            document.getElementById('cuves-description').value = descriptionCarburant;
            document.getElementById('purchase-cuves').value = prixAchat;
            document.getElementById('selling-cuves').value = prixVente;

            // Affiche le formulaire et masque la section d'action rapide
            afficherFormulaire();
        });
    });
}

const popupModifyCuves = document.getElementById('popup-modify-cuves');
const cuvesActionRapide = document.getElementById('cuves-action-rapide');
const btnCancelCuves = document.querySelector('.btn-cancel-cuves');

const afficherFormulaire = () => {
    popupModifyCuves.style.display = 'block';
    cuvesActionRapide.style.display = 'none';
};

const annulerModification = () => {
    popupModifyCuves.style.display = 'none';
    cuvesActionRapide.style.display = 'block';
};

btnCancelCuves.addEventListener('click', annulerModification);


document.querySelector('.popup-modify-form-cuves').addEventListener('submit', function(e) {
    e.preventDefault();

    var formData = new FormData(this);

    fetch('/add_or_update_carburant', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Échec de la requête');
        }
        return response.json();  
    })
    .then(data => {
        console.log(data);
        if (data.status === 'success') {
            fetch('/get_carburants')
                .then(response => response.json())
                .then(data => updatePopupList(data))
                .catch(error => console.error('Erreur:', error));
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Erreur:', error);
    });
});

