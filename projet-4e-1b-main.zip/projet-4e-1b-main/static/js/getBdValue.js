document.addEventListener('DOMContentLoaded', function() {
    // Fonction pour récupérer et afficher les produits
    function fetchAndDisplayProducts() {
        fetch('/get_products')
            .then(response => response.json())
            .then(products => {
                const productList = document.getElementById('product-list');
                productList.innerHTML = '';
                products.forEach(product => {
                    const productItem = document.createElement('div');
                    
                    productItem.classList.add('popup-item');
                    productItem.id = `product-container-${product.id_produit}`;

                    productItem.innerHTML = `
                        <span>${product.nom}</span>
                        <span class="type">${product.seuil_alerte}</span>
                        <span>${product.prix_achat}€</span>
                        <span>${product.prix_vente}€</span>
                    `;
                    productList.appendChild(productItem);

                    productItem.addEventListener('click', function() {
                        // Réinitialisation de l'affichage des sections
                        document.getElementById('stock-action-rapide').style.display = 'none';
                        document.getElementById('popup-modify-stock').style.display = 'block';
                        document.getElementById('titreSectionPopup').textContent = `Consulter ou modifier le stock de ${product.nom}`;

                        const popupCreateStock = document.getElementById('popup-create-stock');
                        const popupModifyStock = document.getElementById('popup-modify-stock');

                        if (popupCreateStock.style.display === 'block') {
                        popupCreateStock.style.display = 'none';

                        }

                        // Remplissage du formulaire avec les données du produit sélectionné
                        document.getElementById('product-id').value = product.id_produit;
                        document.getElementById('product-name').value = product.nom;
                        document.getElementById('product-description').value = product.description;
                        document.getElementById('purchase-price').value = product.prix_achat;
                        document.getElementById('selling-price').value = product.prix_vente;
                        document.getElementById('alert-threshold').value = product.seuil_alerte;
                        // Supposant que l'identifiant est incorrect et devrait être quelque chose lié à la quantité
                        document.getElementById('fournissor').value = product.id_fournisseur; // Vérifiez cet ID !
                    });
                });
            });
    }

    // Gestion de la recherche
    document.getElementById('search-bar').addEventListener('input', function() {
        const searchTerm = this.value.trim().toLowerCase();
        document.querySelectorAll('.popup-item').forEach(function(item) {
            const productName = item.querySelector('span:first-child').textContent.trim().toLowerCase();
            item.style.display = productName.includes(searchTerm) ? 'flex' : 'none';
        });
    });

    const cancelButton = document.querySelector('.btn-cancel-stock');
    cancelButton.addEventListener('click', function() {
        const stockActionRapide = document.getElementById('stock-action-rapide');
        const popupModifyStock = document.getElementById('popup-modify-stock');
        stockActionRapide.style.display = 'block';
        popupModifyStock.style.display = 'none';
    });

    const cancelButton2 = document.querySelector('.btn-cancel-stock-create');
    cancelButton2.addEventListener('click', function() {
        const stockActionRapide = document.getElementById('stock-action-rapide');
        const popupCreateStock = document.getElementById('popup-create-stock');
        stockActionRapide.style.display = 'block';
        popupCreateStock.style.display = 'none';
    });


    const createButton = document.getElementById('creer_produit');
    createButton.addEventListener('click', function() {
        const stockActionRapide = document.getElementById('stock-action-rapide');
        const popupCreateStock = document.getElementById('popup-create-stock');
        const popupModifyStock = document.getElementById('popup-modify-stock');

        if (popupModifyStock.style.display === 'block') {
            popupModifyStock.style.display = 'none';
        }

        stockActionRapide.style.display = 'none';
        popupCreateStock.style.display = 'block';
    });

    document.getElementById('btn-create-product').addEventListener('click', function(event) {
        event.preventDefault();
        const form = document.querySelector('.stock-create-form');
        let formData = new FormData(form);
        let object = {};
        formData.forEach((value, key) => { object[key] = value; });
        let json = JSON.stringify(object);
        console.log(json);
        fetch('/ajouter_product', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: json
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const stockActionRapide = document.getElementById('stock-action-rapide');
                const popupCreateStock = document.getElementById('popup-create-stock');
                stockActionRapide.style.display = 'block';
                popupCreateStock.style.display = 'none';
                fetchAndDisplayProducts();
            } else {
                const stockActionRapide = document.getElementById('stock-action-rapide');
                const popupCreateStock = document.getElementById('popup-create-stock');
                stockActionRapide.style.display = 'block';
                popupCreateStock.style.display = 'none';
                fetchAndDisplayProducts();
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Erreur lors de la communication avec le serveur');
        });
    });
    


    document.querySelectorAll('.btn-delete-stock').forEach(button => {
        button.addEventListener('click', function() {
            const productId = document.getElementById('product-id').value;
            console.log(productId);
            if (!productId) {
                console.error('ID du produit manquant.');
                return;
            }
        
            // Envoi de la requête de suppression au serveur
            fetch(`/delete_product/${productId}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => { 
                if (data.success) {
                    console.log(data.message);
                    // Supprimer l'élément HTML correspondant au produit supprimé
                    console.log(document.querySelector(`#product-container-${productId}`));
                    document.querySelector(`#product-container-${productId}`).remove();
                    fetchAndDisplayProducts();
                } else {
                    console.error(data.message);
                }
            })
            .catch(error => console.error('Error:', error));
        });
    });
    


    // Envoi des données mises à jour
    document.getElementById('btn-modify-stock').addEventListener('click', function(event) {
        event.preventDefault();
        const form = document.querySelector('.stock-modify-form');
        let formData = new FormData(form);
        let object = {};
        console.log(form)
        formData.forEach((value, key) => object[key] = value);
        let json = JSON.stringify(object);

        fetch('/update_product', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: json
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                fetchAndDisplayProducts(); // Rafraîchir la liste des produits
            } else {
                console.error('La mise à jour a échoué');
            }
        })
        .catch(error => console.error('Error:', error));
    });

    // Initialisation de l'affichage des produits
    fetchAndDisplayProducts();
});