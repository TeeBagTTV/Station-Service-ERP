document.addEventListener('DOMContentLoaded', () => {
    const payrollCard = document.getElementById('payroll');
    const dailyPayrollPopup = document.getElementById('daily-payroll-popup');
    const tableReleverPopup = document.getElementById('table_relever'); 
    const closeBtn = document.querySelector('#close-daily-payroll');

    payrollCard.addEventListener('click', () => {
        tableReleverPopup.style.display = 'none';
        dailyPayrollPopup.style.display = 'block';
    });

    window.addEventListener('click', (event) => {
        if (event.target === dailyPayrollPopup) {
            dailyPayrollPopup.style.display = 'none';
        }
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const payrollCard = document.getElementById('payroll');
    if (payrollCard) {
        payrollCard.addEventListener('click', () => {
            fetch('/api/transactions/last24hours')
                .then(response => response.json())
                .then(transactions => {
                    let content = `
                        <div class="transaction-table">
                            <div class="transaction-row header">
                                <span>ID Transaction</span>
                                <span>Date et Heure</span>
                                <span>Type de Paiement</span>
                                <span>Montant Total</span>
                                <span>Verification</span>
                            </div>`;
                    
                    transactions.forEach(transaction => {
                        content += `
                            <div class="transaction-row">
                                <span>${transaction.id_transaction}</span>
                                <span>${transaction.date_heure_transaction}</span>
                                <span>${transaction.type_paiement}</span>
                                <span>${transaction.montant_total}€</span>
                                <span>${transaction.verif ? 'Oui' : 'Non'}</span>
                            </div>
                        `;
                    });
                    content += `</div>`;
                    document.querySelector('#daily-payroll-popup .popup-body').innerHTML = content;
                })
                .catch(error => console.error('Error:', error));
        });
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const validateButton = document.getElementById('validateButton');
    if (validateButton) {
        validateButton.addEventListener('click', function() {
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "/update_verif", true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.responseType = 'json';

            xhr.onload = function() {
                if (xhr.status >= 200 && xhr.status < 300) {
                    alert(xhr.response.message);
                } else {
                    alert("Une erreur est survenue: " + xhr.status);
                }
            };

            xhr.onerror = function() {
                alert("Une erreur est survenue lors de la communication avec le serveur.");
            };
            xhr.send();
        });
    }
});
