document.addEventListener('DOMContentLoaded', function() {
    let employes = []; // Déclaration de la variable employes en dehors de la fonction

    fetch('/employes')
        .then(response => {
            if (!response.ok) {
                throw new Error('Erreur lors de la récupération des données.');
            }
            return response.json();
        })
        .then(data => {
            employes = data;
            renderEmployes(employes);
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
        

    const searchInput = document.getElementById('search-bar-employe');
    searchInput.addEventListener('input', function() {
        const searchText = this.value.trim();
        filterEmployes(searchText, employes); // Passer la liste des employés à la fonction de filtre
    });

    const employeList = document.getElementById('employe-list');
    employeList.addEventListener('click', function(event) {
        const employeItem = event.target.closest('.popup-item');
        console.log('Employé cliqué ID:', employeItem.dataset.employeId);
        if (employeItem) {
            
            displayEmployeInfo(employeItem.dataset.employeId, employes); // Passer la liste des employés à la fonction d'affichage des infos
            // Afficher la section employe-action-information et cacher employe-action-rapide
            document.getElementById('employe-action-information').style.display = 'block';
            document.getElementById('employe-action-rapide').style.display = 'none';
        }
    });

    // Cacher la section employe-action-information au chargement de la page
    document.getElementById('employe-action-information').style.display = 'none';

});

function fetchEmployeInfo(){
    fetch('/employes')
        .then(response => {
            if (!response.ok) {
                throw new Error('Erreur lors de la récupération des données.');
            }
            return response.json();
        })
        .then(data => {
            employes = data;
            renderEmployes(employes);
        })
        .catch(error => {
            console.error('Erreur:', error);
        });

}

function filterEmployes(searchText, employes) { // Ajouter la liste des employés comme paramètre
    const filteredEmployes = employes.filter(employe => {
        const fullName = `${employe.nom} ${employe.prenom}`.toLowerCase();
        return fullName.includes(searchText.toLowerCase()) || employe.email.toLowerCase().includes(searchText.toLowerCase());
    });

    renderEmployes(filteredEmployes);
}

function renderEmployes(employes) {
    const employeList = document.getElementById('employe-list');
    employeList.innerHTML = '';

    employes.forEach(employe => {
        const employeItem = document.createElement('div');
        employeItem.classList.add('popup-item');
        employeItem.dataset.employeId = employe.id_employe;
        employeItem.innerHTML = `
            <span id="employe-nom-${employe.id_employe}">${employe.nom} ${employe.prenom}</span>
            <span id="employe-email-${employe.id_employe}">${employe.email}</span>
            <span id="employe-role-${employe.id_employe}">${employe.role}</span>
        `;
        employeList.appendChild(employeItem);
    });
}

function displayEmployeInfo(employeId, employes) { // Ajouter la liste des employés comme paramètre
    const nomElement = document.getElementById('nom_employe');
    const prenomElement = document.getElementById('prenom_employe');
    const emailElement = document.getElementById('email_employe');
    const roleElement = document.getElementById('role_employe');

    console.log('ID pour afficher les infos:', employeId);

    const employe = employes.find(e => e.id_employe.toString() === employeId); // Utiliser la même clé pour rechercher l'employé
    if (employe) {
        document.getElementById('id_employe').value = employeId;
        nomElement.textContent = employe.nom;
        prenomElement.textContent = employe.prenom;
        emailElement.textContent = employe.email;
        roleElement.textContent = employe.role;
    }
}


function transformInfoIntoInputs() {

    document.querySelectorAll('.action-button').forEach(button => {
        if(button.id !== 'appliquer_modifications') {
            button.classList.add('action-button-hidden');
        }
    });

    document.getElementById('nom_employe').outerHTML = `<input type="text" id="nom_employe" value="${document.getElementById('nom_employe').textContent}" />`;
    document.getElementById('prenom_employe').outerHTML = `<input type="text" id="prenom_employe" value="${document.getElementById('prenom_employe').textContent}" />`;
    document.getElementById('email_employe').outerHTML = `<input type="text" id="email_employe" value="${document.getElementById('email_employe').textContent}" />`;
    document.getElementById('role_employe').outerHTML = `<input type="text" id="role_employe" value="${document.getElementById('role_employe').textContent}" />`;


    document.getElementById('appliquer_modifications_container').style.display = 'block';
}

document.getElementById('gerer_employe').addEventListener('click', function() {
    console.log("Appelle de TransformInfoToInputs")
    transformInfoIntoInputs();
});

document.getElementById('appliquer_modifications').addEventListener('click', function() {
    const idEmploye = document.getElementById('id_employe').value;
    const nom = document.getElementById('nom_employe').value;
    const prenom = document.getElementById('prenom_employe').value;
    const email = document.getElementById('email_employe').value;
    const role = document.getElementById('role_employe').value;

    console.log(idEmploye);
    if (idEmploye) {

            fetch(`/update_employe/${idEmploye}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nom, prenom, email, role })
            })
            .then(response => {
                console.log('Statut de la réponse:', response.status);
                if (!response.ok) {
                    throw new Error('Erreur lors de la mise à jour de l\'employé.');
                }
                return response.json();
            })
            .then(data => {
                document.getElementById(`employe-nom-${idEmploye}`).textContent = nom;
                document.getElementById(`employe-prenom-${idEmploye}`).textContent = prenom;
                document.getElementById(`employe-email-${idEmploye}`).textContent = email;
                document.getElementById(`employe-role-${idEmploye}`).textContent = role;
                alert(data.message);

            })
            .catch(error => console.error('Erreur:', error));
        }
});






