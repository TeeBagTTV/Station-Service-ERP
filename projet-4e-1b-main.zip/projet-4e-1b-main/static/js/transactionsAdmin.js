document.addEventListener('DOMContentLoaded', function() {
    getTransactionsFromAPI();
    afficherDerniereDirective();
    updateIncidentData();
    updateProductData();

    document.getElementById("acces-caisse").addEventListener("click", function() {
        changerDeRoute();
    });
});

function updateProductData() {
    fetch('/produits')
    .then(response => response.json())
    .then(data => {
        const produits = data.produits;
        const produitsSeuilAtteint = produits.filter(produit => produit.prix_vente <= produit.seuil_alerte);
        const nombreProduitsSeuilAtteint = produitsSeuilAtteint.length;

        const nombreProduitsSeuilAtteintElement = document.querySelector('.div10 .bd-main-number');
        nombreProduitsSeuilAtteintElement.textContent = nombreProduitsSeuilAtteint;

        const listeProduitsElement = document.querySelector('.div10 .bd-details2 .bd-list');
        let produitsHTML = '';
        produitsSeuilAtteint.slice(0, 3).forEach(produit => {
            produitsHTML += `
                <li class="transaction-item2">
                    <span>${produit.nom}</span>
                    <span>${produit.description}</span>
                    <span>${produit.prix_vente}</span>
                </li>
            `;
        });
        listeProduitsElement.innerHTML = produitsHTML;
    })
    .catch(error => console.error('Erreur lors de la récupération des données des produits:', error));
}


function afficherDerniereDirective() {
    const descriptionElement = document.querySelector('.report-container .report-list-item span');
  
    fetch('/directives')
      .then(response => response.json())
      .then(data => {
        data.sort((a, b) => new Date(b.date_creation) - new Date(a.date_creation));
        
        const latestDirective = data[0];
        descriptionElement.textContent = latestDirective.description;
      })
      .catch(error => {
        console.error('Erreur lors de la récupération des directives :', error);
      });
}
    
function updateIncidentData() {
    fetch('/incidents')
    .then(response => response.json())
    .then(data => {
        const totalIncidents = data.incidents.length;
        const incidentsToday = data.incidents.filter(incident => {
            const today = new Date();
            const incidentDate = new Date(incident.date_heure);
            return incidentDate.toDateString() === today.toDateString();
        }).length;

        const incidentsTitle = document.querySelector('.div12 .card-title');
        const totalIncidentsSubtitle = document.querySelector('.div12 .card-subtitle');
        const incidentsTodayNumber = document.querySelector('.div12 .card-number');

        incidentsTitle.textContent = "Incidents";
        totalIncidentsSubtitle.textContent = "Nombre d'incident total : " + totalIncidents;
        incidentsTodayNumber.textContent = incidentsToday;
    })
    .catch(error => console.error('Erreur lors de la récupération des données des incidents:', error));
}


function changerDeRoute() {
    fetch('/changer_employe', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Erreur lors de la requête');
        }
        window.location.href = '/dashboard';
    })
    .catch(error => {
        console.error('Erreur:', error);
    });
}


function getTransactionsFromAPI() {
    fetch('/api/daily-transactions')
    .then(response => {
        if (!response.ok) {
            throw new Error('Erreur de réseau');
        }
        return response.json();
    })
    .then(data => {
        console.log('Transactions reçues:', data); 
        generateTransactionsHTML(data);
    })
    .catch(error => console.error('Erreur lors de la récupération des transactions:', error));
}

function generateTransactionsHTML(transactionsData) {
    const transactionsContainer = document.querySelector('.document-list');
    const transactionsTotal = document.getElementById('transact-somme');
    
    
    const transactionsNumber = document.querySelector('.transactionsNbr'); // Correction ici
    if (!transactionsContainer || !transactionsNumber) {
        console.error('.transactions-container ou #transactionsNbr non trouvé dans le DOM');
        return;
    }

    transactionsContainer.innerHTML = '';
    const transactionText = transactionsData.length === 1 ? 'transaction' : 'transactions';
    transactionsNumber.textContent = `Total: ${transactionsData.length} ${transactionText}`;

    let totalAmount = 0;
    transactionsData.forEach(transaction => {
        totalAmount += parseFloat(transaction.montant_total);
        let transactionHTML = `<li class="transaction-item">
                                    <span>${transaction.date_heure_transaction}</span>
                                    <span>${transaction.id_transaction}</span>
                                    <span>${transaction.montant_total}€</span>
                                    <span>${transaction.type_paiement}</span>
                                </li>`;
        transactionsContainer.innerHTML += transactionHTML;
    });

    if (transactionsData.length === 0) {
        console.log('Aucune transaction trouvée pour aujourd\'hui.');
        transactionsContainer.innerHTML = '<div>Aucune transaction trouvée pour aujourd\'hui.</div>';
    }
    transactionsTotal.textContent = `${totalAmount.toFixed(2)}€`;

}