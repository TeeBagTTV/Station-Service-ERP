const profileDropdown = document.getElementById('profileDropdown');
profileDropdown.addEventListener('click', function() {
    this.classList.toggle('active');
});

window.addEventListener('click', function(event) {
    if (!profileDropdown.contains(event.target)) {
        profileDropdown.classList.remove('active');
    }
});

function toggleDropdownMenu() {
    var dropdown = document.querySelector('.dropdown-menu');
    var icon = document.querySelector('.menu-icon');

    var iconRect = icon.getBoundingClientRect();

    if (dropdown.style.display === 'block') {
        dropdown.style.display = 'none'; 
    } else {
        dropdown.style.display = 'block'; 

        dropdown.style.top = iconRect.bottom + 'px';
        dropdown.style.left = iconRect.left + 'px';

        dropdown.style.right = '';
        dropdown.style.bottom = '';
    }
}



document.addEventListener('DOMContentLoaded', function() {
    var logoutButton = document.getElementById('logout-button');
    if(logoutButton) {
        logoutButton.addEventListener('click', function(event) {
            event.preventDefault();
            fetch('/logout', { 
                method: 'POST', 
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    action: 'logout'
                })
            }).then(response => {
                if (response.ok) {
                    return response.json();
                }
                throw new Error('Quelque chose s\'est mal passé lors de la déconnexion.');
            }).then(data => {
                console.log(data); 
            }).catch(error => {
                console.error('Erreur:', error);
            });
        });
    }
});
