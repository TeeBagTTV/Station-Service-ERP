function fetchAndDisplayClients() {
    fetch('/get_clients')
      .then(response => {
          if (!response.ok) {
              throw new Error('Erreur lors de la récupération des clients');
          }
          return response.json();
      })
      .then(data => {
          renderClients(data);
          setupSearchBar(data);
      })
      .catch(error => {
          console.error('Erreur lors de la récupération des clients:', error);
      });
}


function renderClients(clients) {
    const clientList = document.getElementById('liste_client-list');
    clientList.innerHTML = '';

    clients.forEach(client => {
        const clientItem = document.createElement('div');
        clientItem.classList.add('popup-item'); 
        clientItem.dataset.clientId = client.id_client;

        const clientDetails = document.createElement('div');
        clientDetails.innerHTML = `
            <span>${client.nom} </span>
            <span>${client.prenom} </span>
            <span> ${client.email} </span>
            <span>${client.adresse} </span>
        `;

        clientItem.appendChild(clientDetails);
        clientList.appendChild(clientItem);
    });
}

function setupSearchBar(clients) {
    const searchBar = document.getElementById('search-bar-client');
    searchBar.addEventListener('input', function() {
        const searchTerm = this.value.trim();
        const filteredClients = filterClientsByName(clients, searchTerm);
        renderClients(filteredClients);
    });
}

function filterClientsByName(clients, searchTerm) {
    return clients.filter(client => {
        const fullName = `${client.nom.toLowerCase()} ${client.prenom.toLowerCase()}`;
        return fullName.includes(searchTerm.toLowerCase());
    });
}

document.addEventListener('DOMContentLoaded', fetchAndDisplayClients);
