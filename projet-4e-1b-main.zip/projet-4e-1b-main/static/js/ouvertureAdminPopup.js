document.addEventListener('DOMContentLoaded', function() {
    /* RECUPERATION DES ID */
var overlay = document.getElementById('overlay');
var gestion_employe = document.getElementById('gestion-employe');
var niveau_cuves = document.getElementById('niveau-cuves');
var incident = document.getElementById('incident');
var maintenance = document.getElementById('maintenance');
var acces_caisse = document.getElementById('acces-caisse');
var qualite = document.getElementById('qualite-eau-air');
var direction_regional = document.getElementById('direction_regional');
var stock = document.getElementById('stock');
var reapprovisionnement = document.getElementById('reapprovisionnement');
var modif_bd = document.getElementById('modif_bd');
var table_relever = document.getElementById('table_relever');
var document_ligne = document.getElementById('document_ligne');

/* BOUTON FERMETURE */
var closeBtn_gestion = document.querySelector('.close-btn-gestion'); 
var closeBtn_cuves = document.querySelector('.close-btn-cuves'); 
var closeBtn_incident = document.querySelector('.close-btn-incident'); 
var closeBtn_maintenance = document.querySelector('.close-btn-maintenance'); 
var closeBtn_caisse = document.querySelector('.close-btn-caisse'); 
var closeBtn_qualite = document.querySelector('.close-btn-qualite'); 
var closeBtn_direction = document.querySelector('.close-btn-direction'); 
var closeBtn_stock = document.querySelector('.close-btn-stock'); 
var closeBtn_reappro = document.querySelector('.close-btn-reappro'); 
var closeBtn_btn_bd = document.querySelector('.close-btn-bd'); 
var closeBtn_relever = document.querySelector('.close-btn-relever'); 
var closeBtn_document = document.querySelector('.close-btn-document-ligne-2'); 
var closeBtnDocumentEssentielle = document.querySelector('.close-btn-document-ligne');
var closeBtn_payroll = document.querySelector('.close-btn-payroll'); 

/* BOUTON OUVERTURE */
var ouvert_gestion = document.querySelector('.div6');
var ouvert_cuves = document.querySelector('.div4'); 
var ouvert_incident = document.querySelector('.div1'); 
var ouvert_maintenance = document.querySelector('.div2'); 
var ouvert_caisse = document.querySelector('.div3'); 
var ouvert_qualite = document.querySelector('.div5'); 
var ouvert_direction = document.querySelector('.div7'); 
var ouvert_stock = document.querySelector('.div8'); 
var ouvert_reappro = document.querySelector('.div9'); 
var ouvert_bd = document.querySelector('.div10'); 
var ouvert_relever = document.querySelector('.div12'); 
var ouvert_document = document.querySelector('.div11'); 
var ouvert_hamburger = document.querySelector('.menu-icon'); 

/* ETAPE D'OUVERTURE DU POPUP */
ouvert_gestion.addEventListener('click', function() {
    overlay.style.display = 'block';
    gestion_employe.style.display = 'block';
});

ouvert_cuves.addEventListener('click', function() {
    overlay.style.display = 'block';
    niveau_cuves.style.display = 'block';
});

ouvert_incident.addEventListener('click', function() {
    overlay.style.display = 'block';
    document_ligne.style.display = 'block';
});

ouvert_maintenance.addEventListener('click', function() {
    overlay.style.display = 'block';
    maintenance.style.display = 'block';
});

ouvert_caisse.addEventListener('click', function() {
    overlay.style.display = 'block';
    acces_caisse.style.display = 'block';
});

ouvert_qualite.addEventListener('click', function() {
    overlay.style.display = 'block';
    qualite.style.display = 'block';
});

ouvert_direction.addEventListener('click', function() {
    overlay.style.display = 'block';
    direction_regional.style.display = 'block';
});

// ouvert_stock.addEventListener('click', function() {
//     overlay.style.display = 'block';
//     modif_bd.style.display = 'block';
// });

ouvert_reappro.addEventListener('click', function() {
    overlay.style.display = 'block';
    reapprovisionnement.style.display = 'block';
});

ouvert_bd.addEventListener('click', function() {
    overlay.style.display = 'block';
    stock.style.display = 'block';
});

ouvert_relever.addEventListener('click', function() {
    overlay.style.display = 'block';
    incident.style.display = 'block';
});

ouvert_document.addEventListener('click', function() {
    overlay.style.display = 'block';
    table_relever.style.display = 'block';
});

/* ETAPE FERMETURE DU POPUP */
closeBtn_gestion.addEventListener('click', function(){ 
    overlay.style.display = 'none';
    gestion_employe.style.display = 'none';
});

closeBtn_cuves.addEventListener('click', function(){ 
    overlay.style.display = 'none';
    niveau_cuves.style.display = 'none';
});

closeBtn_incident.addEventListener('click', function(){ 
    overlay.style.display = 'none';
    incident.style.display = 'none';
});

closeBtn_maintenance.addEventListener('click', function(){ 
    overlay.style.display = 'none';
    maintenance.style.display = 'none';
});

closeBtn_caisse.addEventListener('click', function(){ 
    overlay.style.display = 'none';
    acces_caisse.style.display = 'none';
});

closeBtn_qualite.addEventListener('click', function(){ 
    overlay.style.display = 'none';
    qualite.style.display = 'none';
});

closeBtn_direction.addEventListener('click', function(){ 
    overlay.style.display = 'none';
    direction_regional.style.display = 'none';
});

closeBtn_stock.addEventListener('click', function(){ 
    overlay.style.display = 'none';
    stock.style.display = 'none';
});

closeBtn_reappro.addEventListener('click', function(){ 
    overlay.style.display = 'none';
    reapprovisionnement.style.display = 'none';
});


closeBtn_btn_bd.addEventListener('click', function(){ 
    overlay.style.display = 'none';
    modif_bd.style.display = 'none';
});

closeBtn_relever.addEventListener('click', function(){ 
    overlay.style.display = 'none';
    table_relever.style.display = 'none';
});

closeBtn_payroll.addEventListener('click', function(){ 
    overlay.style.display = 'none';
    table_relever.style.display = 'none';
});

closeBtn_document.addEventListener('click', function(){ 
    overlay.style.display = 'none';
    document_ligne.style.display = 'none';
});

});
