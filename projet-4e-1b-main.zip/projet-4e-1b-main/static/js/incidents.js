document.addEventListener("DOMContentLoaded", function() {
    // recuperer la liste des utilisateurs
    fetch('/liste_employes')
    .then(response => response.json())
    .then(data => {
        // ajouter les utilisateurs dans le formulaire
        ajouterUtilisateurs(data);
    })
    .catch((error) => {
        console.error('Error:', error);
    });

    handleLevelSelection();

    // gestion du bouton de soumission
    document.getElementById("incidentSubmitBtn").addEventListener("click", function() {
        genererFicheIncident();
    });
});


// ajouter liste des utilisateurs dans le formulaire pour le champ personne contactee
function ajouterUtilisateurs(employe) {
    console.log("starting to add users to the form");
    let select = document.getElementById("personne_contactee");

    employe.forEach(function(employe) {
        let option = document.createElement("option");
        option.text = employe.nom.toUpperCase() + " " + employe.prenom;
        option.value = employe.id_employe;
        select.add(option);
    });
}


function handleLevelSelection() {
    let buttons = document.querySelectorAll("#niveauIncident>button");

    buttons.forEach(button => {
        button.addEventListener("click", () => buttonClicked(button));
    });
}



// A FACTORISER
function buttonClicked(btn) {
    let buttons = document.querySelectorAll("#niveauIncident>button");

    buttons.forEach(button => {
        button.classList.remove("niveauBtnSelectionne");
    });

    btn.classList.add("niveauBtnSelectionne");
}

function removeNiveauBoutonSelectionne() {
    let buttons = document.querySelectorAll("#niveauIncident>button");

    buttons.forEach(button => {
        button.classList.remove("niveauBtnSelectionne");
    });
}

// envoyer la fiche au serveur
function genererFicheIncident() {

    // si niveau d'incident non selectionne
    let niv = document.querySelector("#niveauIncident>button.niveauBtnSelectionne");
    if (niv === null) {
        // message d'alerte et on n'envoie pas la fiche
        let msg = document.createElement("p");
        msg.innerHTML = "Vous devez renseigner le niveau de l'incident !";
        document.getElementById('niveauIncident').appendChild(msg);
        return;
    }

    let donneesForm = new FormData(document.getElementById("incident_form"));

    let jsonDonnees = {};

    for (const [key, value] of donneesForm) {
        jsonDonnees[key] = value;
    }
    jsonDonnees["niveau"] = niv.getAttribute("value");





    // envoyer a la base et gerer la reponse
    fetch('/creer_fiche_incident', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(jsonDonnees),
    })
    .then(response => response.text()) // a adapter
    .then(data => { // a adapter
        console.log(data); 
    })
    .catch((error) => {
        console.error('Error:', error);
    });


    // enlever le dernier niveau enregistré
    // sinon, si l'utilisateur oublie de choisir un niveau d'un nouvel incident, le niveau du dernier sera implicitement retenu
    removeNiveauBoutonSelectionne();
}



// TODO faire la fct python (ajouter dans la base), renvoyer reponse, gerer reponse avec une fenetre statut.
// faire le css du formulaire
// maj lors de reponse gerant