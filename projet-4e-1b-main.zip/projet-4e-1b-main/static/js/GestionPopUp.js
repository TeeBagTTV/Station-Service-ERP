function setRandomPercentage() {
    document.querySelectorAll('.quality-circle .circle').forEach(function(circle) {
      const radius = 24.875;
      const circumference = 2 * Math.PI * radius;
  
      const randomPercentage = Math.floor(Math.random() * 100);
      const offset = circumference - (randomPercentage / 100) * circumference;
  
      circle.style.strokeDasharray = circumference;
      circle.style.strokeDashoffset = offset;

      setTimeout(() => {
        circle.style.strokeDashoffset = offset;
      }, 100);
  
      const percentageText = circle.nextElementSibling;
      percentageText.textContent = `${randomPercentage}%`;

      
      const qualityEtat = circle.closest('.quality-item').querySelector('.quality-etat');
      if (qualityEtat !== null) { 
            qualityEtat.textContent = getQualityEtatText(randomPercentage);
            qualityEtat.style.color = getColorForQualityEtat(randomPercentage);
      }

      circle.setAttribute('data-base-percentage', randomPercentage.toString())

    });
  }

function setRandomTemperature() {
    const temperatureElement = document.querySelector('.temperature-value');
    const randomTemperature = Math.floor(Math.random() * 11) + 20; // Génère un nombre entre 20 et 30
    temperatureElement.textContent = `${randomTemperature}°C`;
}

function getQualityEtatText(percentage) {
    if (percentage >= 90) {
        return 'État Excellent';
    } else if (percentage >= 70) {
        return 'État Bon';
    } else if (percentage >= 50) {
        return 'État Satisfaisant';
    } else if (percentage >= 30) {
        return 'État Moyen';
    } else if (percentage >= 10) {
        return 'État Pauvre';
    } else {
        return 'État Critique';
    }
}

function getColorForQualityEtat(percentage) {
    if (percentage >= 70) {
        return 'blue';
    } else if (percentage < 30) {
        return 'orange';
    } else if (percentage >= 30 && percentage < 70){
        return 'grey'; 
    } else {
        return 'grey';
    }
}


document.addEventListener('DOMContentLoaded', function() {
    var ouvert_qualite = document.querySelector('.div5');

    ouvert_qualite.addEventListener('click', function() {
        var overlay = document.getElementById('overlay');
        var qualite = document.getElementById('qualite-eau-air');
        
        overlay.style.display = 'block';
        qualite.style.display = 'block';
        
        requestAnimationFrame(() => {
            setRandomPercentage();
            setRandomTemperature();
        });
    });
});



document.addEventListener('DOMContentLoaded', function() {
  var annualReport = document.getElementById('annual-report');
  var essentialDocs = document.getElementById('essential-docs');
  var serviceEntretient = document.getElementById('service_entretient');
  var serviceFrigo = document.getElementById('service_bilan_frigo');
  var serviceErp = document.getElementById('service_erp');
  var servicePompe = document.getElementById('service_pompe');

  var tableReleverPopup = document.getElementById('table_relever');
  var documentEssentiellePopup = document.getElementById('document_essentielle');
  var closeBtnDocumentEssentielle = document.querySelector('.close-btn-document-ligne');

  essentialDocs.addEventListener('click', function() {
      tableReleverPopup.style.display = 'none';
      documentEssentiellePopup.style.display = 'block';
      requestAnimationFrame(() => {
        updateStorageUsage(); 
      });
  });

  serviceEntretient.addEventListener('click', function() {
    tableReleverPopup.style.display = 'none';
    documentEssentiellePopup.style.display = 'block';
    requestAnimationFrame(() => {
      updateStorageUsage(); 
    });
  });

  serviceFrigo.addEventListener('click', function() {
    tableReleverPopup.style.display = 'none';
    documentEssentiellePopup.style.display = 'block';
    requestAnimationFrame(() => {
      updateStorageUsage(); 
    });
  });

  serviceErp.addEventListener('click', function() {
    tableReleverPopup.style.display = 'none';
    documentEssentiellePopup.style.display = 'block';
    requestAnimationFrame(() => {
      updateStorageUsage(); 
    });
  });

  servicePompe.addEventListener('click', function() {
    tableReleverPopup.style.display = 'none';
    documentEssentiellePopup.style.display = 'block';
    requestAnimationFrame(() => {
      updateStorageUsage(); 
    });
  });



  annualReport.addEventListener('click', function() {
    tableReleverPopup.style.display = 'none';
    documentEssentiellePopup.style.display = 'block';
    requestAnimationFrame(() => {
      updateStorageUsage(); 
    });
  });

  

  closeBtnDocumentEssentielle.addEventListener('click', function() {
      overlay.style.display = 'none'; 
      documentEssentiellePopup.style.display = 'none';
  });
});





// Fonction pour mettre à jour la vue du visualiseur de documents
function updateDocumentViewer(selected) {
    const viewer = document.querySelector('.document-viewer');
    const title = viewer.querySelector('.viewer-title');
    
    viewer.innerHTML = '';

    if (selected) {
      /*
        viewer.innerHTML = `
            <h3 class="viewer-title">Visualisation Du Document</h3>
            <div class="pdf-viewer">Visualisation de ${selected} ici</div>
        `;
        */

        const selectedDocument = document.querySelector('.document-item.selected');
        const pdfUrl = selectedDocument.getAttribute('data-pdf-url');

        console.log(pdfUrl)

        viewer.innerHTML = `
            <div class="pdf-viewer">
              <iframe src="${pdfUrl}" frameborder="0" style="width:90%; height:350px;"></iframe>
            </  
        `;
    } else {
        viewer.innerHTML = `
            <h3 class="viewer-title">Statistiques Des Documents</h3>
            <div class="stats-container">
                <div class="storage-circle">
                  <svg viewBox="0 0 36 36" class="circular-chart">
                    <path class="circle-bg-document"
                      d="M18 2.0845
                        a 15.9155 15.9155 0 0 1 0 31.831
                        a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none" stroke="#eee" stroke-width="2.8" />
                    
                    <path id="circle-document"
                      d="M18 2.0845
                        a 15.9155 15.9155 0 0 1 0 31.831
                        a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none" stroke="#00abff" stroke-width="2.8" />
                    
                    <text x="18" y="20.35" class="percentage">0.5/2 GB</text>
                  </svg>
                </div>
                
                <div class="file-stats">
                  <p id="pdf-count">Nombre de fichiers pdf: 34</p>
                  <p id="docx-count">Nombre de fichiers xlsx: 2</p>
                  <p id="xlsx-count">Nombre de fichiers doc: 3</p>
                  <p id="txt-count">Nombre de fichiers txt: 10</p>
                </div>
            </div>

            <div class="files-table">
              <div class="table-column">Compte rendu</div>
              <div class="table-column">Relevé des comptes</div>
              <div class="table-column">Fichier supprimé</div>
            </div>
        `;

        updateStorageUsage();
        updateFileCounts();
        const maxLength = 20; // Limite de caractères
        document.querySelectorAll('.document-name').forEach((element) => {
            const originalText = element.textContent;
            const truncatedText = truncateText(originalText, maxLength);
            element.textContent = truncatedText;
          }); 
    }
}

//S

// Ajouter un écouteur d'événement pour chaque élément de document
document.querySelectorAll('.documents-scrollable .document-item').forEach(item => {
    item.addEventListener('click', function() {
      if (item.classList.contains('selected')) {
        item.classList.remove('selected');
        updateDocumentViewer(null);
      } else {
        document.querySelectorAll('.documents-scrollable .document-item.selected').forEach(selectedItem => {
          selectedItem.classList.remove('selected');
        });
        item.classList.add('selected');
        const documentName = item.querySelector('.document-name').textContent.trim();
        updateDocumentViewer(documentName);
      }
    });
  });

  
  // Fonction pour filtrer les documents
function filterDocuments() {
    const searchInput = document.querySelector('.search-bar input');
    const filterText = searchInput.value.toLowerCase();
    const documentItems = document.querySelectorAll('.documents-scrollable .document-item');
  
    documentItems.forEach(item => {
      const name = item.querySelector('.document-name').textContent.toLowerCase();
      if (name.includes(filterText)) {
        item.style.display = '';
      } else {
        item.style.display = 'none';
      }
    });
  }
  
  document.querySelector('.search-bar input').addEventListener('input', filterDocuments);
  
  document.querySelector('.search-bar .search-btn').addEventListener('click', filterDocuments);

  
  function truncateText(filename, maxLength) {
    const dotIndex = filename.lastIndexOf(".");
    const extension = filename.substring(dotIndex + 1);
    const name = filename.substring(0, dotIndex);
  
    if (name.length <= maxLength) return filename;
  
    return `${name.substr(0, maxLength - 3)}...${extension}`;
}



  function updateStorageUsage() {
    const maxSizeInGB = 2; 
    let totalSizeInMB = 0;
  
    document.querySelectorAll('.document-item .document-size').forEach(sizeEl => {
      const sizeText = sizeEl.textContent.trim(); 
      const number = parseFloat(sizeText); 
      const unit = sizeText.match(/[a-zA-Z]+/)[0]; 
  
      // Convertir la taille en Mo selon l'unité et ajouter au total
      switch (unit) {
        case 'Go':
          totalSizeInMB += number * 1024;
          break;
        case 'Mo':
          totalSizeInMB += number;
          break;
        case 'Ko':
          totalSizeInMB += number / 1024;
          break;
        default:
          console.log("Unité non reconnue.");
      }
    });
  
    const totalSizeInGB = totalSizeInMB / 1024;
    const usagePercentage = (totalSizeInGB / maxSizeInGB) * 100;

    console.log(usagePercentage);
  
    const percentageText = document.querySelector('.percentage');
    percentageText.textContent = `${totalSizeInGB.toFixed(2)}/2 GB`;
  

    //const circle = document.querySelector('.circle-document');
    var circle = document.getElementById('circle-document');
    const radius = 15.9155; 
    const circumference = 2 * Math.PI * radius; 
    const offset = circumference - (usagePercentage / 100) * circumference;
    circle.style.strokeDasharray = circumference;

    setTimeout(() => {
        circle.style.strokeDashoffset = offset;
    }, 1500); 

  }
  
//document.addEventListener('DOMContentLoaded', updateStorageUsage);


  function updateFileCounts() {
    console.log("updateFileCountsBienAppelée")
    const fileCounts = {
      pdf: 0,
      docx: 0,
      xlsx: 0,
      txt: 0,
    };
  
    document.querySelectorAll('.document-item .document-name').forEach(item => {
      const extension = item.textContent.trim().split('.').pop().toLowerCase();

      if (fileCounts.hasOwnProperty(extension)) {
        fileCounts[extension]++;
      }
    });


  
    document.getElementById('pdf-count').textContent = `Nombre de fichiers pdf: ${fileCounts.pdf}`;
    document.getElementById('docx-count').textContent = `Nombre de fichiers docx: ${fileCounts.docx}`;
    document.getElementById('xlsx-count').textContent = `Nombre de fichiers xlsx: ${fileCounts.xlsx}`;
    document.getElementById('txt-count').textContent = `Nombre de fichiers txt: ${fileCounts.txt}`;
  }
  
  document.addEventListener('DOMContentLoaded', updateFileCounts);
  

function attachEventsToDocumentItems(){
    const maxLength = 20; // Limite de caractères
    document.querySelectorAll('.document-name').forEach((element) => {
        const originalText = element.textContent;
        const truncatedText = truncateText(originalText, maxLength);
        element.textContent = truncatedText;
      }); 
}

/*
function fetchDocumentsAndUpdateUI() {
  fetch('/api/documents')  
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(documents => {
        const container = document.querySelector('.documents-scrollable');
        container.innerHTML = '';
        documents.forEach(doc => {
            const docItem = document.createElement('div');
            docItem.classList.add('document-item');
            docItem.innerHTML = `
                <span class="document-name">${doc.nom}</span>
                <span class="document-date">${doc.dateAjout}</span>
                <span class="document-size">${formatFileSize(doc.taille)}</span>
            `;
            container.appendChild(docItem);

            attachEventsToDocumentItems();

            document.querySelectorAll('.documents-scrollable .document-item').forEach(item => {
              item.addEventListener('click', function() {
                if (item.classList.contains('selected')) {
                  item.classList.remove('selected');
                  updateDocumentViewer(null);
                } else {
                  document.querySelectorAll('.documents-scrollable .document-item.selected').forEach(selectedItem => {
                    selectedItem.classList.remove('selected');
                  });
                  item.classList.add('selected');
                  const documentName = item.querySelector('.document-name').textContent.trim();
                  updateDocumentViewer(documentName);
                }
              });
            });
        });
    })
    .catch(error => console.error('Erreur lors de la récupération des documents:', error));
} */


function fetchDocumentsAndUpdateUI() {
  fetch('/api/documents')
  .then(response => {
      if (!response.ok) {
          throw new Error('Network response was not ok');
      }
      return response.json();
  })
  .then(documents => {
      const container = document.querySelector('.documents-scrollable');
      container.innerHTML = '';
      documents.forEach(doc => {
          const docItem = document.createElement('div');
          docItem.classList.add('document-item');
          console.log(doc.chemin);
          const pdfUrl = doc.chemin.replace(/\\/g, "/"); // Remplacez les backslashes par des slashes
          console.log(pdfUrl);
          docItem.setAttribute('data-pdf-url', pdfUrl); // Utilisez ici le chemin fourni par l'API
          docItem.innerHTML = `
              <span class="document-name">${doc.nom}</span>
              <span class="document-date">${doc.dateAjout}</span>
              <span class="document-size">${formatFileSize(doc.taille)}</span>
          `;
          container.appendChild(docItem);
      });

      attachEventsToDocumentItems();
      updateFileCounts();


      document.querySelectorAll('.documents-scrollable .document-item').forEach(item => {
        item.addEventListener('click', function() {
          if (item.classList.contains('selected')) {
            item.classList.remove('selected');
            updateDocumentViewer(null);
          } else {
            document.querySelectorAll('.documents-scrollable .document-item.selected').forEach(selectedItem => {
              selectedItem.classList.remove('selected');
            });
            item.classList.add('selected');
            const documentName = item.querySelector('.document-name').textContent.trim();
            updateDocumentViewer(documentName);
          }
        });
      });
  })
  .catch(error => console.error('Erreur lors de la récupération des documents:', error));
}


function formatFileSize(sizeInBytes) {
  let size = sizeInBytes;
  const units = ["o", "Ko", "Mo", "Go", "To"]; // Ajout de To pour les tailles très grandes
  let unitIndex = 0;

  // Convertir la taille dans l'unité la plus appropriée
  while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
  }

  // Vérifier si la taille arrondie a strictement plus de trois chiffres avant la virgule
  if (Math.floor(size) >= 1000 && unitIndex > 0) {
      size /= 1024;
      unitIndex = Math.min(unitIndex + 1, units.length - 1); // S'assurer de ne pas dépasser les limites du tableau
      // Afficher avec deux chiffres après la virgule pour cette condition
      return `${size.toFixed(2)} ${units[unitIndex]}`;
  } else {
      // Pour les autres cas, afficher avec un chiffre après la virgule si moins de 10, sinon arrondir
      if (size < 10) {
          return `${size.toFixed(1)} ${units[unitIndex]}`;
      } else {
          return `${Math.round(size)} ${units[unitIndex]}`;
      }
  }
}





document.addEventListener('DOMContentLoaded', function() {
  fetchDocumentsAndUpdateUI();
});
  

