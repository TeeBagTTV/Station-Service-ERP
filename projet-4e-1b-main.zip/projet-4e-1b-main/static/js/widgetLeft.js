import { clearInput,updateCardCredit } from './calculatrice.js';
import { getIDCarte } from './overlay.js';



document.addEventListener('DOMContentLoaded', (event) => {
    const cancelButton = document.querySelector('.btn1.cancel'); 
    cancelButton.addEventListener('click', function() {
        const items = document.querySelectorAll('.ticket .item');
        items.forEach(function(item) {
            item.remove();
        });
        calculateTotalAmount();
});
});





/*document.addEventListener('DOMContentLoaded', () => {
    const validateButton = document.querySelector('.btn1.validate');
    validateButton.addEventListener('click', () => {
        

        montantTotal = prepareAndSendPurchaseReceipt();


        const items = document.querySelectorAll('.ticket .item');

        recordTransaction(items); 
        
        calculateTotalAmount();
        let total = 0;
        items.forEach((item) => {
            const amount = parseFloat(item.querySelector('.amount').textContent.replace('€', '').trim());
            total += amount
        });
        console.log(`Total à payer: ${total} EUR`);

        fetch('/calculer_total', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                total: total,
            }),
        })
        .then(response => response.json())
        .then(data => {
            console.log(data); 

            
        })
        .catch((error) => {
            console.error('Error:', error);
        });
    });
    calculateTotalAmount();
});*/




/*function prepareAndSendPurchaseReceipt() {
    const items = document.querySelectorAll('.ticket .item');
    let jsonItems = [];
    let total = 0;

    items.forEach((item) => {
        const idItem = item.querySelector('.id') ? item.querySelector('.id').textContent : 'ID non trouvé';
        const amount = parseFloat(item.querySelector('.amount').textContent.replace('EUR', '').trim());
        const quantity = parseInt(item.querySelector('.quantity').textContent.replace('x', '').trim());
        total += amount;

        jsonItems.push({id: idItem, amount, quantity});
    });

    calculateTotalAmount();

    console.log(`Total à payer: ${total} EUR`);

    fetch('/valider_BonVente', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            items: jsonItems,
            total: total,
        }),
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            console.log(data); 
            updateUIAmounts(data.total);
            return data.total;
        } else {
            throw new Error(data.error || 'Erreur lors de la validation du bon de vente');
        }
    })
    .catch((error) => {
        console.error('Error:', error);
    });
    
}*/




// send stock variation to server
/*function recordTransaction(items) {
    console.log("Longueur items : "+items.length);
    let jsonItems = {};
    // pour chaque ligne
    items.forEach((item) => {
        // recuperer son identifiant et montant
        const idItem = item.querySelector('.id');
        const quantity = parseInt(item.querySelector('.quantity').textContent.replace('x', '').trim());

        console.log("Ajout : "+idItem+" ayant pour quantite :"+quantity);

        // ajouter au json
        jsonItems[produits][idItem] = parseInt(quantity);
    });

    // 
    
    // l'envoyer au flask
    fetch('/validerAchat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(jsonItems)
    }) // gerer la reponse
    .then(response => response.json())
    .then(data => {
        console.log(data); 
    })
    .catch((error) => {
        console.error('Error:', error);
    });

    
}*/

function updateUIAmounts(total) {
    calculateTotalAmount();
    const formattedTotal = parseFloat(total).toFixed(2).replace('.', ',') + ' EUR';
    
    document.querySelectorAll('.amount2').forEach(element => {
        element.textContent = formattedTotal;
    });

    const amountWithoutVAT = (parseFloat(total) / 1.2).toFixed(2).replace('.', ',') + ' EUR';
    const detailElement = document.querySelector('.detail');
    if (detailElement) {
        detailElement.textContent = `Montant Sans TVA : ${amountWithoutVAT}`;
    }
    calculateTotalAmount();
}

function supprimerArticles(){
    const items = document.querySelectorAll('.ticket .item');
        items.forEach(function(item) {
            item.remove();
        });
        calculateTotalAmount();
}







function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

async function genererTicket() {
    var overlay = document.getElementById('overlay');
    document.querySelector("#choixTicket").style.display = 'none';

    document.querySelector("#impressionTicket").style.display = 'block';
    
    await sleep(5000);

    document.querySelector("#impressionTicket").style.display = 'none';
    overlay.style.display = 'none';
}

function scrollToBottom() {
    var element = document.querySelector('.ticket');
    element.scrollTop = element.scrollHeight;
}





function calculateTotalAmount() {
    const amountElements = document.querySelectorAll('.item .amount');
    const totalAmountDisplay = document.querySelector('.total-amount');
    if(amountElements.length === 0) {
        totalAmountDisplay.textContent = '0 €';
    }
    else{
        let total = 0;
        
        amountElements.forEach(function(amountElement) {
            const amount = parseFloat(amountElement.textContent.replace('€', '').replace(',', '.'));
            total += amount;
        });

        if (totalAmountDisplay) {
            totalAmountDisplay.textContent = total.toFixed(2).replace('.', ',') + ' €';
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    mergeDuplicateItems();
    
    
    document.querySelectorAll('.item').forEach(attachEventListenersToLine);


    const submitButton = document.getElementById('addProductButton');


    submitButton.addEventListener('click', () => {
        const productCodeInput = document.getElementById('productCodeInput');
        const productCode = productCodeInput.value;
    
        if (productCode.trim() === '') {
            alert('Veuillez saisir un code produit.');
            return;
        }
    
        fetch('/add_product', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id_produit: productCode })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            const productDetails = data.product_details;
            addItem(productDetails,true);
            mergeDuplicateItems();
        })
        .catch(error => {
            console.error('Error:', error);
        });

        clearInput();
    });
    
/*
    function addItem(productDetails) {
        const ticketDiv = document.querySelector('.ticket');
        const existingItems = ticketDiv.querySelectorAll('.item');
        let found = false;
    
        existingItems.forEach(item => {
            if (item.querySelector('.id').textContent === productDetails.id_produit) {
                let quantityText = item.querySelector('.quantity').textContent;
                let quantity = parseInt(quantityText.substring(1)) + 1;
                item.querySelector('.quantity').textContent = 'x' + quantity;
                let price = parseFloat(item.querySelector('.prix').textContent.replace('€', ''));
                let amount = price * quantity;
                item.querySelector('.amount').textContent = `${amount.toFixed(2)}€`;
                found = true;
            }
        });
    
        if (!found) {
            const newItem = document.createElement('div');
            newItem.classList.add('item');
            newItem.innerHTML = `
                <div class='id'>${productDetails.id_produit}</div>
                <div class="description">${productDetails.nom}</div>
                <button class="btn-moins">-</button>
                <div class="quantity">x1</div>
                <button class="btn-plus">+</button>
                <div class="prix">${parseFloat(productDetails.prix_vente).toFixed(2)}€</div>
                <div class="amount">${parseFloat(productDetails.prix_vente).toFixed(2)}€</div>
            `;
            ticketDiv.appendChild(newItem);
            scrollToBottom();
            attachEventListenersToLine(newItem);
        }
        calculateTotalAmount();
    }*/

});


// envoie au serveur : id des produits, quantites, montant total transaction, type de paiement utilise -> pour faire la variation de stock + enregistrement de la transaction
/*
Structure JSON :
produits {
    id,
    quantite
},
montantTotal,
typePaiement

Fonction déclenché lors de la validation de la transaction, quand l'utilisateur a choisi le type de paiement
*/

function enregisterTransaction(typePaiement,bonus) {
    const items = document.querySelectorAll('.ticket .item');

    // calculer le total de paiement
    
    let jsonItems = {};
    jsonItems["produits"] = [];
    let total = 0;

    items.forEach((item) => {
        const idItem = item.querySelector('.id') ? item.querySelector('.id').textContent : 'ID non trouvé';
        const quantity = parseInt(item.querySelector('.quantity').textContent.replace('x', '').trim());
        const amount = parseFloat(item.querySelector(".amount").textContent.replace('€', ''));
        total += amount;

        jsonItems["produits"].push({id: idItem, amount, quantity});
    });

    // garder les 2 premiers chiffres apres la virgule
    total = parseFloat(total.toFixed(2))- bonus;
    updateCarteStationBonus(getIDCarte(),bonus);
    console.log(total);

    if(typePaiement == "CS"){
        updateCardCredit(getIDCarte(),-total);
    }
    jsonItems["montantTotal"] = total;

    jsonItems["typePaiement"] = typePaiement;


    fetch('/validerAchat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            jsonItems
        }),
    })
    .then(response => response.json())
    .then(data => {
        console.log(data); 

        
    })
    .catch((error) => {
        console.error('Error:', error);
    });
    
}

function addItem(productDetails, isQuantityEditable) {
    const ticketDiv = document.querySelector('.ticket');
    const existingItems = ticketDiv.querySelectorAll('.item');
    let found = false;

    existingItems.forEach(item => {
        if (item.querySelector('.id').textContent === productDetails.id_produit) {
            if (isQuantityEditable) {
                let quantityText = item.querySelector('.quantity').textContent;
                let quantity = parseInt(quantityText.substring(1)) + 1;
                item.querySelector('.quantity').textContent = 'x' + quantity;
            }
            let price = parseFloat(item.querySelector('.prix').textContent.replace('€', ''));
            let quantity = parseInt(item.querySelector('.quantity').textContent.substring(1));
            let amount = price * quantity;
            item.querySelector('.amount').textContent = `${amount.toFixed(2)}€`;
            found = true;
        }
    });

    if (!found) {
        const newItem = document.createElement('div');
        newItem.classList.add('item');
        newItem.innerHTML = `
            <div class='id'>${productDetails.id_produit}</div>
            <div class="description">${productDetails.nom}</div>
            <button class="btn-moins">-</button>
            <div class="quantity">x1</div>
            <button class="btn-plus" ${isQuantityEditable ? '' : 'disabled'}>+</button>
            <div class="prix">${parseFloat(productDetails.prix_vente).toFixed(2)}€</div>
            <div class="amount">${parseFloat(productDetails.prix_vente).toFixed(2)}€</div>
        `;
        ticketDiv.appendChild(newItem);
        scrollToBottom();
        attachEventListenersToLine(newItem);
    }
    calculateTotalAmount();
}



function attachEventListenersToLine(item) {
    let autoClicker;
    const plusButton = item.querySelector('.btn-plus');
    const minusButton = item.querySelector('.btn-moins');
    const quantityDisplay = item.querySelector('.quantity');
    const amountDisplay = item.querySelector('.amount');
    const price = parseFloat(item.querySelector('.prix').textContent.replace('€', '').trim());

    function updateAmountDisplay(quantity) {
        amountDisplay.textContent = (price * quantity).toFixed(2) + '€';
        calculateTotalAmount();
    }
    
    function increaseQuantity() {
        let quantity = parseInt(quantityDisplay.textContent.replace('x', ''), 10);
        quantity += 1;
        quantityDisplay.textContent = 'x' + quantity;
        updateAmountDisplay(quantity);
    }
    
    function decreaseQuantity() {
        let quantity = parseInt(quantityDisplay.textContent.replace('x', ''), 10);
        quantity -= 1;
        if (quantity > 0) {
            quantityDisplay.textContent = 'x' + quantity;
            updateAmountDisplay(quantity);
        } else {
            item.remove();
            calculateTotalAmount();
        }
    }

    
    plusButton.addEventListener('mousedown', () => {
        autoClicker = setInterval(increaseQuantity, 75);
    });

    minusButton.addEventListener('mousedown', () => {
        autoClicker = setInterval(decreaseQuantity, 75);
    });

    plusButton.addEventListener('mouseup', () => clearInterval(autoClicker));
    plusButton.addEventListener('mouseleave', () => clearInterval(autoClicker));
    minusButton.addEventListener('mouseup', () => clearInterval(autoClicker));
    minusButton.addEventListener('mouseleave', () => clearInterval(autoClicker));
}

function mergeDuplicateItems() {
    const ticketDiv = document.querySelector('.ticket');
    const items = ticketDiv.querySelectorAll('.item');
    const itemCounts = {};

    items.forEach((item) => {
        const id = item.querySelector('.id').textContent;
        if(itemCounts.hasOwnProperty(id)) {
            itemCounts[id].quantity += parseInt(item.querySelector('.quantity').textContent.substring(1));
            itemCounts[id].amount += parseFloat(item.querySelector('.amount').textContent.replace('€', ''));
            item.remove();
        } else {
            itemCounts[id] = {
                item: item,
                quantity: parseInt(item.querySelector('.quantity').textContent.substring(1)),
                amount: parseFloat(item.querySelector('.amount').textContent.replace('€', ''))
            };
        }
    });

    for (const id in itemCounts) {
        const { item, quantity, amount } = itemCounts[id];
        item.querySelector('.quantity').textContent = `x${quantity}`;
        item.querySelector('.amount').textContent = `${amount.toFixed(2)}€`;
    }

    calculateTotalAmount();
}

function updateCarteStationBonus(idCarteStation, bonus) {
    const url = `/cartes_station/${idCarteStation}/bonus`;
    const data = { bonus: bonus };
    console.log(data);

    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }
        return response.json();
    })
    .then(data => {
        console.log('Success:', data);
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}



export { enregisterTransaction, addItem , calculateTotalAmount, supprimerArticles}
