document.addEventListener('DOMContentLoaded', function() {

    const fuelButtons = document.querySelectorAll('.fuel');
    const paymentButtons = document.querySelectorAll('.payment-button');
    //const inputField = document.querySelector('input');

    function sendData(data) {
        fetch('/endpoint', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('Réponse du serveur:', data);
        })
        .catch(error => {
            console.error('Erreur lors de l\'envoi des données:', error);
        });
    }
/*
    fuelButtons.forEach(button => {
        button.addEventListener('click', () => {
            fuelButtons.forEach(btn => btn.classList.remove('selected'));
            button.classList.add('selected');
            const fuelId = button.getAttribute('id');
            console.log(`Carburant sélectionné : ${fuelId}`);
            
            sendData({ type: 'carburant', value: fuelId });
        });
    });
*/

    paymentButtons.forEach(button => {
        button.addEventListener('click', () => {
            if (button.classList.contains('selected')) {
                button.classList.remove('selected');
            } else {
                button.classList.add('selected');
                const paymentType = button.getAttribute('class').split(' ')[1];
                console.log(`Méthode de paiement sélectionnée : ${paymentType}`);
                sendData({ type: 'paiement', value: paymentType });
            }
        });
    });
/*
    inputField.addEventListener('input', (event) => {
        const inputValue = event.target.value;
        console.log(`Valeur saisie : ${inputValue}`);
        sendData({ type: 'saisie', value: inputValue });
    });
    */
});

import { setupPumpButtons } from './calculatrice.js';


document.addEventListener('DOMContentLoaded', function() {
    fetch('/api/pompes')
        .then(response => response.json())
        .then(pompes => {
            // Base path pour les images
            const basePath = document.body.getAttribute('data-base-path');

            const popupBody = document.querySelector('#pumpManagementPopup .popup-body');
            popupBody.innerHTML = '';
            pompes.forEach(pompe => {
                const pompeItem = document.createElement('div');
                pompeItem.className = 'pump-item ' + pompe.etat;
                pompeItem.setAttribute('data-id-pompe', pompe.id_pompe);
                pompeItem.innerHTML = `
                    <img src="${basePath}images/pompe.png" alt="Pompe">
                    <div class="pump-info">
                        <p>Pompe n°${pompe.id_pompe}</p>
                        <p>Statut: ${pompe.etat}</p>
                    </div>
                `;
                pompeItem.addEventListener('click', function() {
                    const idPompe = this.getAttribute('data-id-pompe');
                    console.log(this.classList)
                    if (this.classList.contains('Désactivée')) {
                        fetch(`/update_pompe/${idPompe}`, {
                            method: 'POST',
                            headers: {'Content-Type': 'application/json'}
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                this.className = 'pump-item ' + data.nouvel_etat; 
                                this.querySelector('.pump-info p:nth-child(2)').textContent = `Statut: ${data.nouvel_etat}`;
                            } else {
                                alert('Erreur lors de la mise à jour de la pompe.');
                            }
                        })
                        .catch(error => console.error('Erreur:', error));
                    } else {
                        alert('Cette pompe ne peut être activée manuellement que si elle est désactivée.');
                     }
                    });                popupBody.appendChild(pompeItem);
            });

            // Mise a jour de la sélection de pompe
            const choixPompeContainer = document.querySelector('#choixpompe .options');
            choixPompeContainer.innerHTML = ''; 
            pompes.forEach(pompe => {
                const pompeButton = document.createElement('button');
                pompeButton.textContent = `Pompe ${pompe.id_pompe}`;
                pompeButton.className = 'pompe';
                pompeButton.id = `pompe-${pompe.id_pompe}`;
                console.log(pompe.etat);
                pompeButton.disabled = pompe.etat === 'Activée' || pompe.etat === 'En_Panne';
                choixPompeContainer.appendChild(pompeButton);
                
            });
            setupPumpButtons();
        })
        .catch(error => console.error('Erreur lors du chargement des pompes:', error));
});
