
    function updateClock() {
        const now = new Date();
        let hours = now.getHours();
        let minutes = now.getMinutes();
        if (hours < 10) {
            hours = '0' + hours;
        }
        if (minutes < 10) {
            minutes = '0' + minutes;
        }
        const timeStr = hours + ':' + minutes;
        document.getElementById('digital-clock').innerText = timeStr;
    }
    setInterval(updateClock, 60000);
updateClock()