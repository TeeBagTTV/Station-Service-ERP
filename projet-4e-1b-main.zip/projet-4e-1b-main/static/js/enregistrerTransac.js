/*document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.payment-button').forEach(button => {
        button.addEventListener('click', (e) => {
            // Déterminer le type de paiement
            let typePaiement;
            if (e.target.closest('.visa-button')) {
                typePaiement = 'carte_bleue';
            } else if (e.target.closest('.cash-button')) {
                typePaiement = 'espece';
            } else if (e.target.closest('.other-button')) {
                typePaiement = 'carte_station';
            }

            // Récupérer le montant total
            let montantTotalStr = document.querySelector('.total-amount').textContent;
            const montantTotal = montantTotalStr.replace(',', '.').slice(0, -2);

            // Préparer les données à envoyer
            const data = {
                type_paiement: typePaiement,
                montant_total: montantTotal,
                // Ajoutez ici d'autres données si nécessaire
            };

            console.log("Envoi des données au serveur:", data);

            // Envoyer la requête au serveur
            fetch('/transactions/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            })
            .then(response => {
                if (!response.ok) {
                    // Log l'état de la réponse en cas d'erreur
                    console.error('La réponse du serveur n\'est pas OK', response);
                    throw new Error('La réponse du réseau n\'était pas ok.');
                }
                return response.json();
            })
            .then(data => {
                console.log('Succès:', data);
                if (data.success) {
                    // Collecter les données des items pour la mise à jour des stocks
                    const items = document.querySelectorAll('.ticket .item');
                    const stockUpdates = Array.from(items).map(item => {
                        return {
                            id_produit: item.querySelector('.id').textContent.trim(),
                            quantite: parseInt(item.querySelector('.quantity').textContent.trim().slice(1))
                        };
                    });
            
                    fetch('/update_stock', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({updates: stockUpdates}),
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            console.log('Stocks mis à jour avec succès');
                        } else {
                            console.error('Échec de la mise à jour des stocks', data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Erreur lors de la mise à jour des stocks:', error);
                    });
                }
            })
            .catch((error) => {
                console.error('Erreur:', error);
            });
        });
    });
});
*/