
import { addItem } from './widgetLeft.js';
import { navigateToCard } from './carrousel.js';
import { searchIDClient, payer, getIDClient, getIDCarte, getPEnCours, setPEnCours} from './overlay.js';

let currentInput = "0,00";
let storedValue = null;
let isMultiplying = false;
let activeInput = null;

let connexionCarte=false;
let recrediterCarte=false;
function changeConnexion(bool){
    connexionCarte=bool;
}

function changeRecrediter(bool){
    recrediterCarte=bool;
}


const amountDisplay = document.querySelector('.amount2');
const productCodeInput = document.getElementById('productCodeInput');
let ajouter = document.getElementById('ajouter');
let fuel = document.getElementById('fuelcard'); 
let display = document.getElementById('top-container'); 
let choixPompe = document.getElementById('choixpompe');


function changeActiveInput(temp){
    activeInput=temp;

}

document.addEventListener('DOMContentLoaded', () => {

    function calculateResult() {
        if (storedValue !== null && isMultiplying) {
            return storedValue * convertInputToFloat(currentInput);
        }
        return 0;
    }

    function formatNumberToDisplay(number) {
        if (isNaN(number)) {
            return "0,00";
        }
        return number.toLocaleString('fr-FR', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }
    

    function convertInputToFloat(input) {
        input = input.replace(',', '.');
        const number = parseFloat(input);
        if (isNaN(number)) {
            return 0;
        }
        return number;
    }

    function addDigit(digit) {
        if (isMultiplying) {
            if (currentInput === "0" || currentInput === "0,00") {
                currentInput = digit.toString();
            } else {
                let potentialInput = currentInput + digit.toString();
                if (convertInputToFloat(potentialInput) <= 9999.99) {
                    currentInput = potentialInput;
                }
            }
            let result = calculateResult();
            amountDisplay.textContent = `${formatNumberToDisplay(storedValue)} x ${currentInput} = ${formatNumberToDisplay(result)}`;
        } else {
            let currentNumber = convertInputToFloat(currentInput);
            let potentialNumber = currentNumber * 10 + digit / 100;
            
            if (potentialNumber <= 9999.99) {
                currentNumber = potentialNumber;
            }
    
            currentInput = formatNumberToDisplay(currentNumber);
            updateDisplay();
        }
    }

    function deleteLastDigit() {
        if (activeInput === productCodeInput || activeInput === document.getElementById("montantRecredite")) {
            activeInput.value = activeInput.value.slice(0, -1);
        } else if (isMultiplying) {
            currentInput = currentInput.slice(0, -1) || "0,00";
            updateDisplay();
        } else {
            let number = convertInputToFloat(currentInput);
            number = (Math.floor(number * 10) / 100);
            currentInput = formatNumberToDisplay(number);
            updateDisplay();
        }
    }
    
    document.querySelectorAll('.btn2.grey').forEach(button => {
        button.addEventListener('click', (e) => {
            let digit = e.target.textContent;
            console.log(digit);
            if (!isNaN(digit)) {
                if (activeInput === productCodeInput || activeInput === document.getElementById("montantRecredite")) {
                    activeInput.value += digit;
                } else {
                    addDigit(parseInt(digit, 10));
                }
            }
        });
    });

    switchClavier(false); 


    document.querySelectorAll('.card2').forEach(button => {
    button.addEventListener('click', () => {
        console.log("card2");
        switchClavier(true);
        activeInput = productCodeInput;

        document.querySelectorAll('.fuel').forEach(btn => btn.classList.remove('selected'));
        document.querySelectorAll('.fuel').forEach(btn => btn.style.opacity = '1');

        document.querySelectorAll('.pompe').forEach(btn => btn.classList.remove('selected'));
        document.querySelectorAll('.pompe').forEach(btn => btn.style.opacity = '1');

        ajouter.style.border = "5px solid #008000";
        fuel.style.border = "None";
        choixPompe.style.border = "None";

        ajouter.style.opacity = '1';
        fuel.style.opacity = '0.5';
        display.style.opacity = '0.5';
        choixPompe.style.opacity = '0.5';
        

        const starButton = document.querySelectorAll('.btn2[style*="star"]');
        const greenButton = document.querySelectorAll('.btn2.green');
        
        starButton.forEach(button => {
            button.disabled = true;
            button.style.opacity = '0.5';
        });
        
        greenButton.forEach(button => {
            button.disabled = true;
            button.style.opacity = '0.5';
        });

        
    });
});

    document.querySelectorAll('.btn2[style*="star"]').forEach(button => {
        button.addEventListener('click', () => {
            if (currentInput !== "0,00" && !isMultiplying) {
                storedValue = convertInputToFloat(currentInput);
                currentInput = "";
                isMultiplying = true;
            }
        });
    });


    document.querySelectorAll('.btn2.green').forEach(button => {
        button.addEventListener('click', () => {
        console.log("Etat recredit"+recrediterCarte+" connexion "+connexionCarte+" pencours "+getPEnCours())
        console.log("bouton vert");
        if (isMultiplying) {
            let result = calculateResult();
            console.log(formatNumberToDisplay(result)); 
            currentInput = "0,00";
            storedValue = null;
            isMultiplying = false;
            updateDisplay();
        }
        else if(getPEnCours()){
            console.log("payement Carte s");
            searchIDClient();
            return;
        }
        else if(connexionCarte){
            console.log("enter");
            searchIDClient();
            changeConnexion(false);
        }
        else if(recrediterCarte){
            console.log('recredter');
            //diriger vers payement
            document.getElementById("carteStationPayement").style.display='none';
            payer();

            let montant = parseFloat(document.getElementById("montantRecredite").value);
            let id = parseInt(getIDCarte());
            updateCardCredit(id, montant);
            console.log("id "+id+" montant "+montant);
            changeRecrediter(false);
        }
        else {
            console.log("normal");
            const selectedFuel = document.querySelector('.fuel.selected');
            const selectedPump = document.querySelector('.pompe.selected');
            let temp = amountDisplay.textContent;
            const totalAmount = parseFloat(temp.replace('€', ''));
        
            if(totalAmount === 0.00){
                display.style.backgroundColor = "#FFC9C2";
                return;
            }
            if (selectedFuel && selectedPump) {
                
                const carburantId = getCarburantId(selectedFuel.id);
                if (!carburantId) {
                    init();
                    navigateToCard(0);
                    return;
                }
        
                fetch(`/carburants/${carburantId}`)
                    .then(response => response.json())
                    .then(data => {
                        console.log('Prix de vente du carburant:', data.prix_vente);
                        const liters = totalAmount / data.prix_vente;

                        const productDetails = {
                            id_produit: selectedFuel.id,
                            nom: `${data.nom} - ${liters.toFixed(2)}L`,
                            prix_vente: totalAmount.toFixed(2),
                        };
                    
                        addItem(productDetails, false);
                        init();
                        navigateToCard(0);
                    })
                    .catch(error => {
                        console.error('Erreur lors de la récupération des données du carburant:', error);
                        init();
                        navigateToCard(0);
                    });
            } else {
                if (selectedFuel && !selectedPump){
                    navigateToCard(1);
                }
                if (!selectedFuel && selectedPump){
                    navigateToCard(0);
                }
                if (!selectedFuel && !selectedPump){
                    navigateToCard(0);
                }
                
            }
        }
    });
    });

    document.querySelectorAll('.btn2.red').forEach(button => {
        button.addEventListener('click', clearInput);
    });

    document.querySelectorAll('.btn2.delete').forEach(button => {
        button.addEventListener('click', deleteLastDigit);
    });
    
    document.getElementById('choixpompe').addEventListener('click', action);
    document.querySelector('.fuel-types').addEventListener('click', action);


    function action() {
        console.log('click');
        activeInput = null;

        fuel.style.border = "5px solid #008000";
        choixPompe.style.border = "5px solid #008000";

        ajouter.style.border = "None";

        ajouter.style.opacity = '0.5';

        fuel.style.opacity = '1';
        choixPompe.style.opacity = '1';
        display.style.opacity = '1';

        switchClavier(true);
    }
    
    //choixpompe

    document.querySelectorAll('.fuel').forEach(button => {
        button.addEventListener('click', () => {
            document.querySelectorAll('.fuel').forEach(btn => btn.classList.remove('selected'));
            document.querySelectorAll('.fuel').forEach(btn => btn.style.opacity = '0.5');
            button.classList.add('selected');
            button.style.opacity = '1';

            const fuelId = button.getAttribute('id');
            console.log(`Carburant sélectionné : ${fuelId}`);

        });
    });

    

    // document.querySelectorAll('.pompe').forEach(button => {
    //     button.addEventListener('click', () => {
    //         document.querySelectorAll('.pompe').forEach(btn => btn.classList.remove('selected'));
    //         document.querySelectorAll('.pompe').forEach(btn => btn.style.opacity = '0.5');
    //         button.classList.add('selected');
    //         button.style.opacity = '1';

    //         const fuelId = button.getAttribute('id');
    //         console.log(`Pompe sélectionné : ${fuelId}`);

    //     });
    // });


});
export function setupPumpButtons() {
    document.querySelectorAll('.pompe').forEach(button => {
        button.addEventListener('click', () => {
            document.querySelectorAll('.pompe').forEach(btn => {
                btn.classList.remove('selected');
                btn.style.opacity = '0.5';
            });
            button.classList.add('selected');
            button.style.opacity = '1';

            const pompeId = button.getAttribute('id');
            console.log(`Pompe sélectionnée : ${pompeId}`);
        });
    });
}

function clearInput() {
    if (activeInput === productCodeInput || activeInput === document.getElementById("montantRecredite")) {
        activeInput.value = "";
    } else {
        currentInput = "0,00";
        storedValue = null;
        isMultiplying = false;
        updateDisplay();
    }
}

function init(){
    display.style.border = "None";
    switchClavier(false);
    clearInput();
    activeInput = null;

    fuel.style.border = "None";
    choixPompe.style.border = "None";
    ajouter.style.border = "None";

    ajouter.style.opacity = '1';

    fuel.style.opacity = '1';
    choixPompe.style.opacity = '1';
    display.style.opacity = '1';

    ajouter.style.border = "None";
    fuel.style.border = "None";
    choixPompe.style.border = "None";

    document.querySelectorAll('.fuel').forEach(btn => btn.classList.remove('selected'));
    document.querySelectorAll('.fuel').forEach(btn => btn.style.opacity = '1');
    document.querySelectorAll('.pompe').forEach(btn => btn.classList.remove('selected'));
    document.querySelectorAll('.pompe').forEach(btn => btn.style.opacity = '1');

}


    
function switchClavier(active) {
    const buttons = document.querySelectorAll('.btn2'); 

    if (!active) {
        buttons.forEach(button => {
            button.style.opacity = '0.5'; 
            button.disabled = true; 
        });
    } else {
        buttons.forEach(button => {
            button.style.opacity = '1'; 
            button.disabled = false; 
        });
    }
}

function updateDisplay() {
    let displayValue = currentInput + " EUR.";
    if (isMultiplying) {
        let result = calculateResult();
        displayValue = `${formatNumberToDisplay(storedValue)} x ${currentInput} = ${formatNumberToDisplay(result)}`;
    }
    amountDisplay.textContent = displayValue;
}



function getCarburantId(htmlId) {
    const mapping = {
        'gazole': 2,
        'gazole-premium': 3,
        'sp98': 4,
        'sp95-e10': 5,
        'sp95': 6,
        'ethanol': 7,
    };
    return mapping[htmlId] || null;
}

function updateCardCredit(id_carte_station, additionalCredit) {
    fetch(`/cartes_station/${id_carte_station}/credit`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ montant_credit_energie: additionalCredit })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log('Success:', data);
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}



export {clearInput, switchClavier, changeActiveInput, changeConnexion, changeRecrediter, updateCardCredit}