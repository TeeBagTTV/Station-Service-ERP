const container = document.querySelector(".container4");
const cards = document.querySelectorAll(".card");

let isPressedDown = false;
let startX;
let scrollLeft;

container.addEventListener("mousedown", (e) => {
  isPressedDown = true;
  startX = e.pageX - container.offsetLeft;
  scrollLeft = container.scrollLeft;
  container.style.cursor = "grabbing";
});

container.addEventListener("mouseup", () => {
  isPressedDown = false;
  container.style.cursor = "grab";
  snapToClosestCard();
});

window.addEventListener("mouseup", () => {
  if (isPressedDown) {
    isPressedDown = false;
    container.style.cursor = "grab";
    snapToClosestCard();
  }
});

container.addEventListener("mousemove", (e) => {
  if (!isPressedDown) return;
  e.preventDefault();
  const x = e.pageX - container.offsetLeft;
  const walk = (x - startX); 
  container.scrollLeft = scrollLeft - walk;
});

const paginationContainer = document.querySelector(".pagination");

function createPaginationDots() {
  for (let i = 0; i < cards.length; i++) {
    const dot = document.createElement("div");
    dot.classList.add("dot");
    if (i === 0) dot.classList.add("active-dot");
    paginationContainer.appendChild(dot);
  }
}

createPaginationDots();

function snapToClosestCard() {
  let closestCardIndex = 0;
  let minDiff = Infinity;
  const centerOfContainer = container.scrollLeft + container.offsetWidth / 2;
  cards.forEach((card, index) => {
    const cardCenter = card.offsetLeft + card.offsetWidth / 2;
    const diff = Math.abs(cardCenter - centerOfContainer);

    if (diff < minDiff) {
      minDiff = diff;
      closestCardIndex = index;
    }
  });

  const cardToSnapTo = cards[closestCardIndex];
  const newPosition = cardToSnapTo.offsetLeft - (container.offsetWidth / 2 - cardToSnapTo.offsetWidth / 2);

  container.scrollTo({
    left: newPosition,
    behavior: 'smooth'
  });

  updateActiveDot(closestCardIndex);
}

function updateActiveDot(activeIndex) {
  const dots = document.querySelectorAll(".dot");
  dots.forEach(dot => dot.classList.remove("active-dot"));
  dots[activeIndex].classList.add("active-dot");
}

document.addEventListener("DOMContentLoaded", snapToClosestCard);

function navigateToCard(index) {
    const cardToNavigateTo = cards[index];
    const newPosition = cardToNavigateTo.offsetLeft - (container.offsetWidth / 2 - cardToNavigateTo.offsetWidth / 2);
  
    container.scrollTo({
        left: newPosition,
        behavior: 'smooth'
    });
  
    updateActiveDot(index);
}

function attachEventsToPaginationDots() {
    const dots = document.querySelectorAll(".dot");
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => navigateToCard(index));
    });
}


attachEventsToPaginationDots();

export { navigateToCard}
